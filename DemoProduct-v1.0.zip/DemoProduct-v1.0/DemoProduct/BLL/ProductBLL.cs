﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exceptions;
using ProductEntity;
using System.Text.RegularExpressions;
using DAL;
using System.Data.SqlClient;


namespace BLL
{
    public class ProductBLL
    {
        ProductDAL pdll= null; // Creating Object of ProductDAL Class
        public ProductBLL()
        {
             pdll= new ProductDAL();
        }
        public static bool ValidateProduct(Product prod)
        {
            bool res = true;
            StringBuilder sb = new StringBuilder();

            if(prod.ProductId < 100000 && prod.ProductId >999999)
            {
                res = false;
                sb.Append(Environment.NewLine + "Product ID should be 6 Digits only");

            }
            var prodReExp = new Regex("^[A-Za-z]+$");
            if (!(prodReExp.IsMatch(prod.ProductName)) == true)
            {
                res = false;
                sb.Append(Environment.NewLine + "Product Name should contain only Alphabets");
            }
            return res;
        }

        public bool AddProduct(Product prod)
        {
            bool prodAdded = false;
            try
            {
                if (ValidateProduct(prod))
                {
                  
                    prodAdded = pdll.AddProduct(prod);
                }
            }
            catch (ProductExceptions)
            {
                throw;
            }
            catch (Exception e)
            {
                throw e;
            }
            return prodAdded;
        }
        
        
        public  List<Product> DisplayProd()
        {
            List<Product> prodList = new List<Product>();
            prodList = pdll.DisplayProd();
            
            return prodList;
        }

        public bool LoginCredentials(LoginClass rec)
        {
            try
            {
                return pdll.LoginCredentials(rec);
            }
            catch ( ProductExceptions e)
            {
                throw new ProductExceptions(e.Message);
            }
            catch (SqlException e)
            {
                throw e;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
