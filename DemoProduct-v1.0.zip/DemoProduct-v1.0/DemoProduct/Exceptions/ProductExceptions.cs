﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class ProductExceptions:ApplicationException
    {
        public ProductExceptions()
        {

        }
        public ProductExceptions(string message):base(message)
        {

        }
    }
}
