﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Exceptions;
using ProductEntity;
using BLL;
using System.Data.SqlClient;

namespace PL
{
    public partial class DisplayProduct : System.Web.UI.Page
    {
        BLL.ProductBLL pbll = new BLL.ProductBLL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                grdprod.DataSource = pbll.DisplayProd();
                grdprod.DataBind();
            }
        }

        protected void btnshow_Click(object sender, EventArgs e)
        {
            
            grdprod.DataSource = pbll.DisplayProd();
            grdprod.DataBind();

        }
    }
}