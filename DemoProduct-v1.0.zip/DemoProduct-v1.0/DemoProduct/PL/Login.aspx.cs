﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProductEntity;
using BLL;
using Exceptions;
using System.Web.Security;

namespace PL
{
    public partial class Login : System.Web.UI.Page
    {
        LoginClass cred = new LoginClass();
        ProductBLL bl = new ProductBLL();


        protected void Page_Load(object sender, EventArgs e)
        {
             
        }

        protected void btnLogIn_Click(object sender, EventArgs e)
        {
            cred.username = txtUsername.Text;
            cred.password = txtPassword.Text;
            if (bl.LoginCredentials(cred))
            {
                FormsAuthentication.RedirectFromLoginPage(cred.username, Persist.Checked);
                
            }
            else
            {
                lblmsg.Text = "Log In Failed ... Invalid Credentials";
            }
            Session["UserName"] = this.txtUsername.Text.Trim();

        }

    }
}