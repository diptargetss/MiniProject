﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Exceptions;
using ProductEntity;
using BLL;
using System.Data.SqlClient;

namespace PL
{
    public partial class AddProduct : System.Web.UI.Page
    {
        Product p = new Product();
        ProductBLL pbl = new ProductBLL();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            
            p.ProductId = Convert.ToInt32(txtid.Text);
            p.ProductName = txtname.Text;
            p.Price = Convert.ToDouble(txtprice.Text);
            if(pbl.AddProduct(p))
            {
               lbldo.Text="Successfully Added";
            }
            else
            {
                lbldo.Text = "Error While Adding";
            }

        }
    }
}