﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using Exceptions;
using ProductEntity;

namespace DAL
{
    public class ProductDAL
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["prodcon"].ConnectionString.ToString());
        SqlCommand cmd;
        
        public bool AddProduct(Product p)
        {
            bool prodadded = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_insertproduct";
                cmd.Parameters.AddWithValue("@id", p.ProductId);
                cmd.Parameters.AddWithValue("@name", p.ProductName);
                cmd.Parameters.AddWithValue("@price", p.Price);
                cmd.Connection = conn;

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                    prodadded = true;
            }
            catch (Exception ex)
            {
                throw new ProductExceptions(ex.Message);
            }

            return prodadded;
        }        
        
        
        
        
        
        
        public  List<Product> DisplayProd()
        {
            List<Product> prodlist = new List<Product>();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "dbo.usp_productasp";
                cmd.Connection = conn;
                conn.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                
                while (dr.Read())
                {
                    Product Prod = new Product();
                    Prod.ProductId = dr.GetInt32(0);
                    Prod.ProductName = dr.GetString(1);
                    Prod.Price = dr.GetDouble(2);

                    prodlist.Add(Prod);
                }
                dr.Close();
                conn.Close();
           
            
            return prodlist;
        }

        public bool LoginCredentials(LoginClass cred)
        {
            
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM HMS_NN.LoginCreds where USERNAME=@u AND PASS=@p", conn);

                cmd.Parameters.Add(new SqlParameter("@u", cred.username));
                cmd.Parameters.Add(new SqlParameter("@p", cred.password));

                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    conn.Close();
                    return true;

                }
                else
                {
                    conn.Close();
                    return false;

                }
            }
            catch (ProductExceptions e)
            {
                conn.Close();
                throw new ProductExceptions(e.Message);
            }
            catch (SqlException e)
            {
                conn.Close();
                throw e;
            }
            catch (Exception)
            {
                conn.Close();
                throw;
            }




        }

    }
}
