select * from ProductASP;

go
create proc usp_insertproduct(@id int,@name varchar(20),
@price float)
as
begin
insert into ProductASP(ProductID,ProductName,Price) 
values(@id,@name,@price)
end 
go