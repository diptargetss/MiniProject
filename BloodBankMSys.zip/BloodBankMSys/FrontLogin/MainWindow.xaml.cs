﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BBMS.Entities;
using BBMS.BL;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        BloodBL bbl = null;

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

       

        

        private void btnadmin_Click(object sender, RoutedEventArgs e)
        {
            Admin ad = new Admin();
            ad.Username = txtadminid.Text;
            ad.Password = txtadminpass.Password;
            bbl = new BloodBL();
            if (bbl.AdminCheck(ad))
            {
                Admin_Page ap = new Admin_Page();
                ap.Show();
            }
            else
                MessageBox.Show("Incorrect username or password entered");
        }

        private void btnbloodbank_Click(object sender, RoutedEventArgs e)
        {
            Login lg = new Login();
            lg.Username = bloodBankuserId.Text;
            lg.Password = bloodBankPwd.Password;
            bbl = new BloodBL();
            if (bbl.LoginCheck(lg))
            {
                BloodBankUser bk = new BloodBankUser();
                bk.Show();
            }
            else
                MessageBox.Show("Incorrect username or password entered");
        }
    }
}
