﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Entities
{
    public class BloodBank
    {
        public int BloodBankId { get; set; }
        public string BloodBankname { get; set; }
        public string Baddress { get; set; }
        public string BRegion { get; set; }
        public string BloodBankCity { get; set; }
        public string BloodBankMobNo { get; set; }
        public int BloodBankUserId { get; set; }
        public string BloodBankPwd { get; set; }
    }
}
