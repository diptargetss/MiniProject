﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entities;
using BBMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BBDAL
{
    public class BloodBankDA
    {
        SqlConnection con =new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public bool AdminCheck(Admin adm)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BBMS_AdminLogin";
                cmd.Parameters.AddWithValue("@username", adm.Username);
                cmd.Parameters.AddWithValue("@password", adm.Password);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
        }
        

        //Login for Blood Bank-------To be Done
        public  BloodBank LoginCheck(string Username,string Password)
        {
            BloodBank bk=new BloodBank();
            return bk;
        }
        public bool RequestCheck(string loc,int units)
        {
            return true;
        }
        public List<Donor> ShowDonors(int bbid)
        {
            List < Donor > DonorList= null;
           

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "donor_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                DonorList = new List<Donor>();
                while (dr.Read())
                {
                    Donor entity = new Donor();
                    entity.DonorID = dr.GetInt16(0);
                    entity.firstname = dr.GetString(1);
                    entity.lastname = dr.GetString(2);
                    entity.Mobile = dr.GetString(3);
                    entity.BloodGroup = dr.GetString(4);
                    entity.City = dr.GetString(5);
                    DonorList.Add(entity);
                }
            }
            catch (Exception ex)
            {
                throw new BloodException(ex.Message);
            }
            return DonorList;
        }

        public bool ModifyCampDetails(BloodCamp bc)
        {
            return true;
        }
        public bool DonorAdd(Donor d)
        {
            return true;
        }
        public bool DonorUpdate(Donor D)
        {
            return true;
        }
        public bool DonorDelete(int id)
        {
            return true;
        }
        public bool registerBank(string id,string bname)
        {
            bool bankadd = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bankadm_add";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Parameters.AddWithValue("@bname", bname);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankadd = true;
            }
            catch (Exception ex)
            {
                throw new BloodException(ex.Message);
            }

            return bankadd;
        }
        public bool AddCamp(BloodCamp bc)
        {
            return true;
        }
        public List<BloodBank> ShowBanks()
        {
            List<BloodBank> BBlist = null;
           

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                BBlist = new List<BloodBank>();
                while (dr.Read())
                {
                    BloodBank entity = new BloodBank();
                    entity.BloodBankId = dr.GetInt32(0);
                    entity.BloodBankname = dr.GetString(1);
                    entity.Baddress = dr.GetString(2);
                    entity.BRegion = dr.GetString(3);
                    entity.BloodBankCity = dr.GetString(4);
                    entity.BloodBankMobNo = dr.GetString(5);
                    BBlist.Add(entity);

                }
            }
            catch (Exception ex)
            {
                throw new BloodException(ex.Message);
            }
            return BBlist;
        }
        public bool AddHospIdName(int id, string hname)
        {
            bool hospadd = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hospadm_add";
                cmd.Parameters.AddWithValue("@hid", id);
                cmd.Parameters.AddWithValue("@hname", hname);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospadd = true;
            }
            catch (Exception ex)
            {
                throw new BloodException(ex.Message);
            }

            return hospadd;
        }

        public bool UpdateHospitalDetails(Hospital details)
        {
            bool hospupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_upd";
                cmd.Parameters.AddWithValue("@hid", details.HospitalId);
                cmd.Parameters.AddWithValue("@hname", details.Hospitalname);
                cmd.Parameters.AddWithValue("@haddress", details.HospitalAddress);
                cmd.Parameters.AddWithValue("@hcity", details.HospitalCity);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospupdate = true;
            }
            catch (Exception)
            {

                throw;
            }
            return hospupdate;
        }

        public bool DelHospitalDetails(int id)
        {
            bool hospdel = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_del";
                cmd.Parameters.AddWithValue("@hid", id);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospdel = true;
            }
            catch (Exception ex)
            {
                throw new BloodException(ex.Message);
            }

            return hospdel;
        }

        public bool AddBankIdName(int id, string bname)
        {
            bool bankadd = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bankadm_add";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Parameters.AddWithValue("@bname", bname);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankadd = true;
            }
            catch (Exception ex)
            {
                throw new BloodException(ex.Message);
            }

            return bankadd;
        }

        public bool DelBankDetails(int id)
        {
            bool bankdel = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_del";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankdel = true;
            }
            catch (Exception ex)
            {
                throw new BloodException(ex.Message);
            }

            return bankdel;
        }

        public bool UpdateBankDetails(BloodBank details)
        {
            bool bankupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_upd";
                cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                cmd.Parameters.AddWithValue("@bname", details.BloodBankname);
                cmd.Parameters.AddWithValue("@baddress", details.Baddress);
                cmd.Parameters.AddWithValue("@bcity", details.BloodBankCity);
                cmd.Parameters.AddWithValue("@bno", details.BloodBankMobNo);

                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankupdate = true;
            }
            catch (Exception)
            {

                throw;
            }
            return bankupdate;
        }
    }
}
