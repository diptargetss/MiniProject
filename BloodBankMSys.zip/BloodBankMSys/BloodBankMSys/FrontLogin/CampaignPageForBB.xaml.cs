﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BBMS.Entities;
using BBMS.Exceptions;
using BBMS.BL;


namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for CampaignPage.xaml
    /// </summary>
    public partial class CampaignPage : Page
    {
        public CampaignPage()
        {
            InitializeComponent();
        }

        BloodBL bbl = null;
        private void btncreate_Click(object sender, RoutedEventArgs e)
        {
            BloodCamp bc = new BloodCamp();
            bc.Name = txtcampname.Text;
            bc.Address = txtvenue.Text;
            bc.BloodBank = txtbbid.Text;
            bc.StartDate = Convert.ToDateTime(txtstartdate.SelectedDate);
            bc.EndDate = Convert.ToDateTime(txtenddate.SelectedDate);
            bbl = new BloodBL();
            bbl.AddCamp(bc);

        }

        
    }
}
