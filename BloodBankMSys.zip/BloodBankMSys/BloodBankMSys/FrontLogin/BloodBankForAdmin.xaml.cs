﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.BL;
using BBMS.Entities;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for BloodBankForAdmin1.xaml
    /// </summary>
    public partial class BloodBankForAdmin : Window
    {
        public BloodBankForAdmin()
        {
            InitializeComponent();
        }
        BloodBL bbl = null;

        private void btnaddbb_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtbbidadd.Text);
            string bname = txtbbnameadd.Text;
            bbl = new BloodBL();

        }



    }
}
