﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class BloodBL
    {
        BloodBankDA bbda = null;
        public BloodBL()
        {
            bbda = new BloodBankDA();
        }
        
        //Sign In For Admin
        public bool AdminCheck(Admin admin)
        {
            return bbda.AdminCheck(admin);
        }

        // Sign In For Blood Bank Employee
        public BloodBank LoginCheck(string Username,string Password)
        {
            return bbda.LoginCheck(Username,Password);
        }
        public bool ModifyCampDetails(BloodCamp camp,out string checkmsg)
        {
            //bool checkDate=false;
            checkmsg = "";
            if(camp.StartDate.CompareTo(DateTime.Now)>0)
            return bbda.ModifyCampDetails(camp);
            else
            {
                //Console.WriteLine("Cannot Change details as date already passed");
                checkmsg="Cannot Change details as date already passed";
                return false;
            }
        }
        public bool registerBank(string id,string bname )//out bbid)
        {
            //BloodBank bnk=bbda.BankSearch(b.userid);
            //if(bnk!=null)
            //{
            //    checkmsg="Username already exists";
            //    return false;
            //}
            //else
            return bbda.registerBank(id, bname);  
                    

        }
        public bool DonorAdd(Donor d){ return bbda.DonorAdd(d);}
        public bool DonorUpdate(Donor d){return bbda.DonorUpdate(d);}
        public bool DonorDelete(int id){return bbda.DonorDelete(id);}
        public bool AddCamp(BloodCamp bc)
        {
            if(bc.StartDate.CompareTo(DateTime.Now)>0)
            {
                if (bc.EndDate.CompareTo(bc.StartDate) > 0)
                    return bbda.AddCamp(bc);
                else
                    return false;
            }
            else
            {
                return false;
            }
        }
        
        public bool BloodRequest(Hospital hos,int units)
        {
            bool ch=bbda.RequestCheck(hos.Location,units);
            return ch;
        }
        public List<Donor> ShowDonors(int bbid)
        {return bbda.ShowDonors(bbid);}


        public List<BloodBank> ShowBanks()
        { return bbda.ShowBanks(); }

        public bool AddHospital(int id,string hname)
        {
            return bbda.AddHospIdName(id,hname);
        }

        public bool UpdateHospitalDetails(Hospital details)
        {
            return bbda.UpdateHospitalDetails(details);
        }

        public bool DelHospitalDetails(int id)
        {
            return bbda.DelHospitalDetails(id);
        }
        public bool AddBankIdName(int id, string bname)
        {
            return AddBankIdName(id,bname);
        }

        public bool DelBankDetails(int id)
        {
            return bbda.DelBankDetails(id);
        }

        public bool UpdateBankDetails(BloodBank details)
        {
            return UpdateBankDetails(details);
        }
        public List<Hospital> GetHospDetails()
        {
            return bbda.GetHospDetails();
        }
        public Hospital GetHospDetailsById(int id)
        {
            return bbda.GetHospDetailsById(id);
        }
        public List<BloodBank> GetBankDetails()
        {
            return bbda.GetBankDetails();
        }
        public BloodBank GetBankDetailsById(int id)
        {
            return bbda.GetBankDetailsById(id);
        }
        public List<BloodInventory> GetInventoryDetails()
        {
            return bbda.GetInventoryDetails();
        }
        public List<BloodCamp> GetDonationCampDetails()
        {
            return bbda.GetDonationCampDetails();
        }
        public List<Donor> GetDonorDetails()
        {
            return bbda.GetDonorDetails();
        }
    }
}
