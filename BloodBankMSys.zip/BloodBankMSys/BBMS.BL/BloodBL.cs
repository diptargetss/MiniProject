﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class BloodBL
    {
        BloodBankDA bbda = null;
        public BloodBL()
        {
            bbda = new BloodBankDA();
        }
        
        //Sign In For Admin
        public bool AdminCheck(Admin admin)
        {
            return bbda.AdminCheck(admin);
        }

        // Sign In For Blood Bank Employee
        public bool LoginCheck(Login login)
        {
            return bbda.LoginCheck(login);
        }
        public bool ModifyCampDetails(BloodCamp camp,out string checkmsg)
        {
            //bool checkDate=false;
            checkmsg = "";
            if(camp.StartDate.CompareTo(DateTime.Now)>0)
            return bbda.ModifyCampDetails(camp);
            else
            {
                //Console.WriteLine("Cannot Change details as date already passed");
                checkmsg="Cannot Change details as date already passed";
                return false;
            }
        }
        public bool registerBank(BloodBank b)//out bbid)
        {
            //BloodBank bnk=bbda.BankSearch(b.userid);
            //if(bnk!=null)
            //{
            //    checkmsg="Username already exists";
            //    return false;
            //}
            //else
                
            bool ch=bbda.registerBank(b);
            return ch;
            

        }
        public bool DonorAdd(Donor d){ return bbda.DonorAdd(d);}
        public bool DonorUpdate(Donor d){return bbda.DonorUpdate(d);}
        public bool DonorDelete(int id){return bbda.DonorDelete(id);}
        public bool AddCamp(BloodCamp bc)
        {
            if(bc.StartDate.CompareTo(DateTime.Now)>0)
            {
                if (bc.EndDate.CompareTo(bc.StartDate) > 0)
                    return bbda.AddCamp(bc);
                else
                    return false;
            }
            else
            {
                return false;
            }
        }
        
        public bool BloodRequest(Hospital hos,int units)
        {
            bool ch=bbda.RequestCheck(hos.Location,units);
            return ch;
        }
        public List<Donor> ShowDonors(int bbid)
        {return bbda.ShowDonors(bbid);}



    }
}
