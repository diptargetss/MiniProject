﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entities;
using BBMS.Exceptions;

namespace BBDAL
{
    public class BloodBankDA
    {
        public bool AdminCheck(Admin adm)
        {
            return true;
        }
        public bool LoginCheck(Login log)
        {
            return true;
        }
        public bool RequestCheck(string loc,int units)
        {
            return true;
        }
        public List<Donor> ShowDonors(int bbid)
        {
            List < Donor > DonorList= new List<Donor>();
            return DonorList;
        }

        public bool ModifyCampDetails(BloodCamp bc)
        {
            return true;
        }
        public bool DonorAdd(Donor d)
        {
            return true;
        }
        public bool DonorUpdate(Donor D)
        {
            return true;
        }
        public bool DonorDelete(int id)
        {
            return true;
        }
        public bool registerBank(BloodBank bb)
        {
            return true;
        }
        public bool AddCamp(BloodCamp bc)
        {
            return true;
        }

    }
}
