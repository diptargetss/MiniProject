﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;
using System.Data.SqlClient;
namespace BBMS.PL
{
    public partial class BloodRequest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        BloodRequestBL rbl = new BloodRequestBL();

        protected void btnrequest_Click(object sender, EventArgs e)
        {
            
            Bloodrequest brq=new Bloodrequest();
            try
            {
                //BloodRequest bb=new BloodRequest();
                brq.HospitalId = Convert.ToInt32(txthid.Text);
                brq.HospCity = txtcity.Text;
                brq.HospitalName = txthname.Text;
                brq.HospAddress = txtaddr.Text;
                brq.ReqDate = Convert.ToDateTime(txtdate.Text);
                brq.HospRegion = txtregion.Text;
                brq.NoOfPackets = Convert.ToInt32(txtno.Text);
                brq.BloodGroup = drpblood.SelectedItem.ToString();
                if(rbl.AddRequest(brq))
                {
                    //ScriptManager.RegisterClientScriptBlock(this,this.GetType(), "Alert", "alert('Request added successfully')", true);
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Request added successfully')", true);
                    Session["user"] = brq;

                    Server.Transfer("BloodProcess.aspx");
                }
                else
                {
                    lblmsg.Text = "Failed to add request";
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = "Please register hospital with admin";
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }

    }
}