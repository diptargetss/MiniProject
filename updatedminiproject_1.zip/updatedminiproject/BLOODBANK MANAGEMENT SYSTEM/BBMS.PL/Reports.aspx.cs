﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BBMS.BL;
using BBMS.Entity;
using BBMS.Exceptions;
using System.Data.SqlClient;

namespace BBMS.PL
{
    public partial class Reports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AdminReportBL arl=new AdminReportBL ();
            if(DropDownList1.SelectedItem.Value=="Blood Bank")
            {
                GridView1.Enabled = true;
                lblheading.Text = "Blood Bank Details";
                GridView1.DataSource = arl.GetBankDetails();
                GridView1.DataBind();
            }
            else if(DropDownList1.SelectedItem.Value=="Hospital")
            {
                GridView1.Enabled = true;
                lblheading.Text = "Hospital Details";
                GridView1.DataSource = arl.GetHospitalDetails();
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedItem.Value == "Donor")
            {
                GridView1.Enabled = true;
                lblheading.Text = "Donor Details";
                GridView1.DataSource = arl.GetDonorDetails();
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedItem.Value == "Camp")
            {
                GridView1.Enabled = true;
                lblheading.Text = "Camp Details";
                GridView1.DataSource = arl.GetCampDetails();
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedItem.Value == "Inventory")
            {
                GridView1.Enabled = true;
                lblheading.Text = "Inventory Details";
                GridView1.DataSource = arl.GetInventoryDetails();
                GridView1.DataBind();
            }
            else
            {
                lblheading.Text = "Select any option";
                GridView1.Enabled = false;
            }
        }
    }
}