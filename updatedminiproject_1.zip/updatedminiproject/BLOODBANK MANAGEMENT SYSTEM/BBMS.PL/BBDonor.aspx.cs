﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class BBDonor : System.Web.UI.Page
    {
        DonorBL dbl = new DonorBL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                Donor d = new Donor();
                d.BloodBankID = (int)Session["user"];
                d.DonorID = Convert.ToInt32(txtdonorid.Text);
                d.firstname = txtfname.Text;
                d.lastname = txtlname.Text;
                d.Address = txtadd.Text;
                d.City = txtcity.Text;
                d.Mobile = txtmob.Text;
                d.Age = Convert.ToInt32(txtage.Text);
                d.Weight = Convert.ToInt32(txtwt.Text);
                d.BloodGroup = dd1.SelectedItem.Value;
                d.NoOfBottles = Convert.ToInt32(txtunits.Text);
                d.DonationDate = Convert.ToDateTime(txtcal.Text);
                d.DonationID = Convert.ToInt32(txtdonationid.Text);
                d.HBcount = Convert.ToInt32(txthb.Text);
                if (dbl.DonorAdd(d))
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record added successfully')", true);
                    txtdonorid.Text = "";
                    txtfname.Text = "";
                    txtlname.Text = "";
                    txtadd.Text = "";
                    txtcity.Text = "";
                    txtmob.Text = "";
                    txtage.Text = "";
                    txtwt.Text = "";
                    txtunits.Text = "";
                    txtcal.Text = "";
                    txtdonationid.Text = "";
                    txthb.Text = "";
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not added ')", true);
                    txtdonorid.Text = "";
                    txtfname.Text = "";
                    txtlname.Text = "";
                    txtadd.Text = "";
                    txtcity.Text = "";
                    txtmob.Text = "";
                    txtage.Text = "";
                    txtwt.Text = "";
                    txtunits.Text = "";
                    txtcal.Text = "";
                    txtdonationid.Text = "";
                    txthb.Text = "";
                }
            }
            catch(BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                Donor d = new Donor();
                d.BloodBankID = (int)Session["user"];
                d.DonorID = Convert.ToInt32(txtdonorid.Text);
                d.firstname = txtfname.Text;
                d.lastname = txtlname.Text;
                d.Address = txtadd.Text;
                d.City = txtcity.Text;
                d.Mobile = txtmob.Text;
                d.Age = Convert.ToInt32(txtage.Text);
                d.Weight = Convert.ToInt32(txtwt.Text);
                d.BloodGroup = dd1.SelectedItem.Value;
                d.NoOfBottles = Convert.ToInt32(txtunits.Text);
                d.DonationDate = Convert.ToDateTime(txtcal.Text);
                d.DonationID = Convert.ToInt32(txtdonationid.Text);
                d.HBcount = Convert.ToInt32(txthb.Text);
                if (dbl.DonorUpdate(d))
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record modified successfully')", true);
                    txtdonorid.Text = "";
                    txtfname.Text = "";
                    txtlname.Text = "";
                    txtadd.Text = "";
                    txtcity.Text = "";
                    txtmob.Text = "";
                    txtage.Text = "";
                    txtwt.Text = "";
                    txtunits.Text = "";
                    txtcal.Text = "";
                    txtdonationid.Text = "";
                    txthb.Text = "";
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not modified ')", true);
                    txtdonorid.Text = "";
                    txtfname.Text = "";
                    txtlname.Text = "";
                    txtadd.Text = "";
                    txtcity.Text = "";
                    txtmob.Text = "";
                    txtage.Text = "";
                    txtwt.Text = "";
                    txtunits.Text = "";
                    txtcal.Text = "";
                    txtdonationid.Text = "";
                    txthb.Text = "";
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                Donor d = new Donor();
                d.BloodBankID = (int)Session["user"];
                d.DonorID = Convert.ToInt32(txtdonorid.Text);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "confirm('Are you sure want to delete ?')", true);
                if (true)
                {
                    if (dbl.DonorDelete(d))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record deleted successfully')", true);
                        txtdonorid.Text = "";
                        txtfname.Text = "";
                        txtlname.Text = "";
                        txtadd.Text = "";
                        txtcity.Text = "";
                        txtmob.Text = "";
                        txtage.Text = "";
                        txtwt.Text = "";
                        txtunits.Text = "";
                        txtcal.Text = "";
                        txtdonationid.Text = "";
                        txthb.Text = "";
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not deleted ')", true);
                        txtdonorid.Text = "";
                        txtfname.Text = "";
                        txtlname.Text = "";
                        txtadd.Text = "";
                        txtcity.Text = "";
                        txtmob.Text = "";
                        txtage.Text = "";
                        txtwt.Text = "";
                        txtunits.Text = "";
                        txtcal.Text = "";
                        txtdonationid.Text = "";
                        txthb.Text = "";
                    }
                }
                else
                {
                    txtdonorid.Text = "";
                    txtfname.Text = "";
                    txtlname.Text = "";
                    txtadd.Text = "";
                    txtcity.Text = "";
                    txtmob.Text = "";
                    txtage.Text = "";
                    txtwt.Text = "";
                    txtunits.Text = "";
                    txtcal.Text = "";
                    txtdonationid.Text = "";
                    txthb.Text = "";
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                Donor d = new Donor();
                d.BloodBankID = (int)Session["user"];
                d.DonorID = Convert.ToInt32(txtdonorid.Text);
                d = dbl.SearchDonorById(d);
                if (d != null)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record Found')", true);
                    txtdonorid.Text =Convert.ToString(d.DonorID);
                    txtfname.Text = d.firstname;
                    txtlname.Text = d.lastname;
                    txtadd.Text = d.Address;
                    txtcity.Text = d.City;
                    txtmob.Text = d.Mobile;
                    txtage.Text =Convert.ToString(d.Age);
                    txtwt.Text =Convert.ToString(d.Weight);
                    dd1.SelectedValue=d.BloodGroup;
                    txtunits.Text =Convert.ToString(d.NoOfBottles);
                    txtcal.TextMode = System.Web.UI.WebControls.TextBoxMode.DateTime;
                    txtcal.Text = d.DonationDate.ToShortDateString();
                    txtdonationid.Text =Convert.ToString(d.DonationID);
                    txthb.Text =Convert.ToString(d.HBcount);                 
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not found ')", true);
                    txtdonorid.Text = "";
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }
    }
}