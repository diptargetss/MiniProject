﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class BloodBankDetails : System.Web.UI.Page
    {
        BBDetailBL bbl = new BBDetailBL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnmodify_Click(object sender, EventArgs e)
        {
            try
            {
                Bloodbank bb = new Bloodbank();

                bb.BloodBankId = (int)Session["user"];
                bb.BloodBankname = txtbname.Text;
                bb.Baddress = txtaddr.Text;
                bb.BRegion = txtregion.Text;
                bb.BloodBankCity = txtcity.Text;
                bb.BloodBankMobNo = txtcontact.Text;

                if(bbl.UpdateBankDetails(bb))
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record modified successfully')", true);
                    txtbname.Text = "";
                    txtaddr.Text = "";
                    txtregion.Text = "";
                    txtcity.Text = "";
                    txtcontact.Text = "";
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record is not modified.')", true);
                    txtbname.Text = "";
                    txtaddr.Text = "";
                    txtregion.Text = "";
                    txtcity.Text = "";
                    txtcontact.Text = "";
                }
            }
            catch(BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }
    }
}