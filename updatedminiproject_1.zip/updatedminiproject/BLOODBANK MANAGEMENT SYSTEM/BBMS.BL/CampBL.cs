﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.DAL;

namespace BBMS.BL
{
    public class CampBL
    {
        CampDL cdl = new CampDL();
        public bool ValidateCamp(BloodCamp bc)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();

            if (bc.CampID == null || bc.Name == string.Empty || bc.City == string.Empty || bc.StartDate == null || bc.EndDate == null)
            {
                valid = false;
                sb.Append(" Values cannot be Empty ");
            }
            if(bc.CampID<1000||bc.CampID>9999)
            {
                valid = false;
                sb.Append("Camp ID should be atleast 4 digits");
            }
            if (bc.EndDate<bc.StartDate)
            {
                valid = false;
                sb.Append("EndDate should be more than or equal to current date.  ");
            }
            if (bc.StartDate<=DateTime.Now)
            {
                valid = false;
                sb.Append("Start date should be greater than or equal to current date ");
            }
            if (valid == false)
            {
                throw new BloodExceptions(sb.ToString());
            }  
            return valid;
        }
        public bool AddCamp(BloodCamp bc)
        {
            bool added = false;
            try
            {
                if(ValidateCamp(bc))
                {
                    added = cdl.AddCampDetails(bc);
                }
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return added;
        }

        public bool ModifyCampDetails(BloodCamp bc)
        {
            bool updated = false;
            try
            {
                if (ValidateCamp(bc))
                {
                    updated = cdl.UpdateCampDetails(bc);
                }
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return updated;
        }

        public BloodCamp GetCampDetailsById(BloodCamp bc)
        {
            try
            {
                return cdl.GetCampDetailsById(bc);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
        public bool DeleteCamp(BloodCamp bc)
        {
            try
            {
                return cdl.DeleteCampDetails(bc);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
    }
}
