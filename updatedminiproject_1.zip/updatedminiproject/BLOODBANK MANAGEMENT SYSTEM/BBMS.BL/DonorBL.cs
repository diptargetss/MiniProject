﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.DAL;

namespace BBMS.BL
{
    public class DonorBL
    {
        DonorDL ddl = new DonorDL();
        public bool ValidateDonor(Donor donr)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();

            if (donr.DonorID == null || donr.firstname == string.Empty || donr.lastname == string.Empty || donr.Address == string.Empty || donr.City == string.Empty||
                donr.Mobile==string.Empty || donr.Age==null || donr.NoOfBottles==null || donr.Weight==null || donr.DonationDate==null||donr.DonationID==null||donr.HBcount==null)
            {
                valid = false;
                sb.Append(" Values cannot be Empty ");
            }
            var regexp = new Regex("^[0-9]{10}$");
            if (regexp.IsMatch(donr.Mobile)==false)
            {
                valid = false;
                sb.Append("Mobile number should be 10 digits");
            }
            if (valid == false)
            {
                throw new BloodExceptions(sb.ToString());
            }
            return valid;
        }
        public bool DonorAdd(Donor d)
        {
            bool added = false;
            try
            {
                if (ValidateDonor(d))
                {
                    added=ddl.AddDonor(d);
                }
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return added;
        }

        public bool DonorUpdate(Donor d)
        {
            bool updated=false;
            try
            {
                if(ValidateDonor(d))
                {
                    updated=ddl.UpdateDonor(d);
                }
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return updated;
        }
        public bool DonorDelete(Donor d)
        {
            try
            {
                return ddl.DelDonor(d);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
        public Donor SearchDonorById(Donor d)
        {
            try
            {
                return SearchDonorById(d);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
    }
}
