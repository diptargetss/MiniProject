﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Entity
{
    public class Bloodrequest
    {
        public int HospitalId { get; set; }
        public string HospitalName { get; set; }
        public string HospAddress { get; set; }
        public string HospCity { get; set; }
        public string HospRegion { get; set; }
        public DateTime ReqDate { get; set; }
        public string BloodGroup { get; set; }
        public int NoOfPackets { get; set; }
    }
}
