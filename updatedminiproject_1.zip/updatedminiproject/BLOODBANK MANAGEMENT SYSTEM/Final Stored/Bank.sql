----stored PROCedure for bloodbank login

GO
CREATE PROC udp_bblogin
(
	@user VARCHAR(20),
	@password VARCHAR(20)
)
AS
BEGIN
	SELECT 
		BloodBankId
	FROM
		BBMS.BloodBank 
	WHERE
		bbuser=@user 
		AND
		bbpwd=@password
END
GO

DROP PROC udp_bblogin
EXEC udp_bblogin 'abcuser','abcuser'

select * from BBMS.BloodBank 


----displaying camp details for particular blood bank



GO 
CREATE PROC bb_campview
(
	@bbid INT
)
AS
BEGIN
	SELECT * FROM
		BBMS.BloodDonationCamp 
	WHERE
		bloodbankid=@bbid
END
GO

EXEC bb_campview 100100


-----displaying donor for particular blood bank


GO 
CREATE PROC bb_donorview
(
	@bbid INT
)
AS
BEGIN
	SELECT * FROM 
		BBMS.BloodDonor 
	WHERE 
		bloodbankid=@bbid
END
GO


---displaying inventory for particular blood bank


GO 
CREATE PROC bb_inventoryview
(
	@bbid INT
)
AS
BEGIN
	SELECT * FROM 
		BBMS.BloodInventory 
	WHERE 
		BloodBankId=@bbid
END
GO


---displaying request for blood bank


GO 
CREATE PROC bb_requestview
AS
BEGIN
	SELECT * FROM 
		BBMS.HospitalRequest
END
GO

DROP PROC bb_requestview



-------INSERTing stock----
GO 
CREATE PROC udp_stocktransfers
(
	@id INT,
	@name VARCHAR(20),
	@group VARCHAR(5),
	@quantity INT,
	@date DATE
)
AS
BEGIN
		INSERT INTO BBMS.StockTransfer 
		VALUES(@id,@name,@group,@quantity,@date)
END
GO


------Updating stock-----------
GO 
CREATE PROC inventory_upd
(
	@bbid INT,
	@bgrp VARCHAR(10)
)
AS
	DELETE FROM 
		BBMS.BloodInventory 
	WHERE 
		BloodGroup=@bgrp 
		AND 
		BloodBankId=@bbid
		AND 
		expirydate=(SELECT min(expirydate) FROM BBMS.BloodInventory)
		AND
		BloodInventoryId=(SELECT MIN(BloodInventoryId) FROM BBMS.BloodInventory
	WHERE 
		BloodGroup=@bgrp
		AND 
		BloodBankId=@bbid
		AND
		expirydate=(SELECT min(expirydate) FROM BBMS.BloodInventory)
)
GO

DROP PROC udp_stocktransfers

EXEC udp_stocktransfers 100102,'ABC','O+ve',12,'02-02-2018',1,51,'11-11-2018'



------------stored PROCedure for bloodbank registration

GO
CREATE PROC udp_bloodbankreg
(
	@id INT,
	@user VARCHAR(10),
	@pass VARCHAR(10),
	@address VARCHAR(50),
	@region VARCHAR(20),
	@city VARCHAR(10),
	@contact VARCHAR(10)
)
AS
BEGIN
	--INSERT INTO BBMS.BloodBank(BloodBankId,bbuser,bbpwd,bbaddress,bbregion,bbcity,bbMobNo) 
	--VALUES(@id,@user,@pass,@address,@region,@city,@contact)
	UPDATE BBMS.BloodBank
	SET
	bbuser=@user,
	bbpwd=@pass,
	bbaddress=@address,
	bbregion=@region,
	bbcity=@city,
	bbMobNo=@contact
	WHERE
	BloodBankId=@id
	 
END
GO

EXEC udp_bloodbankreg 100102,'gdshjadga','sagdhsgd','ye','sdgfdsgf','gsfdggfsa','324322543'

select * from BBMS.BloodBank
DROP PROC udp_bloodbankreg


-------Adding Request---------
GO
CREATE PROC udp_requestadd
(
	@hid INT,
	@hname VARCHAR(20),
	@haddress VARCHAR(20),
	@hcity VARCHAR(20),
	@hregion VARCHAR(20),
	@hdate DATE,
	@hbgroup VARCHAR(20),
	@humpackets INT
)
AS
BEGIN 
	INSERT INTO BBMS.hospitalrequest 
	VALUES(@hid,@hname,@haddress,@hcity,@hregion,@hdate,@hbgroup,@humpackets)
END
GO


-------Adding blood donation camp details---
GO
CREATE PROC udp_camp
(
	@bid INT,
	@cid INT,
	@cname VARCHAR(10),
	@cadd VARCHAR(10),
	@startdate DATE,
	@enddate DATE
)
AS
BEGIN
	INSERT INTO BBMS.BloodDonationCamp 
	(BloodbankId,Donationcampid,campName,donaddress,campcity,campstartdate,campenddate)
	VALUES
	(@bid,@cid,@cname,'',@cadd,@startdate,@enddate)
END	
GO

EXEC udp_camp 100101,101,'BloodDrop2','HYD2','9-9-2017','11-9-2017'


DROP PROC udp_camp

------Searching by donation camp id--
GO
CREATE PROC udp_campbyid
(
	@cid INT
)
AS
BEGIN
	SELECT * FROM 
		BBMS.BloodDonationCamp 
	WHERE 
		Donationcampid=@cid
END
GO

EXEC udp_campbyid 1001

---_Updating camp details by camp id-----
GO
CREATE PROC udp_campupdate
(
	@cid INT,
	@bid INT,
	@cname VARCHAR(10),
	@cadd VARCHAR(10),
	@startdate DATE,
	@enddate DATE
)
AS
BEGIN
	UPDATE BBMS.BloodDonationCamp 
	SET Donationcampid=@cid,
		bloodbankid=@bid,
		campName=@cname,
		campcity=@cadd,
		campstartdate=@startdate,
		campenddate=@enddate 
		WHERE
		Donationcampid=@cid
END
GO


DROP PROC udp_campupdate



---------check availability for  bank id----

GO
CREATE PROC udp_checkavailbank
(
	@bid INT
)
AS
BEGIN
	SELECT * FROM BBMS.BloodBank 
	WHERE 
	BloodBankId=@bid
END
GO

SELECT * FROM BBMS.BloodBank

EXEC udp_checkavailbank

-------------check availability donor---
GO
CREATE PROC udp_checkavailbankuser
(
	@bbuser VARCHAR(10)
)
AS
BEGIN
	SELECT * FROM BBMS.BloodBank 
	WHERE 
	BloodBankname=@bbuser
END
GO


----stored PROCedure for adding donor details

GO
CREATE PROC udp_adddonor
(
	@id INT,
	@fname VARCHAR(20),
	@lname VARCHAR(20),
	@add VARCHAR(50),
	@city VARCHAR(20),
	@mobileno VARCHAR(15),
	@age INT,
	@weight INT,
	@bloodgroup VARCHAR(15),
	@units INT,
	@donationdate date,
	@hbcount INT,
	@donationid INT,
	@bloodbankid INT
)
AS
BEGIN
	INSERT INTO BBMS.BloodDonor 
	VALUES(@id,@fname,@lname,@add,@city,@mobileno,@age,@weight,@bloodgroup,@units,@donationdate,@hbcount,@donationid,@bloodbankid)
END
GO

DROP PROC udp_adddonor


--deleting the donor details

DROP PROC udp_donordelete

GO
CREATE PROC udp_donordelete
(
	@id INT
)
AS
BEGIN
	DELETE FROM BBMS.BloodDonor
	WHERE 
		BloodDonorId=@id
END
GO

EXEC udp_donordelete 101


--CREATE PROC udp_donorDELETE(@id INT)
--AS
--BEGIN
--DELETE BBMS.BloodDonor,BBMS.BloodDonorDonation FROM BBMS.BloodDonor,BBMS.BloodDonorDonation WHERE BBMS.BloodDonor.blooddonorid=BBMS.BloodDonorDonation.blooddonorid
--END
--GO

SELECT * FROM BBMS.BloodDonor
SELECT * FROM BBMS.BloodDonorDonation

EXEC udp_donorDELETE 1001

------updating the donor details

--INSERT INTO BBMS.BloodDonor VALUES(1001,'latha','Reddy','Chirala','Ap','7337037769','O+ve',21,65)

--INSERT INTO BBMS.BloodDonorDonation VALUES(10023,1001,'02-02-1998',12,23,23,12)



-----updating donor details

GO
CREATE PROC udp_update
(
	@id INT,@fname VARCHAR(20),
	@lname VARCHAR(20),
	@add VARCHAR(50),
	@city VARCHAR(20),
	@mobileno VARCHAR(15),
	@age INT,
	@weight INT,
	@bloodgroup VARCHAR(15),
	@units INT,
	@donationdate date,
	@hbcount INT,
	@donationid INT,
	@bloodbankid INT
)
AS
BEGIN
	UPDATE BBMS.BloodDonor 
	SET
		BloodDonorId=@id,
		firstname=@fname,
		lAStname=@lname,
		donoraddress=@add,
		donorcity=@city,
		donormobnum=@mobileno,
		age=@age,
		donorbloodgroup=@bloodgroup,
		units=@units,
		weights=@weight,
		Donationdate=@donationdate,
		hbCount=@hbcount,
		donationid=@donationid,
		bloodbankid=@bloodbankid
		WHERE
			BloodDonorId=@id
END
GO

drop PROC udp_update

--searching donor dy id
GO
CREATE PROC udp_DonorSearchById
(
	@id INT
)
AS
BEGIN
	SELECT * FROM 
		BBMS.BloodDonor 
	WHERE
		BloodDonorId=@id
END
GO


EXEC udp_DonorSearchById 101
