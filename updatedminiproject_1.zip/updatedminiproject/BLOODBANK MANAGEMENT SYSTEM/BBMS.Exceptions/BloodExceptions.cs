﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Exceptions
{
    public class BloodExceptions:ApplicationException
    {
        public BloodExceptions():base()
        {

        }
        public BloodExceptions(string message):base(message)
        {
                
        }
    }
}
