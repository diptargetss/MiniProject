﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.Exceptions;
using BBMS.Entity;


namespace BBMS.DAL
{
    public class StockDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public bool DeleteExp()
        {
            bool delete = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "inventory_delexp";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@expdate",DateTime.Now);

                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                {
                    delete = true;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return delete;
        }

        public bool UpdateInventory(int bbid,int units,string grp)
        {
            bool updated = false;
            int res=0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "inventory_upd";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@bbid", bbid);
                cmd.Parameters.AddWithValue("@bgrp", grp);
               
                con.Open();
                
                for (int i = 0; i < units; i++)
                {
                    res=cmd.ExecuteNonQuery();
                }
                con.Close();
                if (res > 0)
                    updated = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return updated;
        }
        public bool StockTransfer(int bbid,int units,string hname,string grp,DateTime dt)
        {
            bool added = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_stocktransfer";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@id", bbid);
                cmd.Parameters.AddWithValue("@name",hname);
                cmd.Parameters.AddWithValue("@group", grp);
                cmd.Parameters.AddWithValue("@quantity", units);
                cmd.Parameters.AddWithValue("@date", dt);
                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                    added = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return added;
        }
       
    }
    
}
