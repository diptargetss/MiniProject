﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.Entities;
using BBMS.Exceptions;
using BBMS.BL;
namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for DonarForm.xaml
    /// </summary>
    public partial class DonarForm : Window
    {
        public DonarForm()
        {
            InitializeComponent();
        }
        BloodBL bbl = null;
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btndonoradd_Click(object sender, RoutedEventArgs e)
        {
            Donor dr=new Donor();
            dr.Address = txtaddress.Text;
            dr.Age = Convert.ToInt32(txtage.Text);
            dr.BloodBankID=1233;
            dr.BloodGroup = bgrp.SelectedValue.ToString();
            dr.City = txtcity.Text;
            dr.DonationDate = Convert.ToDateTime(dpdonate.SelectedDate);
            dr.DonationID = Convert.ToInt32(txtdonationid.Text);
            dr.firstname = txtfirstname.Text;
            dr.lastname = txtlastname.Text;
            dr.HBcount = Convert.ToInt32(txthbcount.Text);
            dr.NoOfBottles = 1;
            dr.Weight = Convert.ToInt32(txtweight.Text);
            dr.Mobile = txtmobile.Text;
            dr.DonorID = Convert.ToInt32(txtdonorid.Text);

            bbl = new BloodBL();
            if (bbl.DonorAdd(dr))
                MessageBox.Show("Added Successfully");
            else
                MessageBox.Show("Failed to Add Donor");
            


        }

        private void btndonorupd_Click(object sender, RoutedEventArgs e)
        {
            Donor dr = new Donor();
            dr.Address = txtaddress.Text;
            dr.Age = Convert.ToInt32(txtage.Text);
            dr.BloodBankID = 1230;
            dr.BloodGroup = bgrp.SelectedValue.ToString();
            dr.City = txtcity.Text;
            dr.DonationDate = Convert.ToDateTime(dpdonate.SelectedDate);
            dr.DonationID = Convert.ToInt32(txtdonationid.Text);
            dr.firstname = txtfirstname.Text;
            dr.lastname = txtlastname.Text;
            dr.HBcount = Convert.ToInt32(txthbcount.Text);
            dr.NoOfBottles = 1;
            dr.Weight = Convert.ToInt32(txtweight.Text);
            dr.Mobile = txtmobile.Text;
            dr.DonorID = Convert.ToInt32(txtdonorid.Text);
            bbl=new BloodBL();
            if (bbl.DonorUpdate(dr))
                MessageBox.Show("Donor Details updated");
            else
                MessageBox.Show("Failed to update Donor");
        }


        private void btndonordel_Click(object sender, RoutedEventArgs e)
        {
            Donor dr = new Donor();
            dr.Address = txtaddress.Text;
            dr.Age = Convert.ToInt32(txtage.Text);
            dr.BloodBankID = 1233;
            dr.BloodGroup = bgrp.SelectedValue.ToString();
            dr.City = txtcity.Text;
            dr.DonationDate = Convert.ToDateTime(dpdonate.SelectedDate);
            dr.DonationID = Convert.ToInt32(txtdonationid.Text);
            dr.firstname = txtfirstname.Text;
            dr.lastname = txtlastname.Text;
            dr.HBcount = Convert.ToInt32(txthbcount.Text);
            dr.NoOfBottles = 1;
            dr.Weight = Convert.ToInt32(txtweight.Text);
            dr.Mobile = txtmobile.Text;
            dr.DonorID = Convert.ToInt32(txtdonorid.Text);
            bbl = new BloodBL();
            if (bbl.DonorDelete(dr))
                MessageBox.Show("Donor Details deleted");
            else
                MessageBox.Show("Failed to delete Donor");
        }


    }
}
