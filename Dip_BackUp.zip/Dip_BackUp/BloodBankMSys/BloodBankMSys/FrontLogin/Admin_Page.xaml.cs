﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;
using BBMS.BL;
using BBMS.Entities;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for Admin_Page.xaml
    /// </summary>
    public partial class Admin_Page : Window
    {
        
        BloodBL bl;
        public Admin_Page(string MyID)
        {
            
            InitializeComponent();
            
            lbladmin.Content = MyID;
        }

        private void btnHospital_Click(object sender, RoutedEventArgs e)
        {
            ////Button theButton = sender as Button;
            ////string url = theButton.Tag.ToString();

            ////this.Frame.Navigate(typeof(HospitalForAdmin), null);

            HospitalForAdmin hadmin = new HospitalForAdmin(lbladmin.Content.ToString()); //create your new form.
            hadmin.Show(); //show the new form.
            ////this.Close(); 
        }

        private void btnBB_Click(object sender, RoutedEventArgs e)
        {
            BloodBankForAdmin bbadmin = new BloodBankForAdmin();
            bbadmin.Show();
        }
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnHospitalView_Selected(object sender, RoutedEventArgs e)
        {
            bl = new BloodBL();
            List<Hospital> hop = new List<Hospital>();
            foreach (Hospital h in bl.GetHospDetails())
            {
                //if (h.Location != null && h.HospitalAddress != null && h.ContactNo != null && h.HospitalCity != null)
                hop.Add(h);
            }

            grdshowadmin.ItemsSource = hop;
        }

        private void btnBloodBanks_Selected(object sender, RoutedEventArgs e)
        {
            bl = new BloodBL();

            grdshowadmin.ItemsSource = bl.GetBankDetails();
        }

        private void btnCamps_Selected(object sender, RoutedEventArgs e)
        {
            bl = new BloodBL();
            grdshowadmin.ItemsSource = bl.GetDonationCampDetails();
        }

        private void btnDonors_Selected(object sender, RoutedEventArgs e)
        {
            bl = new BloodBL();
            grdshowadmin.ItemsSource = bl.GetDonorDetails();
        }

        private void btnInventory_Selected(object sender, RoutedEventArgs e)
        {
            bl = new BloodBL();
            grdshowadmin.ItemsSource = bl.GetInventoryDetails();
        }
    }
    
}
