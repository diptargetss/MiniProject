﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace GuestBookDemo.Models
{
    public class Guest
    {
        [Required(ErrorMessage="No is Required")]
        [RegularExpression(@"^\d{3}$",ErrorMessage="Only Three Digits are allowed")]
        public int GuestNo { get; set; }
        [Required(ErrorMessage = "Name is Required")]
        public string GuestName { get; set; }
        [Required(ErrorMessage = "Phone Number is Required")]
        [StringLength(10,ErrorMessage="Only 10 Characters allowed")]
        public string GuestPhoneNumber { get; set; }
    }

    public class GuestService
    {
        private static List<Guest> guestList = null;

        static GuestService()
        {
            guestList = new List<Guest>();

            guestList.Add(new Guest { GuestNo = 101, GuestName = "Ayushi", GuestPhoneNumber = "7894561230" });
            guestList.Add(new Guest { GuestNo = 102, GuestName = "Divayni", GuestPhoneNumber = "7894561230" });
            guestList.Add(new Guest { GuestNo = 103, GuestName = "Aditi", GuestPhoneNumber = "7894561230" });
            guestList.Add(new Guest { GuestNo = 104, GuestName = "Mandvi", GuestPhoneNumber = "7894561230" });
            guestList.Add(new Guest { GuestNo = 105, GuestName = "Pramesha", GuestPhoneNumber = "7894561230" });
        }

        public List<Guest> GetAllList()
        {
            return guestList;
        }

        public bool AddGuest(Guest newGuest)
        {
            bool guestAdded = false;

            int oldcount = guestList.Count;
            guestList.Add(newGuest);

            if (guestList.Count > oldcount)
                guestAdded = true;
            
            return guestAdded;
        }

        public Guest UpdateGuest(Guest updateGuest)
        {
            Guest guest = ShowGuest(updateGuest.GuestNo);//guestList.First(g => g.GuestNo == updateGuest.GuestNo);
            guest.GuestName = updateGuest.GuestName;
            guest.GuestPhoneNumber = updateGuest.GuestPhoneNumber;
            return guest;
        }

        public Guest ShowGuest(int guestNumber)
        {
            return guestList.First(guest => guest.GuestNo == guestNumber);
        }

        public bool RemoveGuest(int guestNumber)
        {
            Guest guest = ShowGuest(guestNumber);
            return guestList.Remove(guest);
        }
    }
}