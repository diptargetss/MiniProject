﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GuestBookDemo.Models;

namespace GuestBookDemo.Controllers
{
    public class GuestController : Controller
    {
        //
        // GET: /Guest/
        public ActionResult Index()
        {
            var guestDetails = new GuestService();
            var guests = guestDetails.GetAllList();
            return View(guests);
        }

        public ActionResult Create()
        {
            return View(new Guest());
        }

        public ActionResult Update(int guestNumber)
        {
            GuestService gs = new GuestService();
            Guest guest = gs.ShowGuest(guestNumber);
            return View(guest);
        }

        public ActionResult Delete(int guestNumber)
        {
            GuestService gs = new GuestService();
            Guest guest = gs.ShowGuest(guestNumber);
            return View(guest);
        }

        public ActionResult Details(int guestNumber)
        {
            GuestService gs = new GuestService();
            Guest guest = gs.ShowGuest(guestNumber);
            return View(guest);
        }

        [HttpPost]
        public ActionResult Create(Guest newGuest)
        {
            if(ModelState.IsValid)
            {
                GuestService gs = new GuestService();
                gs.AddGuest(newGuest);
                return RedirectToAction("Index");
            }
            else
            {
                return View(newGuest);
            }
        }

        [HttpPost]
        public ActionResult Update(int guestNumber, FormCollection collection)
        {
            Guest updateGuest = null;
            try
            {
                updateGuest = new Guest();
                updateGuest.GuestNo = guestNumber;
                updateGuest.GuestName = collection["GuestName"];
                updateGuest.GuestPhoneNumber = collection["GuestPhoneNumber"];
                GuestService gs = new GuestService();
                gs.UpdateGuest(updateGuest);
                return RedirectToAction("Index");
            }

            catch
            {
                return View(updateGuest);
            }
        }

        [HttpPost]
        public ActionResult Delete(int guestNumber, FormCollection collection)
        {
            Guest deleteGuest = null;
            try
            {
                deleteGuest = new Guest();
                deleteGuest.GuestName = collection["GuestName"];
                deleteGuest.GuestPhoneNumber = collection["GuestPhoneNumber"];
                GuestService gs = new GuestService();
                gs.RemoveGuest(guestNumber);
                return RedirectToAction("Index");
            }

            catch
            {
                return View(deleteGuest);
            }
        }
	}
}