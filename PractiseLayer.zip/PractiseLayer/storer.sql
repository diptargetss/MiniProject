create proc usp_productadder @id int,@name varchar(20),@price float
as
insert into ProductASP values(@id,@name,@price)
go

