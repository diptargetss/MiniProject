﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Prexceptions;
using PracEntities;

namespace ProductDAL
{
    public class ProDAL
    {
        
        public List<Product> Show()
        {
            List<Product> ProList = new List<Product>();
            string cs = ConfigurationManager.ConnectionStrings["dbstring"].ConnectionString.ToString();
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            string query="exec usp_productasp";
            cmd.Connection = con;
            cmd.CommandText =query ;
            //cmd.Parameters.Add(new SqlParameter("@n", txtSname.Text));
            //cmd.Parameters.Add(new SqlParameter("@c", txtCourse.Text));
            //con.Open();
            //SqlDataReader dr = new SqlDataReader(); 
            //dr=cmd.ExecuteReader();
            //con.Close();
            //MessageBox.Show("Saved Succes...");
            SqlDataAdapter adp = new SqlDataAdapter();
            adp.SelectCommand=cmd;
            SqlCommandBuilder builder = new SqlCommandBuilder(adp);
            DataTable dt= new DataTable();
            adp.Fill(dt);

            foreach (DataRow rw in dt.Rows)
            {
                
            
                Product gObj = new Product();
                gObj.Productid = Convert.ToInt32(rw[0]);
                gObj.Productname = rw[1].ToString();
                gObj.Price = Convert.ToInt32(rw[2]);
                ProList.Add(gObj);
            }
            return ProList;
        }
        public bool AdminCheck(string uname,string password)
        {
            bool ch = false;
            string cs = ConfigurationManager.ConnectionStrings["dbstring"].ConnectionString.ToString();
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            string query = "select * from logrights";
            cmd.Connection = con;
            cmd.CommandText = query;
            //cmd.Parameters.Add(new SqlParameter("@n", txtSname.Text));
            //cmd.Parameters.Add(new SqlParameter("@c", txtCourse.Text));
            //con.Open();
            //SqlDataReader dr = new SqlDataReader(); 
            //dr=cmd.ExecuteReader();
            //con.Close();
            //MessageBox.Show("Saved Succes...");
            SqlDataAdapter adp = new SqlDataAdapter();
            adp.SelectCommand = cmd;
            SqlCommandBuilder builder = new SqlCommandBuilder(adp);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            foreach (DataRow drow in dt.Rows)
            {
                if (uname == drow[0].ToString() && password == drow[1].ToString())
                    ch = true;
                
            }
            return ch;

        }

        public bool AddProduct(Product prd)
        {
            bool ch = false;
            string cs = ConfigurationManager.ConnectionStrings["dbstring"].ConnectionString.ToString();
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            string query = "exec usp_productadder";
            cmd.Connection = con;
            cmd.CommandText = query;
            //SqlDataAdapter adp = new SqlDataAdapter();
            //adp.InsertCommand= cmd;
            //SqlCommandBuilder builder = new SqlCommandBuilder(adp);
            //DataTable dt = new DataTable();
            //adp.Fill(dt);
        }
        

    }
}
