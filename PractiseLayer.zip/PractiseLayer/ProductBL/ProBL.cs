﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductDAL;
using PracEntities;
using Prexceptions;
using System.Text.RegularExpressions;

namespace ProductBL
{
    public class ProBL
    {
        ProDAL pd = null;
        public ProBL()
        {
            pd=new ProDAL();
        }
        public List<Product> Show()
        {
            return pd.Show();
        }
        public bool AdminCheck(string uname,string password)
        {
            return pd.AdminCheck(uname, password);
        }
        public bool validate(Product prd)
        {
            bool flag = true;
            if (prd.Productname == "")
                flag = false;
            var rex = new Regex("[0-9]{6}");
            if (!rex.IsMatch(prd.Productid.ToString()))
                flag = false;
            if (prd.Price == null || prd.Price <= 0)
                flag = false;
            return flag;

         }
        public bool AddProduct(Product prd)
        {
            if (!validate(prd))
                return false;
            else
                pd.AddProduct(prd);
        }

    }
}
