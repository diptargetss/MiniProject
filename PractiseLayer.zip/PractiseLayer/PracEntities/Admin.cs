﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracEntities
{
    public class Admin
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
