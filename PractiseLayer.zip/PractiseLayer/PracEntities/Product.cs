﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracEntities
{
    public class Product
    {
        public string Productname { get; set; }
        public int Productid { get; set; }
        public float Price { get; set; }
    }
}
