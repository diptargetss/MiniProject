﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prexceptions
{
    public class proexception:ApplicationException
    {
        public proexception():base()
        {

        }
        public proexception(string message):base(message)
        {

        }
    }
}
