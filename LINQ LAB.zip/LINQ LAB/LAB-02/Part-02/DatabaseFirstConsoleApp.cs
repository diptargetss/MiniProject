﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_02
{
    class DatabaseFirstConsoleApp
    {
        static void Main(string[] args)
        {
            Mumbai13TrainingEntities obj = new Mumbai13TrainingEntities();
            ALBUM o = new ALBUM();
            Console.WriteLine("Album ID: ");
            o.AlbumID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Album Name");
            o.Name = Console.ReadLine();
            Console.WriteLine("Album Genre");
            o.Genre = Console.ReadLine();
            Console.WriteLine("Year (YYYY/MM/DD)");
            o.AYear = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Price");
            o.Price = Convert.ToDecimal(Console.ReadLine());

            obj.ALBUMs.Add(o);
            obj.SaveChanges();//

            var query = from d in obj.ALBUMs select d;

            foreach (var item in query)//
            {
                Console.WriteLine(item.AlbumID);
                Console.WriteLine(item.Name);
                Console.WriteLine(item.AYear);
                Console.WriteLine(item.Genre);
                Console.WriteLine(item.Price);
            }

            Console.ReadLine();
        }
    }
}
