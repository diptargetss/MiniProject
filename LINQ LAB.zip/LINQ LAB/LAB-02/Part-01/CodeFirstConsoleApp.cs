﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_01
{
    class CodeFirstConsoleApp
    {
        static void Main(string[] args)
        {
            using (var db = new ProductContext())
            {
                //Creating and saving a new Product
                Console.Write("Enter Product Name: ");
                var n = Console.ReadLine();
                Console.Write("Enter Product ID: ");
                var i = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Product Type: ");
                var t = Console.ReadLine();

                var prod = new Product { ProductID = i, ProductName = n, ProductType = t};
                db.Prod.Add(prod);
                db.SaveChanges();

                // Display all products from the database
                var query = from b in db.Prod
                            orderby b.ProductID
                            select b;

                Console.WriteLine("All Products in the database:");
                foreach (var item in query)
                {
                    Console.WriteLine(item.ProductID+"\t"+item.ProductName+"\t"+item.ProductType);
                }

                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }
        }
    }
}
