﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_01
{
    public class Product
    {
        int productID;
        string productName;
        string productType;

        public string ProductType
        {
            get { return productType; }
            set { productType = value; }
        }

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }

        public int ProductID
        {
            get { return productID; }
            set { productID = value; }
        }
    }
}
