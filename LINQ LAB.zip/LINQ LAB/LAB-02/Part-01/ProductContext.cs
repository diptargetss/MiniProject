﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;//For DbContext Class

namespace Part_01
{
    class ProductContext: DbContext
    {
        //public ProductContext(): base("name=Cs")
        //{

        //}
        public DbSet<Product> Prod { get; set; }//virtual Keyword Missing -- Performance
    }
}
