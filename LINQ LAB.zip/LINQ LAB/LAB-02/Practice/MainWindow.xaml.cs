﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnshow_Click(object sender, RoutedEventArgs e)
        {
            Mumbai13TrainingEntities obj = new Mumbai13TrainingEntities();
            dgv.ItemsSource = obj.ALBUMs.ToList();
        }

        private void btnsave_Click(object sender, RoutedEventArgs e)
        {
            Mumbai13TrainingEntities obj = new Mumbai13TrainingEntities();

            ALBUM o = new ALBUM();

            o.AlbumID = Convert.ToInt32(textid.Text);
            o.Name = textname.Text;
            o.Genre = textgenre.Text;
            o.Price = Convert.ToDecimal(textprice.Text);
            o.AYear = Convert.ToDateTime(textyear.Text);

            obj.ALBUMs.Add(o);
            obj.SaveChanges();

            btnshow_Click(sender, e);
        }

    }
}
