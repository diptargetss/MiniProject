﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practice
{
    /// <summary>
    /// Interaction logic for DFCApp.xaml
    /// </summary>
    public partial class DFCApp : UserControl
    {
        public DFCApp()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
            Mumbai13TrainingEntities obj = new Mumbai13TrainingEntities();

            //Q-1
            //var query = from d in obj.ALBUMs where d.Name=="Rajat" select d;

            //Q-2
            var query = from d in obj.ALBUMs where d.Price > 500 select d;

            dgv.ItemsSource = query.ToList();

            //dgv.ItemsSource = obj.ALBUMs.ToList();
        }
    }
}
