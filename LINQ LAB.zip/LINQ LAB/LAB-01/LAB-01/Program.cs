﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_01
{
    class Program
    {
        static void Main(string[] args)
        {
            //EmployeeID (Integer)
            //FirstName (String)
            //LastName (String)
            //Title (String)
            //DOB (Date)
            //DOJ (Date)
            //City (String)
            List<Employee> empList = new List<Employee>();

            empList.Add(new Employee { EmployeeID = 1001, FirstName = "Malcolm", LastName = "Daruwalla", Title = "Manager", DOB = DateTime.Parse("11/16/1984"), DOJ = DateTime.Parse("6/8/2011"), City = "Mumbai" });
            empList.Add(new Employee { EmployeeID = 1002, FirstName = "Asdin", LastName = "Dhalla", Title = "AsstManager", DOB = DateTime.Parse("08/20/1984"), DOJ = DateTime.Parse("7/7/2012"), City = "Mumbai" });
            empList.Add(new Employee { EmployeeID = 1003, FirstName = "Madhavi", LastName = "Oza", Title = "Consultant", DOB = DateTime.Parse("11/14/1987"), DOJ = DateTime.Parse("4/12/2015"), City = "Pune" });
            empList.Add(new Employee { EmployeeID = 1004, FirstName = "Saba", LastName = "Shaikh", Title = "SE", DOB = DateTime.Parse("6/3/1990"), DOJ = DateTime.Parse("2/2/2016"), City = "Pune" });
            empList.Add(new Employee { EmployeeID = 1005, FirstName = "Nazia", LastName = "Shaikh", Title = "SE", DOB = DateTime.Parse("3/8/1991"), DOJ = DateTime.Parse("2/2/2016"), City = "Mumbai" });
            empList.Add(new Employee { EmployeeID = 1006, FirstName = "Amit", LastName = "Pathak", Title = "Consultant", DOB = DateTime.Parse("11/7/1989"), DOJ = DateTime.Parse("8/8/2014"), City = "Chennai" });
            empList.Add(new Employee { EmployeeID = 1007, FirstName = "Vijay", LastName = "Natrajan", Title = "Consultant", DOB = DateTime.Parse("12/2/1989"), DOJ = DateTime.Parse("6/1/2015"), City = "Mumbai" });
            empList.Add(new Employee { EmployeeID = 1008, FirstName = "Rahul", LastName = "Dubey", Title = "Associate", DOB = DateTime.Parse("11/11/1993"), DOJ = DateTime.Parse("6/11/2014"), City = "Chennai" });
            empList.Add(new Employee { EmployeeID = 1009, FirstName = "Suresh", LastName = "Mistry", Title = "Associate", DOB = DateTime.Parse("8/12/1992"), DOJ = DateTime.Parse("12/3/2014"), City = "Chennai" });
            empList.Add(new Employee { EmployeeID = 1010, FirstName = "Sumit", LastName = "Shah", Title = "Manager", DOB = DateTime.Parse("4/12/1991"), DOJ = DateTime.Parse("1/2/2016"), City = "Pune" });


            //i) Display detail of all the employee
            //First Query
            //var query1 = from e in empList select e;

            //Console.WriteLine("ID  \tFirst Name\tLast Name\tTitle\tDOB\tDOJ\tCity");
            //foreach (var item in query1)
            //{
            //    Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}", item.EmployeeID, item.FirstName, item.LastName, item.Title, item.DOB, item.DOJ, item.City);
            //}


            //ii) Display details of all the employee whose location is not Mumbai
            //Second Query
            //var query2 = from e in empList where e.City !="Mumbai" select e;

            //foreach (var item in query2)
            //{
            //    Console.WriteLine(item.FirstName);
            //}


            //iii) Display details of all the employee whose title is AsstManager
            //Third Query
            //var query3 = from e in empList where e.Title == "AsstManager" select e;

            //foreach (var item in query3)
            //{
            //    Console.WriteLine(item.FirstName);
            //}


            //iv) Display details of all the employee whose Last Name start with S
            //Fourth Query
            //var query4 = from e in empList where e.LastName.StartsWith("S") select e;

            //foreach (var item in query4)
            //{
            //    Console.WriteLine(item.FirstName);
            //}


            //v) Display a list of all the employee who have joined before 1/1/2015
            //Fifth Query

            //DateTime d = DateTime.Parse("1/1/2015");
            //var query5 = from e in empList where e.DOJ.Date < d.Date select e;

            //foreach (var item in query5)
            //{
            //    Console.WriteLine(item.FirstName);
            //}

            //vi) Display a list of all the employee whose date of birth is after 1/1/19
            //Sixth Query
            //DateTime d = DateTime.Parse("1/1/1990");
            //var query6 = from e in empList where e.DOB.Date > d.Date select e;

            //foreach (var item in query6)
            //{
            //    Console.WriteLine(item.FirstName);
            //}

            //vii) Display a list of all the employee whose designation is Consultant and Associate
            //Seventh Query
            //var query7 = from e in empList where e.Title == "Consultant" || e.Title == "Associate" select e;

            //foreach (var item in query7)
            //{
            //    Console.WriteLine(item.FirstName);
            //}

            //viii) Display total number of employees

            //var query8 = from e in empList select e;
            //Console.WriteLine(query8.Count());

            //ix) Display total number of employees belonging to “Chennai”

            //var query9 = from e in empList where e.City == "Chennai" select e;
            //Console.WriteLine(query9.Count());


            //x) Display highest employee id from the list

            //var query10 = from e in empList select e.EmployeeID;
            //Console.WriteLine("Employee ID: {0}", query10.Max());

            //xi) Display total number of employee who have joined after 1/1/2015

            //DateTime d = DateTime.Parse("1/1/2015");
            //var query11 = from e in empList where e.DOJ.Date >d.Date select e;

            //Console.WriteLine(query11.Count());


            //xii) Display total number of employee whose designation is not “Associate”

            //var query12 = from e in empList where e.Title != "Associate" select e;
            //Console.WriteLine(query12.Count());


            //xiii) Display total number of employee based on City

            //var query13 = from e in empList group e by e.City;
            //foreach (var item in query13)
            //{
            //    Console.WriteLine(item.Count());
            //}


            //xiv) Display total number of employee based on city and title

            //var query14 = from e in empList group e by new { e.Title, e.City };
            //foreach (var item in query14)
            //{
            //    Console.WriteLine(item.Count());
            //}

            //xv) Display total number of employee who is youngest in the list

            //var query15 = (from e in empList select new { e.EmployeeID, e.DOB }).Min();

            //Console.WriteLine(query15);

            //foreach (var item in query15)
            //{
            //    Console.WriteLine(item);
            //}
            

            Console.ReadLine();
        }
    }
}
