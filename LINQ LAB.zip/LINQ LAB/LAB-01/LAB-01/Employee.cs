﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_01
{
    public class Employee
    {
        //EmployeeID (Integer)
        //FirstName (String)
        //LastName (String)
        //Title (String)
        //DOB (Date)
        //DOJ (Date)
        //City (String)
        #region Fields
        int employeeID;
        string firstName;
        string lastName;
        string title;
        DateTime dOB;
        DateTime dOJ;
        string city;
        #endregion

        #region Properties
        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public DateTime DOJ
        {
            get { return dOJ; }
            set { dOJ = value; }
        }

        public DateTime DOB
        {
            get { return dOB; }
            set { dOB = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public int EmployeeID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }
        #endregion





    }
}
