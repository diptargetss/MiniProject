--stored procedure for showing inventory details
go
create procedure inventory_show
as
begin
select * from BBMS.BloodInventory
end
go

drop proc inventory_show
exec inventory_show
--stored procedure for showing donor details


go
create procedure donor_show
as
begin
select * from BBMS.BloodDonor
end
go

drop proc donor_show



go
create procedure camp_show
as
begin
select * from BBMS.BloodDonationCamp
end
go

drop proc camp_show
exec camp_show