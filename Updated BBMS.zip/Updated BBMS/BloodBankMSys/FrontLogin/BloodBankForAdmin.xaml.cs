﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.BL;
using BBMS.Entities;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for BloodBankForAdmin1.xaml
    /// </summary>
    public partial class BloodBankForAdmin : Window
    {
        public BloodBankForAdmin()
        {
            InitializeComponent();
        }
        BloodBL bbl = null;

        private void btnaddbb_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtbbidadd.Text);
            string bname = txtbbnameadd.Text;
            bbl = new BloodBL();
            if (bbl.AddBankIdName(id, bname))
                MessageBox.Show("Blood Bank added successfully");
            else
                MessageBox.Show("Adding Blood Bank failed");
        }

        private void btndelbb_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtbbidview.Text);
            bbl = new BloodBL();
            if (bbl.DelBankDetails(id))
                MessageBox.Show("Blood bank deleted successfully");
            else
                MessageBox.Show("Failed blood bank deletion");
        }

        private void btnmodbb_Click(object sender, RoutedEventArgs e)
        {
            BloodBank bk = new BloodBank();
            bk.BloodBankId = Convert.ToInt32(txtbbidview.Text);
            bk.Baddress = txtaddress.Text;
            bk.BloodBankCity = txtcity.Text;
            bk.BRegion = txtregion.Text;
            bk.BloodBankMobNo = txtcontact.Text;
            bk.BloodBankname = txtbbname.Text;
            if (bbl.UpdateBankDetails(bk))
                MessageBox.Show("Updated successfully");
            else
                MessageBox.Show("Failed to Update");
        }

        private void btnbbview_Click(object sender, RoutedEventArgs e)
        {
            bbl = new BloodBL();

        }



    }
}
