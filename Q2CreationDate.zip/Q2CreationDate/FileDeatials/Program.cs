﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileDeatials
{
    class Program
    {
        static void Main(string[] args)
        {
            FileInfo file = new FileInfo(@"P:\Siddhartha Pramanik - UID 142412\Module 2\C-Sharp\serialization.cs");
            var creationTime = file.CreationTime;
            var lastModified = file.LastWriteTime;
            var dirName = file.DirectoryName;
            var lastAccess = file.LastAccessTime;
            var size = file.Length;

            Console.WriteLine("Creation time : {0}\nLast Modified : {1}\nDirectory Name : {2}\nLast Access Time : {3}\nSize : {4} Bytes", creationTime, lastModified, dirName, lastAccess, size);
        }
    }
}
