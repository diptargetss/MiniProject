﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.Exceptions;
using BBMS.Entity;


namespace BBMS.DAL
{
    public class AdminReportDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        public List<Hospitals> GetHospitalDetails()
        {
            List<Hospitals> hospdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_showall";
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                hospdetails = new List<Hospitals>();
                while (dr.Read())
                {
                    Hospitals entity = new Hospitals();
                    entity.Hospitalid = dr.GetInt32(0);
                    entity.Hospitalname = dr.GetString(1);
                    entity.HospitalAddress = dr.GetString(2);
                    entity.HospitalCity = dr.GetString(3);
                    entity.Location = dr.GetString(4);
                    entity.ContactNo = dr.GetString(5);
                    hospdetails.Add(entity);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return hospdetails;
        }
        public List<Bloodbank> GetBankDetails()
        {
            List<Bloodbank> BBlist = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_show";
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                BBlist = new List<Bloodbank>();
                while (dr.Read())
                {
                    Bloodbank entity = new Bloodbank();
                    entity.BloodBankId = dr.GetInt32(0);
                    entity.BloodBankname = dr.GetString(1);
                    entity.Baddress = dr.GetString(2);
                    entity.BRegion = dr.GetString(3);
                    entity.BloodBankCity = dr.GetString(4);
                    entity.BloodBankMobNo = dr.GetString(5);
                    BBlist.Add(entity);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return BBlist;
        }
        public List<Donor> GetDonorDetails()
        {
            List<Donor> donordetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "donor_show";
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                donordetails = new List<Donor>();
                while (dr.Read())
                {
                    Donor entity = new Donor();
                    entity.DonorID = dr.GetInt32(0);
                    entity.firstname = dr.GetString(1);
                    entity.lastname = dr.GetString(2);
                    entity.Address = dr.GetString(3);
                    entity.City = dr.GetString(4);
                    entity.Mobile = dr.GetString(5);
                    entity.BloodGroup = dr.GetString(6);
                    donordetails.Add(entity);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return donordetails;
        }
        public List<BloodCamp> GetCampDetails()
        {
            List<BloodCamp> campdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "camp_show";
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                campdetails = new List<BloodCamp>();
                while (dr.Read())
                {
                    BloodCamp entity = new BloodCamp();
                    entity.CampID = dr.GetInt32(0);
                    entity.Name = dr.GetString(1);
                    entity.Address = dr.GetString(2);
                    entity.City = dr.GetString(3);
                    entity.StartDate = dr.GetDateTime(4);
                    entity.EndDate = dr.GetDateTime(5);
                    entity.BloodBankId = dr.GetInt32(6);
                    campdetails.Add(entity);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return campdetails;
        }
        public List<BloodInventory> GetInventoryDetails()
        {
            List<BloodInventory> invdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "inventory_show";
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                invdetails = new List<BloodInventory>();
                while (dr.Read())
                {
                    BloodInventory entity = new BloodInventory();
                    entity.BloodInventoryId = dr.GetInt32(0);
                    entity.BloodGroup = dr.GetString(1);
                    entity.NumOfBottles = dr.GetInt32(2);
                    entity.BloodBankId = dr.GetInt32(3);
                    entity.ExpDate = dr.GetDateTime(4);
                    invdetails.Add(entity);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return invdetails;
        }
    }
}
