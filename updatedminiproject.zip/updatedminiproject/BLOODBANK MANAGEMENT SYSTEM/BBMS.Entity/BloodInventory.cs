﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Entity
{
    public class BloodInventory
    {
        public int BloodInventoryId { get; set; }
        public string BloodGroup { get; set; }
        public int NumOfBottles { get; set; }
        public int BloodBankId { get; set; }
        public DateTime ExpDate { get; set; }
    }
}
