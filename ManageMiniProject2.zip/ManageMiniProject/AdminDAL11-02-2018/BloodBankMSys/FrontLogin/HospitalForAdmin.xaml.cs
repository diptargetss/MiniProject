﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.BL;
using BBMS.Entities;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for HospitalForAdmin1.xaml
    /// </summary>
    public partial class HospitalForAdmin : Window
    {
        public HospitalForAdmin()
        {
            InitializeComponent();
        }
        BloodBL bbl = null;
        private void btnviewhosp_Click(object sender, RoutedEventArgs e)
        {
            bbl = new BloodBL();
            int id = Convert.ToInt32(txthospidview.Text);
            Hospital hh = bbl.GetHospDetailsById(id);
            if (hh == null)
                MessageBox.Show("No Hospital found with that id");
            else
            {
                txtaddress.Text = hh.HospitalAddress;
                txthosname.Text = hh.Hospitalname;
                txtcity.Text = hh.HospitalCity;
                txtcontact.Text = hh.ContactNo;
                txtregion.Text = hh.Location;
            }
        }

        private void btnaddhosp_Click(object sender, RoutedEventArgs e)
        {
            string id = txthospidadd.Text;
            string hname = txthospnameadd.Text;
            
             bbl = new BloodBL();
             if (hname ==string.Empty)
                 MessageBox.Show("Name cannot be null");
             else
             {
                 if (bbl.AddHospital(id, hname))
                     MessageBox.Show("Hospital added successfully");
                 else
                     MessageBox.Show("Add hospital failed");
             }
        }

        private void btnmodhosp_Click(object sender, RoutedEventArgs e)
        {
            Hospital hos = new Hospital();
            hos.HospitalId = Convert.ToInt32(txthospidview.Text);
            hos.HospitalCity = txtcity.Text;
            hos.HospitalAddress = txtaddress.Text;
            hos.Hospitalname = txthosname.Text;
            hos.Location = txtregion.Text;
            hos.ContactNo = txtcontact.Text;
            bbl = new BloodBL();
            if (hos.HospitalAddress == "" || hos.HospitalCity == "" || hos.Hospitalname == "" ||
                hos.Location == "")
                MessageBox.Show("Values cannot be null");
            else
            {
                if (bbl.UpdateHospitalDetails(hos))
                    MessageBox.Show("Hospital updated successfully");
                else
                    MessageBox.Show("Update hospital failed");
            }
        }

        private void btndelhosp_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txthospidview.Text);
            bbl = new BloodBL();
            if (bbl.DelHospitalDetails(id))
                MessageBox.Show("Hospital deleted successfully");
            else
                MessageBox.Show("Delete hospital failed");
        }
    }
}
