﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace BloodBankRegistration.Dal
{
    public class BloodbankRegistration
    {
        SqlConnection con =new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public bool CheckAvailability(string buserid)
        {
            bool valid=false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_checkavailbankuser";
                cmd.Parameters.AddWithValue("@bbuser", buserid);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    valid=true;
                }
            }
            catch(SqlException s)
            {
                con.Close();
                throw s;
            }
            catch(Exception v)
            {
                con.Close();
                throw v;
            }
            return valid;
        }
        public bool RegisterBloodBank(BloodBank bb)
        {
            bool added = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_bloodbankreg";
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankId);
                cmd.Parameters.AddWithValue("@bname", bb.Baddress);
                cmd.Parameters.AddWithValue("@bname", bb.BRegion);
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankCity);
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankMobNo);
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankUserId);
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankPwd);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    added = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return added;
        }
    }
}
