﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using BBMS.Entities;
using BBMS.Exceptions;


namespace BBDAL
{
    public class InventoryDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public bool DeleteExp(BloodInventory bi)
        {
            bool delete = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "inventory_delexp";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@id",bi);

                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                {
                    delete = true;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return delete;
        }

        public bool UpdateInventory(BloodInventory bi)
        {
            bool updated = false;
            int res=0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "inventory_upd";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@", bi);
                cmd.Parameters.AddWithValue("@", bi);
                cmd.Parameters.AddWithValue("@", bi);
                cmd.Parameters.AddWithValue("@", bi);
                con.Open();
                
                for (int i = 0; i < bi.NumOfBottles; i++)
                {
                    res = 2;//cmd.ExecuteNonQuery();
                }
                con.Close();
                if (res > 0)
                    updated = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return updated;
        }
        public bool StockTransfer(BloodInventory bi)
        {
            bool added = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_stocktransfer";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@id", bi);
                cmd.Parameters.AddWithValue("@name", bi);
                cmd.Parameters.AddWithValue("@group", bi);
                cmd.Parameters.AddWithValue("@quantity", bi);
                cmd.Parameters.AddWithValue("@date", bi);
                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                    added = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return added;
        }
    }
}
