﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.BL;
using BBMS.Entities;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for BloodRequestPage.xaml
    /// </summary>
    public partial class BloodRequestPage : Window
    {
        public BloodRequestPage()
        {
            InitializeComponent();
        }

        private void btnsubmit1_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                BloodRequest brq = new BloodRequest();
                brq.BloodGroup = Combo11.SelectedItem.ToString();
                brq.HospAddress = txtAddress.Text;
                brq.HospCity = txtcityy.Text;
                brq.HospitalId = Convert.ToInt32(txtID.Text);
                brq.ReqDate = Convert.ToDateTime(txtdatee.SelectedDate);
                brq.NoOfPackets = Convert.ToInt32(txtpackets1.Text);
                brq.HospitalName = txtName.Text;
                brq.HospRegion = txtregionn.Text;
                BloodBL bbl = new BloodBL();
                if (bbl.AddRequest(brq))
                {
                    MessageBox.Show("Request Placed");
                }
                else
                    MessageBox.Show("Failed to Place Request");
            }
            catch (BloodException be)
            {
                MessageBox.Show(be.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        
    }
}
