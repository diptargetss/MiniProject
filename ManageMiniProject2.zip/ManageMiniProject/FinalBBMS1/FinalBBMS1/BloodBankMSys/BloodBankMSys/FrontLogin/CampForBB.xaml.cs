﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.Entities;
using BBMS.Exceptions;
using BBMS.BL;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for CampForBB.xaml
    /// </summary>
    public partial class CampForBB : Window
    {
        int bbid;
        public CampForBB(int id)
        {
            InitializeComponent();
            bbid = id;
        }
        CampBL cb = new CampBL();
        private void btnviewcamp_Click(object sender, RoutedEventArgs e)
        {
           
            int id = Convert.ToInt32(txtcampid.Text);
            BloodCamp hh = cb.GetCampDetailsById(id);
            if (hh == null)
                MessageBox.Show("No Camp found with that id");
            else
            {
                txtbbname.Text = hh.BloodBankName;
                txtcampname.Text = hh.Name;
                txtvenue.Text = hh.Address;
                dpstart.DisplayDate = hh.StartDate;
                dpend.DisplayDate = hh.EndDate;
                
                    

            }
        }

        private void btncreatecamp_Click(object sender, RoutedEventArgs e)
        {
            BloodCamp bc = new BloodCamp();
            bc.CampID = Convert.ToInt32(txtcampid.Text);
            bc.Name = txtcampname.Text;
            bc.BloodBankName = txtbbname.Text;
            bc.Address = txtvenue.Text;
            bc.EndDate = Convert.ToDateTime(dpend.SelectedDate);
            bc.StartDate = Convert.ToDateTime(dpstart.SelectedDate);

            
            
            try
            {


                if (cb.AddCamp(bc))
                    MessageBox.Show("Camp added successfully");
                else
                    MessageBox.Show("Adding Camp failed");
            }
            catch (BloodException be)
            {
                MessageBox.Show(be.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnmodcamp_Click(object sender, RoutedEventArgs e)
        {
            BloodCamp cp = new BloodCamp();
            cp.CampID = Convert.ToInt32(txtcampid.Text);
            cp.Address = txtvenue.Text;
            cp.BloodBankName = txtbbname.Text;
            cp.StartDate = Convert.ToDateTime(dpstart.SelectedDate);
            cp.Name = txtcampname.Text;
            cp.EndDate = Convert.ToDateTime(dpend.SelectedDate);
            try
            {
                if (cb.ModifyCampDetails(cp))
                    MessageBox.Show("Hospital updated successfully");
                else
                    MessageBox.Show("Update hospital failed");
            }
            catch (BloodException be)
            {
                MessageBox.Show(be.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        
    }
}
