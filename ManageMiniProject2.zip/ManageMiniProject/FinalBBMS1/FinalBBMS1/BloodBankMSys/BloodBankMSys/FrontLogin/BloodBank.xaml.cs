﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.Entities;
using BBMS.Exceptions;
using BBMS.BL;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for BloodBank.xaml
    /// </summary>
    public partial class BloodBank : Window
    {
        public int BloodBankID;
        public BloodBank(int id)
        {
            InitializeComponent();
            BloodBankID = id;
        }



        private void btnBBCamp_Click(object sender, RoutedEventArgs e)
        {
            CampForBB campbb = new CampForBB(BloodBankID);
            campbb.Show();
        }

        private void btnBBDetails_Click(object sender, RoutedEventArgs e)
        {
            BBDetailsForBB bbdetails = new BBDetailsForBB(BloodBankID);
            bbdetails.Show();
        }

        private void btnDonors_Click(object sender, RoutedEventArgs e)
        {
            DonarForm adddonor = new DonarForm(BloodBankID);
            adddonor.Show();
        }

        private void btnBBStock_Click(object sender, RoutedEventArgs e)
        {
            BBStock stock = new BBStock(BloodBankID);
            stock.Show();
        }

        private void DonorsView_Selected(object sender, RoutedEventArgs e)
        {
            BloodBL bbl = new BloodBL();
            grdshowforbank.ItemsSource = bbl.ShowDonors(BloodBankID);
        }

        private void BloodRequests_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void CampsView_Selected(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
