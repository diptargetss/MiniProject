﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.BL;
using BBMS.Entities;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for BBDetailsForBB.xaml
    /// </summary>
    public partial class BBDetailsForBB : Window
    {
        int bbid;
        public BBDetailsForBB(int id)
        {
            InitializeComponent();
            bbid = id;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            BankBL bbl = new BankBL();
            Bloodbank b = new Bloodbank();
            b.BloodBankId = bbid;
            b.BloodBankname = txtname.Text;
            b.BloodBankCity = txtcity.Text;
            b.Baddress = txtaddress.Text;
            b.BRegion = txtregion.Text;
            b.BloodBankMobNo = txtcontact.Text;
            try
            {
                bbl.UpdateBankDetails(b);
            }
            catch (BloodException be)
            {
                MessageBox.Show(be.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
