﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBDAL;
using BBMS.Entities;
using BBMS.Exceptions;
using System.Text.RegularExpressions;


namespace BBMS.BL
{
    public class HospitalBL
    {
        AdminHospital bbda = new AdminHospital();
        //var expr = new Regex("[0-9]");
        //For Adding Hospital
        public bool AddHospital(string id, string hname)
        {
            
            int i = Convert.ToInt32(id);
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (id == null || hname==string.Empty)
            {
                valid = false;
                sb.Append(" Values cannot be null ");
            }
            if (i < 100000||i>999999)
            {
                valid = false;
                sb.Append(" Enter valid ID of 6 digits ");
            }
            
            if (valid == false)
            {
                throw new BloodException(sb.ToString());
            }

                return bbda.AddHospIdName(i, hname);
        }


        //For Updating Hospital
        public bool UpdateHospitalDetails(Hospital hos)
        {
            bool valid = true;
            var expr = new Regex("[0-9]");
            StringBuilder sb = new StringBuilder();
            if (hos.HospitalAddress == "" || hos.HospitalCity == "" || hos.Hospitalname == "" ||
                hos.Location == "")
            {
                valid = false;
                sb.Append(" Values cannot be null ");
            }
            if (expr.IsMatch(hos.ContactNo)!=true)
            {
                valid = false;
                sb.Append(" Contact no should be all digits ");
            }
            if (valid == false)
            {
                throw new BloodException(sb.ToString());
            }

            return bbda.UpdateHospitalDetails(hos);
        }


        public bool DelHospitalDetails(int id)
        {
            return bbda.DelHospitalDetails(id);
        }

        public List<Hospital> GetHospDetails()
        {
            return bbda.GetHospDetails();
        }
        public Hospital GetHospDetailsById(int id)
        {
            
            return bbda.GetHospDetailsById(id);
        }
    }
}