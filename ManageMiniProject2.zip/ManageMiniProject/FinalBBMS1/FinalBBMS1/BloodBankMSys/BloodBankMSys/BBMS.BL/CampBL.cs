﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class CampBL
    {
        //Add Camp
        CampDAL bbda = new CampDAL();
        AdminBloodbank bbd = new AdminBloodbank();
        public bool AddCamp(BloodCamp bc)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (bc.Address == string.Empty || bc.BloodBankName == string.Empty || bc.City == string.Empty
                || bc.Name == string.Empty || bc.CampID == null||bc.StartDate==null||bc.EndDate==null)
            {
                valid = false;
                sb.Append(" Values cannot be null ");
            }
            
            if (bc.StartDate.CompareTo(DateTime.Now)<0)
            {
                valid = false;
                sb.Append(" Date already passed ");
            }
            if (bc.StartDate.CompareTo(bc.EndDate) < 0)
            {
                valid = false;
                sb.Append(" End Date cannot be greater than start date ");
            }

            if (bc.CampID < 100000||bc.CampID>999999)
            {
                valid = false;
                sb.Append(" Id length should be atleast 6 digits ");
            }

            if (valid == false)
            {
                throw new BloodException(sb.ToString());
            }

             return bbda.AddCampDetails(bc);
             
        }

        //Modify Camp
        public bool ModifyCampDetails(BloodCamp bc)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (bc.Address == string.Empty || bc.BloodBankName == string.Empty || bc.City == string.Empty
                || bc.Name == string.Empty || bc.CampID == null || bc.StartDate == null || bc.EndDate == null)
            {
                valid = false;
                sb.Append(" Values cannot be null ");
            }

            if (bc.StartDate.CompareTo(DateTime.Now) < 0)
            {
                valid = false;
                sb.Append(" Date already passed ");
            }
            if (bc.StartDate.CompareTo(bc.EndDate) < 0)
            {
                valid = false;
                sb.Append(" End Date cannot be greater than start date ");
            }

            if (bc.CampID < 100000 || bc.CampID > 999999)
            {
                valid = false;
                sb.Append(" Id length should be atleast 6 digits ");
            }

            if (valid == false)
            {
                throw new BloodException(sb.ToString());
            }

            return bbda.UpdateCampDetails(bc);

        }

        public BloodCamp GetCampDetailsById(int id)
        {
            return bbda.GetCampDetailsById(id);
        }
    }
}