﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBDAL;
using BBMS.Entities;
using BBMS.Exceptions;
using System.Text.RegularExpressions;

namespace BBMS.BL
{
    public class BankBL
    {
        BloodBankDA bbda = new BloodBankDA();
       

        AdminBloodbank bbd = new AdminBloodbank();
        public bool UpdateBankDetails(Bloodbank b)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (b.Baddress == string.Empty || b.BRegion == string.Empty || b.BloodBankCity == string.Empty || b.BloodBankMobNo == string.Empty
                ||b.BloodBankname==string.Empty)
            {
                valid = false;
                sb.Append(" Values cannot be null ");
            }
            var expr = new Regex("[0-9]");
            if (expr.IsMatch(b.BloodBankMobNo) != true)
            {
                valid = false;
                sb.Append(" Contact no can only be digits ");
            }
           

            if (valid == false)
            {
                throw new BloodException(sb.ToString());
            }

            return bbd.UpdateBankDetail(b);

        }
        public Bloodbank GetBankDetailsById(string id)
        {

            int i = Convert.ToInt32(id);

            return bbd.GetBankDetailsById(i);

        }

        public List<Bloodbank> ShowBanks()
        {
            return bbd.ShowBanks();
        }



        public bool AddBankIdName(int id, string bname)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (id==null || bname == string.Empty)
            {
                valid = false;
                sb.Append(" Values cannot be null ");
            }
            
            
            if (id < 100000 || id>999999)
            {
                valid = false;
                sb.Append(" ID should be atleast 6 digits ");
            }

            if (valid == false)
            {
                throw new BloodException(sb.ToString());
            }

            return bbd.AddBankIDName(id, bname);
        }

        public bool DelBankDetails(int id)
        {
            return bbd.DelBankDetails(id);
        }
    }
}
