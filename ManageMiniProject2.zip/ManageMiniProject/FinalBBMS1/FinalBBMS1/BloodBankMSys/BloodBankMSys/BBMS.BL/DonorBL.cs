﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;
using System.Text.RegularExpressions;

namespace BBMS.BL
{
    public class DonorBL
    {
        DonorDL bbda = new DonorDL();
        //Donor Add
        public bool DonorAdd(Donor d)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (d.Address == string.Empty || d.lastname == string.Empty || d.City == string.Empty||d.BloodBankID==null||d.BloodGroup==string.Empty
                || d.firstname == string.Empty || d.DonorID == null || d.DonationDate == null || d.Age == null||d.Weight==null
                ||d.DonationID==null||d.Mobile==string.Empty||d.HBcount==null)
            {
                valid = false;
                sb.Append(" Values cannot be null ");
            }

            if (d.Age < 14)
            {
                valid = false;
                sb.Append(" Invalid Age ");
            }
            if (d.Weight < 30)
            {
                valid = false;
                sb.Append(" Invalid Weight ");
            }

            if (d.DonorID < 100000 || d.DonorID > 999999 || d.DonationID < 100000 || d.DonationID > 999999
                || d.BloodBankID < 100000 || d.BloodBankID > 999999)
            {
                valid = false;
                sb.Append(" Id length should be atleast 6 digits ");
            }
            var expr = new Regex("[0-9]");
            if (expr.IsMatch(d.Mobile))
            {
                valid = false;
                sb.Append(" Phone number can only have digits ");
            }

            if (valid == false)
            {
                throw new BloodException(sb.ToString());
            }

            return bbda.AddDonor(d);
        }


        //Donor Update
        public bool DonorUpdate(Donor d)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (d.Address == string.Empty || d.lastname == string.Empty || d.City == string.Empty || d.BloodBankID == null || d.BloodGroup == string.Empty
                || d.firstname == string.Empty || d.DonorID == null || d.DonationDate == null || d.Age == null || d.Weight == null
                || d.DonationID == null || d.Mobile == string.Empty || d.HBcount == null)
            {
                valid = false;
                sb.Append(" Values cannot be null ");
            }

            if (d.Age < 14)
            {
                valid = false;
                sb.Append(" Invalid Age ");
            }
            if (d.Weight < 30)
            {
                valid = false;
                sb.Append(" Invalid Weight ");
            }

            if (d.DonorID < 100000 || d.DonorID > 999999 || d.DonationID < 100000 || d.DonationID > 999999
                || d.BloodBankID < 100000 || d.BloodBankID > 999999)
            {
                valid = false;
                sb.Append(" Id length should be atleast 6 digits ");
            }
            var expr = new Regex("[0-9]");
            if (expr.IsMatch(d.Mobile))
            {
                valid = false;
                sb.Append(" Phone number can only have digits ");
            }

            if (valid == false)
            {
                throw new BloodException(sb.ToString());
            }

            
                return bbda.UpdateDonor(d);
            
        }
        public bool DonorDelete(Donor d)
        {
            return bbda.DelDonor(d);
        }
        public Donor SearchDonorById(Donor d)
        {
            return SearchDonorById(d);
        }
        
    }
}
