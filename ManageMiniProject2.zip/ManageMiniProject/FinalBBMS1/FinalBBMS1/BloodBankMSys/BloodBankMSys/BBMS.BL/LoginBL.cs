﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
   public class LoginBL
    {
       LoginDl bbda = new LoginDl();

        public bool AdminCheck(Admin admin)
        {
            return bbda.AdminCheck(admin);
        }

        // Sign In For Blood Bank Employee
        public int ValidateBankLogin(Bloodbank bb)
        {
            //InventoryDAL ival = new InventoryDAL();
            return bbda.ValidateBankLogin(bb);
        }
    }
}
