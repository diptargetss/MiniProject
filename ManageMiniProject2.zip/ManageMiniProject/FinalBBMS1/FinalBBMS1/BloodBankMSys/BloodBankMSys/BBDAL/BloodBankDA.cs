﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entities;
using BBMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BBDAL
{
    public class BloodBankDA        
    {
        SqlConnection con =new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
      
        public List<Donor> ShowDonors(int bbid)
        {
            List < Donor > DonorList= null;
           

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "donor_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                DonorList = new List<Donor>();
                while (dr.Read())
                {
                    Donor entity = new Donor();
                    entity.DonorID = dr.GetInt16(0);
                    entity.firstname = dr.GetString(1);
                    entity.lastname = dr.GetString(2);
                    entity.Mobile = dr.GetString(3);
                    entity.BloodGroup = dr.GetString(4);
                    entity.City = dr.GetString(5);
                    DonorList.Add(entity);
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return DonorList;
        }

       
        //public bool registerBank(string id,string bname)
        //{
        //    bool bankadd = false;
        //    try
        //    {
        //        cmd = new SqlCommand();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "bankadm_add";
        //        cmd.Parameters.AddWithValue("@bid", id);
        //        cmd.Parameters.AddWithValue("@bname", bname);
        //        cmd.Connection = con;

        //        con.Open();

        //        int result = cmd.ExecuteNonQuery();

        //        con.Close();

        //        if (result > 0)
        //            bankadd = true;
        //    }
        //    catch (SqlException s)
        //    {
        //        con.Close();
        //        throw s;
        //    }
        //    catch (Exception ex)
        //    {
        //        con.Close();
        //        throw ex;
        //    }
        //    return bankadd;
        //}
        
    }
}
