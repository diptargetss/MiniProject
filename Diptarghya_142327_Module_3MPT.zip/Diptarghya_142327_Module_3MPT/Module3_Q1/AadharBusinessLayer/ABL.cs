﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UIDEntity;
using UIDExceptions;
using System.Text.RegularExpressions;
using AadharDAL;

namespace AadharBusinessLayer
{
    public class ABL
    {
        AadharDAO adao = null;
        public ABL()
        {
            adao = new AadharDAO();
        }
        public static bool validate(Aadhar ad)
        {
            StringBuilder sb = new StringBuilder();
            bool validUid = true;
           
            var adNumRegex = new Regex("^[0-9]{12}");
            if (!(adNumRegex.IsMatch(ad.Aadharnumber)) == true)
            {
                validUid = false;
                sb.Append(Environment.NewLine + "Aadhar number can only be digits and of length 12");
            }

            var adPinRegex = new Regex("^[0-9]{6}");
            if (!(adPinRegex.IsMatch(ad.Pincode)) == true)
            {
                validUid = false;
                sb.Append(Environment.NewLine + "Pin Code should only be digits and of length 6");
            }
            
            var adPhoneRegex = new Regex("^[0-9]{10}");
            if (!(adPhoneRegex.IsMatch(ad.Phone)) == true)
            {
                validUid = false;
                sb.Append(Environment.NewLine + "Phone number can only be digits and of length 10");
            }
           
           if(ad.Email[0]=='@' || !(ad.Email.Contains("@")) || !(ad.Email.Contains(".")))
           {
               validUid = false;
                sb.Append(Environment.NewLine + "Enter valid Email");
           }
            
            if (validUid == false)
                throw new UIDException(sb.ToString());
            return validUid;
        }
        public static bool validNum(String uidno)
        {
            StringBuilder sb = new StringBuilder();
            bool validUid = true;

            var adNumRegex = new Regex("^[0-9]{12}");
            if (!(adNumRegex.IsMatch(uidno)) == true)
            {
                validUid = false;
                sb.Append(Environment.NewLine + "Aadhar number can only be digits and of length 12");
            }

           
            if (validUid == false)
                throw new UIDException(sb.ToString());
            return validUid;
        }

        public bool UpdateAadhar(Aadhar ad)
        {
            bool updated = false;
            try
            {
                if (validate(ad))
                {
                    //StudentDAO sbl = new StudentDAO();
                    updated = adao.UpdateAadhar(ad);
                }
            }
            catch (UIDException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw e;
            }
            return updated;
            
        }
        public Aadhar Search(string uidno)
        {
            
            Aadhar adh=null;
            if (validNum(uidno))
            {
                return adao.Search(uidno);
            }
            else
                return adh;
            
            
        }

    }
}
