﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UIDEntity;
using System.Data.SqlClient;
using System.Configuration;

namespace AadharDAL
{
    public class AadharDAO
    {
        public bool UpdateAadhar(Aadhar ad)
        {

            bool flag = false;
            string q = "update Aadhar set Address=@a , Phone = @p, City=@c, state_res=@s, Pincode=@d, Email=@e where Id=@i";
            string cs = ConfigurationManager.ConnectionStrings["dbstring"].ConnectionString.ToString();
            SqlConnection con = new SqlConnection(cs);

            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.Add(new SqlParameter("@a", ad.Address));
            cmd.Parameters.Add(new SqlParameter("@p", ad.Phone));
            cmd.Parameters.Add(new SqlParameter("@i", ad.Aadharnumber));
            cmd.Parameters.Add(new SqlParameter("@c", ad.City));
            cmd.Parameters.Add(new SqlParameter("@s", ad.State));
            cmd.Parameters.Add(new SqlParameter("@d", ad.Pincode));
            cmd.Parameters.Add(new SqlParameter("@e", ad.Email));


            con.Open();
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r > 0)
                flag = true;
            return flag;
        }
        public Aadhar Search(string i)
        {
            Aadhar Obj = new Aadhar();
            string cs = ConfigurationManager.ConnectionStrings["dbstring"].ConnectionString.ToString();
            SqlConnection con = new SqlConnection(cs);
            string q = "select * from Aadhar where id= @n";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.Add(new SqlParameter("@n", i));
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                Obj.Aadharnumber = dr[0].ToString();
                Obj.FullName = dr[1].ToString();
                Obj.Gender = dr[2].ToString();
                Obj.DOB = Convert.ToDateTime(dr[3]);
                Obj.Address = dr[4].ToString();
                Obj.City = dr[5].ToString();
                Obj.State = dr[6].ToString();
                Obj.Pincode = dr[7].ToString();
                Obj.Email = dr[8].ToString();
                Obj.Phone = dr[9].ToString();
            }

            con.Close();
            return Obj;
        }

    }
}
