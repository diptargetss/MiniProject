﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIDExceptions
{
    public class UIDException:ApplicationException
    {
        public UIDException():base()
        {

        }
        public UIDException(string message):base(message)
        {

        }
    }
}
