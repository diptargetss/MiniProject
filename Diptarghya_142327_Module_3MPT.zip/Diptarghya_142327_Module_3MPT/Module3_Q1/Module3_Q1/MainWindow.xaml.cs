﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AadharBusinessLayer;
using UIDEntity;
using UIDExceptions;

namespace Module3_Q1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        ABL ab = new ABL();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string uid = txtid.Text;
            
                Aadhar an = ab.Search(uid);


                if (an != null)
                {
                    txtname.Text = an.FullName;
                    txtgender.Text = an.Gender;
                    txtdob.Text = an.DOB.ToString();
                    txtaddr.Text = an.Address;
                    txtcity.Text = an.City;
                    txtstate.Text = an.State;
                    txtpin.Text = an.Pincode;
                    txtemail.Text = an.Email;
                    txtphno.Text = an.Phone;


                }
                else
                    MessageBox.Show("Please check Adhar number its not correct");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Aadhar ad = new Aadhar();
            ad.Aadharnumber = txtid.Text;
            ad.Address = txtaddr.Text;
            ad.City = txtcity.Text;
            ad.DOB = Convert.ToDateTime(txtdob.Text);
            ad.Email = txtemail.Text;
            ad.Phone = txtphno.Text;
            ad.Pincode = txtpin.Text;
            ad.State = txtstate.Text;
            ad.FullName = txtname.Text;
            ad.Gender = txtgender.Text;
            try
            {
                bool updated = ab.UpdateAadhar(ad);
                if (updated)
                    MessageBox.Show("Record updated successfully");
                else
                    MessageBox.Show("Failed to update record");
            }
            catch(UIDException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
