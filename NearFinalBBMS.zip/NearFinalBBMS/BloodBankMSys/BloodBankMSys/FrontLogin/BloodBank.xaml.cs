﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for BloodBank.xaml
    /// </summary>
    public partial class BloodBank : Window
    {
        public int BloodBankID;
        public BloodBank()
        {
            InitializeComponent();
        }



        private void btnBBCamp_Click(object sender, RoutedEventArgs e)
        {
            CampForBB campbb = new CampForBB();
            campbb.Show();
        }

        private void btnBBDetails_Click(object sender, RoutedEventArgs e)
        {
            BBDetailsForBB bbdetails = new BBDetailsForBB();
            bbdetails.Show();
        }

        private void btnDonors_Click(object sender, RoutedEventArgs e)
        {
            DonarForm adddonor = new DonarForm();
            adddonor.Show();
        }

        private void btnBBStock_Click(object sender, RoutedEventArgs e)
        {
            BBStock stock = new BBStock();
            stock.Show();
        }
    }
}
