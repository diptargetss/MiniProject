﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Exceptions
{
    public class BloodException:ApplicationException
    {
        public BloodException():base()
        {

        }
        public BloodException(string message):base(message)
        {

        }
    }
}
