﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class BloodBL
    {
        BloodBankDA bbda = null;
        public BloodBL()
        {
            bbda = new BloodBankDA();
        }
        
        //Sign In For Admin
        public bool AdminCheck(Admin admin)
        {
            return bbda.AdminCheck(admin);
        }

        // Sign In For Blood Bank Employee
        public Bloodbank LoginCheck(string Username,string Password)
        {
            return bbda.LoginCheck(Username,Password);
        }
        public bool ModifyCampDetails(BloodCamp camp)
        {
            //bool checkDate=false;
            StringBuilder sb = new StringBuilder();
            
            
            if(camp.StartDate.CompareTo(DateTime.Now)>0)
            return bbda.ModifyCampDetails(camp);
            else
            {
                //Console.WriteLine("Cannot Change details as date already passed");
                sb.Append("Date has already passed");
                throw new BloodException(sb.ToString());
                
            }
            
        }
        public bool registerBank(string id,string bname )//out bbid)
        {
            //BloodBank bnk=bbda.BankSearch(b.userid);
            //if(bnk!=null)
            //{
            //    checkmsg="Username already exists";
            //    return false;
            //}
            //else
            return bbda.registerBank(id, bname);  
                    

        }
        public bool DonorAdd(Donor d)
        { 
            //if(d.Address==""||d.BloodGroup!)
            return bbda.DonorAdd(d);
        }
        public bool DonorUpdate(Donor d){return bbda.DonorUpdate(d);}
        public bool DonorDelete(int id){return bbda.DonorDelete(id);}
        public bool AddCamp(BloodCamp bc)
        {
            if(bc.StartDate.CompareTo(DateTime.Now)>0)
            {
                if (bc.EndDate.CompareTo(bc.StartDate) > 0)
                    return bbda.AddCamp(bc);
                else
                    return false;
            }
            else
            {
                return false;
            }
        }
        
        public bool BloodRequest(Hospital hos,int units)
        {
            bool ch=bbda.RequestCheck(hos.Location,units);
            return ch;
        }
        public List<Donor> ShowDonors(int bbid)
        {return bbda.ShowDonors(bbid);}


        public List<Bloodbank> ShowBanks()
        { return bbda.ShowBanks(); }

        public bool AddHospital(string id,string hname)
        {
            int i = Convert.ToInt32(id);
            if (i >= 100000 ||i <= 999999)
                return bbda.AddHospIdName(i,hname);
            else
                return false;
        }

        public bool UpdateHospitalDetails(Hospital details)
        {
            return bbda.UpdateHospitalDetails(details);
        }

        public bool DelHospitalDetails(int id)
        {
            return bbda.DelHospitalDetails(id);
        }
        public bool AddBankIdName(int id, string bname)
        {
            return bbda.AddBankIDName(id,bname);
        }

        public bool DelBankDetails(int id)
        {
            return bbda.DelBankDetails(id);
        }

        public bool UpdateBankDetails(Bloodbank details)
        {
            
                return bbda.UpdateBankDetail(details);
            
        }
        public List<Hospital> GetHospDetails()
        {
            return bbda.GetHospDetails();
        }
        public Hospital GetHospDetailsById(int id)
        {
            return bbda.GetHospDetailsById(id);
        }
        public List<Bloodbank> GetBankDetails()
        {
            return bbda.GetBankDetails();
        }
        public Bloodbank GetBankDetailsById(string id)
        {

            int i = Convert.ToInt32(id);
                
                return bbda.GetBankDetailsById(i);
            
        }
        public List<BloodInventory> GetInventoryDetails()
        {
            return bbda.GetInventoryDetails();
        }
        public List<BloodCamp> GetDonationCampDetails()
        {
            return bbda.GetDonationCampDetails();
        }
        public List<Donor> GetDonorDetails()
        {
            return bbda.GetDonorDetails();
        }

       
       
    }
}
