---stored procedure for Bloodbank---
 select * from BBMS.BloodBank
 delete from BBMS.BloodBank where bbregion is NULL
 go
 create proc bank_add(@bid int,@bname varchar(20)) as
 begin
 insert into BBMS.BloodBank values(@bid,@bname,'  ','  ','  ','  ')
 end 
 go

 exec bank_add 170170,'Santoshi Maa'
 drop proc bank_add

---stored procedure for updating----

go
create proc bank_upd(@bid int,@bname varchar(20),@baddress varchar(50),@bregion varchar(20),@bcity varchar(15),@bmobnum varchar(20))
as
begin
update  BBMS.BloodBank SET BloodBankname=@bname,bbaddress=@baddress,bbregion=@bregion,bbcity=@bcity,bbMobNo=@bmobnum
where BloodBankId=@bid
end
go
select * from BBMS.BloodBank
drop proc bank_upd
exec bank_upd 100100,'ABC','ABC Apartments','Thane','Mumbai',7893365789

--stored procedure for deleting---
go
create proc bank_del (@bid int) as
begin
delete from BBMS.BloodBank where BloodBankId=@bid
end
go

---stored procedure for showing bloodbank details by id---

go
create proc bank_showbyid(@bid int)
as
begin
select BloodBankId,BloodBankname,bbaddress,bbregion,bbMobNo,bbcity  from BBMS.BloodBank where BloodBankId=@bid
end
go

drop proc bank_showbyid
exec bank_showbyid 456456
---stored procedure for showing bloodbank details


go
create procedure bank_showall
as
begin
select * from BBMS.BloodBank
end
go
exec bank_showall
drop proc bank_showall
--table for bloodbank login credentials


create table BBMS.BloodLogin(Username varchar(10),Passord varchar(10));

insert into  BBMS.BloodLogin values('bloodbank','bloodbank');

drop table BBMS.BloodLogin

go
create proc BBMS_BBLogin (@username varchar(10),@password varchar(10)) as 
(select * from BBMS.BloodLogin where Username=@username and Passord=@password)	
go

drop proc BBMS_BBLogin

exec BBMS_BBLogin 'bloodbank','bloodbank'

select * from BBMS.Hospital