﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Module_4_Q2.Models;

namespace Module_4_Q2.Controllers
{
    public class LeaveController : Controller
    {
        private LeaveContext db = new LeaveContext();

        // GET: /Leave/
        public ActionResult Index()
        {
            return View(db.EmployeeLeaves.ToList());
        }

        // GET: /Leave/Details/5
        public ActionResult Details(int id)
        {
            if (id == 0)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var query = from ob in db.EmployeeLeaves where ob.EmployeeID == "546565" select ob; ;
            
            if (query == null)
            {
                return HttpNotFound();
            }
            return View(query.ToList());
        }

        // GET: /Leave/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /Leave/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="EmployeeID,StartDate,EndDate,LeaveType,LeaveReason,Comments")] EmployeeLeave employeeleave)
        {
            if (ModelState.IsValid)
            {
                db.EmployeeLeaves.Add(employeeleave);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employeeleave);
        }

        // GET: /Leave/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeLeave employeeleave = db.EmployeeLeaves.Find(id);
            if (employeeleave == null)
            {
                return HttpNotFound();
            }
            return View(employeeleave);
        }

        // POST: /Leave/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="EmployeeID,StartDate,EndDate,LeaveType,LeaveReason,Comments")] EmployeeLeave employeeleave)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employeeleave).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employeeleave);
        }

        // GET: /Leave/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeLeave employeeleave = db.EmployeeLeaves.Find(id);
            if (employeeleave == null)
            {
                return HttpNotFound();
            }
            return View(employeeleave);
        }

        // POST: /Leave/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            EmployeeLeave employeeleave = db.EmployeeLeaves.Find(id);
            db.EmployeeLeaves.Remove(employeeleave);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
