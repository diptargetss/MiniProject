﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Module_4_Q2.Startup))]
namespace Module_4_Q2
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
