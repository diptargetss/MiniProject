create table diptarghya_142327.EmployeeLogin
(
EmployeeID varchar(6) primary key,
Password varchar(20)
)

insert into diptarghya_142327.EmployeeLogin values('546565','random')
insert into diptarghya_142327.EmployeeLogin values('701701','shirayuki')


go
create proc usp_searchemployee(@id varchar(6),@password varchar(20))
as
select * from diptarghya_142327.EmployeeLogin where EmployeeID=@id and Password=@password
go

exec usp_searchemployee '546565','random'

create table diptarghya_142327.EmployeeLeave
(
EmployeeID varchar(6) primary key,
StartDate date,
EndDate date,
LeaveType varchar(30),
LeaveReason varchar(30),
Comments varchar(200)
)

drop table diptarghya_142327.EmployeeLeave

insert into diptarghya_142327.EmployeeLeave values('546565','05/10/18','11/10/18','Earned Leave','Festival','Durga Puja')
insert into diptarghya_142327.EmployeeLeave values('701701','07/12/18','12/12/18','Transfer Leave','Personal','Injured Leg')

go
create proc usp_insertleave(@id varchar(6),@password varchar(20))
as
select * from diptarghya_142327.EmployeeLogin where EmployeeID=@id and Password=@password
go
