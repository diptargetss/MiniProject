﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LMS.Exceptions
{
    public class LogException:ApplicationException
    {
        public LogException(string message):base(message)
        {

        }
    }
}
