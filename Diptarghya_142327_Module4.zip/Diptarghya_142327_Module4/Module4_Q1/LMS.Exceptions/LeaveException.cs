﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LMS.Exceptions
{
    public class LeaveException:ApplicationException
    {
        public LeaveException(string message):base(message)
        {

        }
    }
}
