﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LMS.Exceptions;
using LMSDAL;
using LMSEntity;
using System.Data.SqlClient;

namespace LMSBusinessLayer
{
    public class LoginBL
    {
        public bool CheckLogin(LoginCreds rec)
        {

            try
            {
                LoginDAL obj = new LoginDAL();
                bool flag = obj.CheckLogin(rec);

                return flag;
            }

            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
    }
}
