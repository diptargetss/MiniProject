﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LMS.Exceptions;
using LMSDAL;
using LMSEntity;
using System.Data.SqlClient;

namespace LMSBusinessLayer
{
    public class LeaveBL
    {
        public bool AddLeave(Leave obj)
        {
            bool flag = false;
            try
            {
                LeaveDAL dobj = new LeaveDAL();
                if (Validate(obj))
                {
                    flag = dobj.AddLeave(obj);
                }

            }    
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }

            return flag;
        }

        private static bool Validate(Leave p)
        {
            bool flag = true;
            StringBuilder sb = new StringBuilder();
            int EID = Convert.ToInt32(p.ID);
            


            if (EID < 100000 && EID > 999999)
            {
                flag = false;
                sb.Append("Product ID should be 6 digit");
            }
            if (p.StartDate == null)
            {
                flag = false;
                sb.Append("Start Date cant be Null");
            }
            if (p.EndDate == null)
            {
                flag = false;
                sb.Append("End Date cant be Null");
            }
            if (p.LeaveType != "Earned Leave"|| p.LeaveType!="Transfer Leave" )
            {
                flag = false;
                sb.Append("Invalid Leave Type");
            }
            if (p.Reason != "Out of Station" || p.Reason != "Personal"||p.Reason!="Festival")
            {
                flag = false;
                sb.Append("Invalid Leave Reason");
            }
            if (p.Comments.Length > 200)
            {
                flag = false;
                sb.Append("Comments Exceeded 200 characters");
            }
            if (flag == false)
            {
                throw new LeaveException(sb.ToString());
            }

            return flag;
        }
    }
}
