﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LMSEntity;
using LMSBusinessLayer;
using LMS.Exceptions;
using System.Web.Security;
using System.Data.SqlClient;


namespace Module4_Q1
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                LoginBL lb = new LoginBL();
                LoginCreds o = new LoginCreds();
                o.ID = txtempid.Text;
                o.Password = txtpassword.Text;
                bool flag = lb.CheckLogin(o);
                Session["userName"] = txtempid.Text;

                if (flag)
                {
                    FormsAuthentication.RedirectFromLoginPage(txtempid.Text, Persist.Checked);
                }
                else
                    lblmsg.Text = "Incorrect username or password";
            }
            catch(SqlException)
            {
                lblmsg.Text="Login Failed"; 
            }
        }
    }
}