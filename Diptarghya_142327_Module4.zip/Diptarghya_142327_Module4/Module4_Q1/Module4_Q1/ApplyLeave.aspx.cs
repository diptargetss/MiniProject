﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LMSBusinessLayer;
using LMSEntity;
using LMS.Exceptions;
using System.Data.SqlClient;

namespace Module4_Q1
{
    public partial class ApplyLeave : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //LeaveBL lv = new LeaveBL();
        }

        protected void btnleave_Click(object sender, EventArgs e)
        {
            try
            {
                LeaveBL obj = new LeaveBL();
                Leave o = new Leave();
                o.ID = txtid.Text;
                o.StartDate = Convert.ToDateTime(txtstart.Text);
                o.EndDate = Convert.ToDateTime(txtend.Text);
                o.LeaveType=dltype.SelectedValue.ToString();
                o.Reason=dlreason.SelectedValue.ToString();
                o.Comments=txtcomment.Text;
                bool flag = obj.AddLeave(o);
                if (flag)
                {
                    lblmsg.Text="Leave successfully Added";
                }
                else
                {
                    lblmsg.Text = "Unable to add Leave";
                }
            }
            catch(SqlException s)
            {
                lblmsg.Text = s.Message.ToString();
            }
            catch (Exception v)
            {
                lblmsg.Text = v.Message.ToString();
            }
        }
    }
}