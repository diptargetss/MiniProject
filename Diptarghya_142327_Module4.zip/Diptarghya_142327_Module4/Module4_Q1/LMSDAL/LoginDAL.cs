﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using LMSEntity;
using LMS.Exceptions;
using System.Configuration;

namespace LMSDAL
{
    public class LoginDAL
    {
        public bool CheckLogin(LoginCreds rec)
        {
            //Write ado.net query
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            bool ch = false;
           try{
                
              
                
                SqlCommand cmd = new SqlCommand();
               // string query = "exec ;
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_searchemployee";
                cmd.Parameters.AddWithValue("@id",rec.ID);
                cmd.Parameters.AddWithValue("@password",rec.Password);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                
               
                if (dr.HasRows)
                    ch = true;
                con.Close();
                //MessageBox.Show("Saved Succes...");
                //SqlDataAdapter adp = new SqlDataAdapter(cmd);
                
                //SqlCommandBuilder builder = new SqlCommandBuilder(adp);
                //DataTable dt = new DataTable();
                //adp.Fill(dt);
                //foreach (DataRow drow in dt.Rows)
                //{
                //    if (rec.ID == drow[0].ToString() && rec.Password == drow[1].ToString())
                //        ch = true;

                //}
                
        }

            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
    return ch;
        }
    }
}
