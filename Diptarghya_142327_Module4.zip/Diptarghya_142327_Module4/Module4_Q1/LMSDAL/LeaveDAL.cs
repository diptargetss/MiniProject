﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using LMSEntity;
using LMS.Exceptions;

namespace LMSDAL
{
    public class LeaveDAL
    {
        public bool AddLeave(Leave obj)
        {
            bool flag = false;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
                SqlCommand cmd = new SqlCommand();
                string query = "exec usp_searchemployee";
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@id", obj.ID);
                cmd.Parameters.AddWithValue("@startdate", obj.StartDate);

                cmd.Parameters.AddWithValue("@enddate", obj.EndDate);
                cmd.Parameters.AddWithValue("@leavetype", obj.LeaveType);
                cmd.Parameters.AddWithValue("@leavecause", obj.Reason);
                cmd.Parameters.AddWithValue("@comment", obj.Comments);

                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();
                if (ra > 0)
                {
                    flag = true;
                }
                

            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return flag;
        }
    }
}
