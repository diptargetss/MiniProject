﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.Exceptions;
using BBMS.Entity;


namespace BBMS.DAL
{
    public class BBDetailDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public bool UpdateBankDetail(Bloodbank details)
        {
            bool bankupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_upd";
                cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                cmd.Parameters.AddWithValue("@bname", details.BloodBankname);
                cmd.Parameters.AddWithValue("@baddress", details.Baddress);
                cmd.Parameters.AddWithValue("@bcity", details.BloodBankCity);
                cmd.Parameters.AddWithValue("@bmobnum", details.BloodBankMobNo);
                cmd.Parameters.AddWithValue("@bregion", details.BRegion);
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    bankupdate = true;
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return bankupdate;
        }
        public Bloodbank GetBankDetailsById(Bloodbank bb)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_showbyid";
                cmd.Parameters.AddWithValue("@bid", bb.BloodBankId);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    bb.BloodBankname = dr.GetString(1);
                    bb.Baddress = dr.GetString(2);
                    bb.BRegion = dr.GetString(3);
                    bb.BloodBankCity = dr.GetString(4);
                    bb.BloodBankMobNo = dr.GetString(5);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return bb;
        }
    }
}
