﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.Exceptions;
using BBMS.Entity;

namespace BBMS.DAL
{
    public class BBReportDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public List<Donor> GetDonorDetails(int id)
        {
            List<Donor> donordetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bb_donorview";
                cmd.Parameters.AddWithValue("@bbid", id);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                donordetails = new List<Donor>();
                while (dr.Read())
                {
                    Donor entity = new Donor();

                    entity.DonorID = dr.GetInt32(0);
                    entity.firstname = dr.GetString(1);
                    entity.lastname = dr.GetString(2);
                    entity.Address = dr.GetString(3);
                    entity.City = dr.GetString(4);
                    entity.Mobile = dr.GetString(5);
                    entity.BloodGroup = dr.GetString(6);

                    donordetails.Add(entity);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return donordetails;
        }
        public List<BloodCamp> GetCampDetails(int id)
        {
            List<BloodCamp> campdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bb_campview";
                cmd.Parameters.AddWithValue("@bbid", id);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                campdetails = new List<BloodCamp>();
                while (dr.Read())
                {
                    BloodCamp entity = new BloodCamp();

                    entity.CampID = dr.GetInt32(0);
                    entity.Name = dr.GetString(1);
                    entity.Address = dr.GetString(2);
                    entity.BloodBankId = dr.GetInt32(3);
                    entity.StartDate = dr.GetDateTime(4);
                    entity.EndDate = dr.GetDateTime(5);

                    campdetails.Add(entity);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return campdetails;
        }
        public List<BloodInventory> GetInventoryDetails(int id)
        {
            List<BloodInventory> invdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bb_inventoryview";
                cmd.Parameters.AddWithValue("@bbid", id);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                invdetails = new List<BloodInventory>();
                while (dr.Read())
                {
                    BloodInventory entity = new BloodInventory();

                    //entity.BloodInventoryId = dr.GetInt32(0);
                    entity.BloodGroup = dr.GetString(0);
                    entity.NumOfBottles = dr.GetInt32(1);
                    entity.BloodBankId = dr.GetInt32(2);
                    entity.ExpDate = dr.GetDateTime(3);

                    invdetails.Add(entity);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return invdetails;
        }
    }
}
