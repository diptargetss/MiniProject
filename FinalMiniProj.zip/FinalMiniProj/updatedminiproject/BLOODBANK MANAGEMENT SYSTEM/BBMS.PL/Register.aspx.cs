﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class Register : System.Web.UI.Page
    {
        RegisterBBBL rbl = new RegisterBBBL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncheck_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtbid.Text == string.Empty)
                {
                    lblcheck.Text = "User id is required";
                }
                else
                {

                    Bloodbank bb = new Bloodbank();
                    bb.BloodBankUserId = txtbid.Text;
                    if (rbl.CheckAvailability(bb))
                    {
                        lblcheck.Text = "User id already exists";
                    }
                    else
                    {
                        lblcheck.Text = "User id available";
                    }
                }
            }
            catch(BloodExceptions b)
            {
                lblcheck.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblcheck.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblcheck.Text = ex.Message;
            }
        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            Bloodbank bb = new Bloodbank();
            
            try
            {
                if (txtbid.Text == string.Empty || txtcity.Text == string.Empty || txtregistercontact.Text == string.Empty || txtAddressLine.Text == string.Empty
                    || txtregisteregion.Text == string.Empty || txtregisterpassword.Text == string.Empty || txtconfirmpassword.Text == string.Empty ||
                    txtregistername.Text == string.Empty)
                {
                    lblmsg.Text = "Values cannot be null";
                }
                else
                {
                    bb.BloodBankId = Convert.ToInt32(txtbid.Text);
                    bb.BloodBankCity = txtcity.Text;
                    bb.BloodBankMobNo = txtregistercontact.Text;
                    bb.Baddress = txtAddressLine.Text;
                    bb.BloodBankPwd = txtregisterpassword.Text;
                    bb.BloodBankUserId = txtregistername.Text;
                    bb.BRegion = txtregisteregion.Text;
                    if (rbl.CheckAvailability(bb))
                    {
                        lblcheck.Text = "User id already exists";
                        lblmsg.Text = "Please provide unique username";
                        txtregistername.Text = string.Empty;
                    }
                    else
                    {
                        if (txtregisterpassword.Text.ToString() == txtconfirmpassword.Text.ToString())
                        {
                            if (rbl.RegisterBloodBank(bb))
                            {
                                lblmsg.Text = "Registration successful";
                            }
                            else
                            {
                                lblmsg.Text = "Failed to Register";
                            }
                        }
                        else
                        {
                            lblmsg.Text = "Please recheck password";
                        }
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }
    }
}