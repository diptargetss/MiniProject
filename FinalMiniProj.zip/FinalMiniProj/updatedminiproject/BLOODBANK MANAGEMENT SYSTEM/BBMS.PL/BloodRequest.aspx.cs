﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;
using System.Data.SqlClient;
namespace BBMS.PL
{
    public partial class BloodRequest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        BloodRequestBL rbl = new BloodRequestBL();

        protected void btnrequest_Click(object sender, EventArgs e)
        {
            
            Bloodrequest brq=new Bloodrequest();
            try
            {
                if (txthid.Text == string.Empty || txthname.Text == string.Empty || txtcity.Text == string.Empty || txtaddr.Text == string.Empty
                    || txtdate.Text == string.Empty || txtregion.Text == string.Empty || txtno.Text == string.Empty)
                {
                    lblmsg.Text = "Values cannot be null";
                }
                else
                {
                    brq.HospitalId = Convert.ToInt32(txthid.Text);
                    brq.HospCity = txtcity.Text;
                    brq.HospitalName = txthname.Text;
                    brq.HospAddress = txtaddr.Text;
                    brq.ReqDate = Convert.ToDateTime(txtdate.Text);
                    brq.HospRegion = txtregion.Text;
                    brq.NoOfPackets = Convert.ToInt32(txtno.Text);
                    brq.BloodGroup = drpblood.SelectedItem.ToString();

                    if (rbl.AddRequest(brq))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Request added successfully')", true);
                        Session["user"] = brq;
                        Server.Transfer("BloodProcess.aspx");
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Request not added')", true);
                        txthid.Text ="";
                        txthname.Text ="";
                        txtcity.Text = "";
                        txtaddr.Text ="";
                        txtdate.Text ="";
                        txtregion.Text ="";
                        txtno.Text ="";
                        lblmsg.Text = "";
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = "Please register hospital with admin";
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }
    }
}