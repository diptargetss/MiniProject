﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class Login : System.Web.UI.Page
    {
        LoginBL bbl = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                AdminLogin ad = new AdminLogin();
                ad.Username = txtuser.Text;
                ad.Password = txtpasswd.Text;
                bbl = new LoginBL();
                if (bbl.AdminCheck(ad))
                {
                    Session["user"] = this.txtuser.Text;
                    Response.Redirect("AdminHome.aspx");                  
                    txtuser.Text = "";
                    txtpasswd.Text = "";
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Incorrect username or password entered')", true);
                    txtuser.Text = "";
                    txtpasswd.Text = "";
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception v)
            {
                lblmsg.Text = v.Message;
            }
        }
    }
}