﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class BBCamp : System.Web.UI.Page
    {
        CampBL cbl = new CampBL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncreate_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtcid.Text == string.Empty || txtcname.Text == string.Empty || txtvenue.Text == string.Empty || txtstartdate.Text == string.Empty || txtenddate.Text == string.Empty)
                {
                    lblmsg.Text = "Values cannot be null";
                }
                else
                {
                    BloodCamp bc = new BloodCamp();
                    bc.BloodBankId = (int)Session["user"];
                    bc.CampID = Convert.ToInt32(txtcid.Text);
                    bc.Name = txtcname.Text;
                    bc.Address = txtvenue.Text;
                    bc.StartDate = Convert.ToDateTime(txtstartdate.Text);
                    bc.EndDate = Convert.ToDateTime(txtenddate.Text);
                    if (cbl.AddCamp(bc))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record added successfully')", true);
                        Clear_Click(sender, e);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not added ')", true);
                        Clear_Click(sender, e);
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtcid.Text == string.Empty)
                {
                    lblmsg.Text = "Id is required";
                }
                else
                {
                    BloodCamp bc = new BloodCamp();
                    bc.BloodBankId = (int)Session["user"];
                    bc.CampID = Convert.ToInt32(txtcid.Text);
                    bc = cbl.GetCampDetailsById(bc);
                    if (bc.Name != null)
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record Found')", true);
                        txtcname.Text = bc.Name;
                        txtvenue.Text = bc.Address;
                        txtstartdate.TextMode = System.Web.UI.WebControls.TextBoxMode.DateTime;
                        txtenddate.TextMode = System.Web.UI.WebControls.TextBoxMode.DateTime;
                        txtstartdate.Text = bc.StartDate.ToShortDateString();
                        txtenddate.Text = bc.EndDate.ToShortDateString();
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not found ')", true);
                        txtcid.Text = "";
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }

        protected void btnmodify_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtcid.Text == string.Empty || txtcname.Text == string.Empty || txtvenue.Text == string.Empty || txtstartdate.Text == string.Empty || txtenddate.Text == string.Empty)
                {
                    lblmsg.Text = "Values cannot be null";
                }
                else
                {
                    BloodCamp bc = new BloodCamp();
                    bc.BloodBankId = (int)Session["user"];
                    bc.CampID = Convert.ToInt32(txtcid.Text);
                    bc.Name = txtcname.Text;
                    bc.Address = txtvenue.Text;
                    bc.StartDate = Convert.ToDateTime(txtstartdate.Text);
                    bc.EndDate = Convert.ToDateTime(txtenddate.Text);
                    if (cbl.ModifyCampDetails(bc))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record modified successfully')", true);
                        Clear_Click(sender, e);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not modified ')", true);
                        Clear_Click(sender, e);
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtcid.Text == string.Empty || txtcname.Text == string.Empty || txtvenue.Text == string.Empty || txtstartdate.Text == string.Empty || txtenddate.Text == string.Empty)
                {
                    lblmsg.Text = "Values cannot be null";
                }
                else
                {
                    BloodCamp bc = new BloodCamp();
                    bc.BloodBankId = (int)Session["user"];
                    bc.CampID = Convert.ToInt32(txtcid.Text);

                    if (cbl.DeleteCamp(bc))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record deleted successfully')", true);
                        Clear_Click(sender, e);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not deleted ')", true);
                        Clear_Click(sender, e);
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }
        protected void Clear_Click(object sender, EventArgs e)
        {
            txtcid.Text = "";
            txtcname.Text = "";
            txtvenue.Text = "";
            txtstartdate.Text = "";
            txtenddate.Text = "";
            lblmsg.Text = "";
        }
    }
}