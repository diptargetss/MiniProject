﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BBMS.BL;
using BBMS.Entity;
using BBMS.Exceptions;
using System.Data.SqlClient;

namespace BBMS.PL
{
    public partial class Hospital : System.Web.UI.Page
    {
        AdminHospitalBL bbl = new AdminHospitalBL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            Hospitals h = new Hospitals();
            try
            {
                if (txthosidadd.Text == string.Empty || txthosnameadd.Text == string.Empty)
                {
                    lblview.Text = "";
                    lbladd.Text = " Values cannot be null ";
                }
                else
                {
                    h.Hospitalid = Convert.ToInt32(txthosidadd.Text);
                    h.Hospitalname = txthosnameadd.Text;


                    if (bbl.AddHospIdName(h))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record added successfully')", true);
                        ClearControl_Click(sender, e);                        
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not added')", true);
                        ClearControl_Click(sender, e);
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lbladd.Text = b.Message;
            }
            catch (SqlException s)
            {
                lbladd.Text = s.Message;
            }
            catch (Exception v)
            {
                lbladd.Text = v.Message;
            }
        }

        protected void btnmodify_Click(object sender, EventArgs e)
        {
            Hospitals h = new Hospitals();
            try
            {
                if (txthosidview.Text == string.Empty || txtname.Text == string.Empty || txtcon.Text == string.Empty || txtaddr.Text == string.Empty ||
                    txtcity.Text == string.Empty || txtreg.Text == string.Empty)
                {
                    lblview.Text = "Values cannot be null";
                    lbladd.Text = "";
                }
                else
                {
                    h.Hospitalid = Convert.ToInt32(txthosidview.Text);
                    h.Hospitalname = txtname.Text;
                    h.ContactNo = txtcon.Text;
                    h.HospitalAddress = txtaddr.Text;
                    h.HospitalCity = txtcity.Text;
                    h.Location = txtreg.Text;

                    if (bbl.UpdateHospitalDetails(h))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record modified successfully')", true);
                        ClearControl_Click(sender, e);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not modified')", true);
                        ClearControl_Click(sender, e);
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblview.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblview.Text = s.Message;
            }
            catch (Exception v)
            {
                lblview.Text = v.Message;
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            try
            {
                if (txthosidview.Text == string.Empty)
                {
                    lblview.Text = "Id is required";
                    lbladd.Text = "";
                }
                else
                {
                    int id = Convert.ToInt32(txthosidview.Text);
                    Hospitals hh = bbl.GetHospDetailsById(id);
                    if (hh == null)
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record Not Found')", true);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record Found')", true);
                        txtaddr.Text = hh.HospitalAddress;
                        txtcity.Text = hh.HospitalCity;
                        txtcon.Text = hh.ContactNo;
                        txtreg.Text = hh.Location;
                        txtname.Text = hh.Hospitalname;
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblview.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblview.Text = s.Message;
            }
            catch (Exception v)
            {
                lblview.Text = v.Message;
            }
        }

        protected void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                if (txthosidview.Text == string.Empty)
                {
                    lblview.Text = "ID cannot be null";
                    lbladd.Text = "";
                }
                else
                {
                    Hospitals h = new Hospitals();
                    h.Hospitalid = Convert.ToInt32(txthosidview.Text);
                    if (bbl.DelHospitalDetails(h))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record deleted successfully')", true);
                        ClearControl_Click(sender, e);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not deleted')", true);
                        ClearControl_Click(sender, e);
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblview.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblview.Text = s.Message;
            }
            catch (Exception v)
            {
                lblview.Text = v.Message;
            }
        }
        protected void ClearControl_Click(object sender, EventArgs e)
        {
            txthosidadd.Text = "";
            txthosnameadd.Text = "";
            txthosidview.Text = "";
            txtname.Text = "";
            txtcon.Text = "";
            txtaddr.Text = "";
            txtcity.Text = "";
            txtreg.Text = "";
        }
    }
}