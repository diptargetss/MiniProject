﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entity;
using BBMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.DAL;
using System.Text.RegularExpressions;

namespace BBMS.BL
{
    public class AdminHospitalBL
    {
        AdminHospitalDL bbda = new AdminHospitalDL();
        public bool AddHospIdName(Hospitals h)
        {
           
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            try
            {
                
                if (h.Hospitalid < 100000 || h.Hospitalid > 999999)
                {
                    valid = false;
                    sb.Append(" Enter valid ID of 6 digits ");
                }

                if (valid == false)
                {
                    throw new BloodExceptions(sb.ToString());
                }
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }

            return bbda.AddHospIdName(h);
        }

         public bool UpdateHospitalDetails(Hospitals hos)
        {
            bool valid = true;
            var expr = new Regex("^[0-9]{5,10}$");
            StringBuilder sb = new StringBuilder();
            try
            {
                if (expr.IsMatch(hos.ContactNo) != true)
                {
                    valid = false;
                    sb.Append(" Contact no should be all digits ");
                }
                if (valid == false)
                {
                    throw new BloodExceptions(sb.ToString());
                }
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }

            return bbda.UpdateHospitalDetails(hos);
        }

        public Hospitals GetHospDetailsById(int id)
         {
             try
             {
                 return bbda.GetHospDetailsById(id);
             }
             catch (BloodExceptions b)
             {
                 throw b;
             }
             catch (SqlException s)
             {
                 throw s;
             }
             catch (Exception v)
             {
                 throw v;
             }
         }

        public bool DelHospitalDetails(Hospitals h)
        {
            try
            {
                return bbda.DelHospitalDetails(h);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
    }
}
