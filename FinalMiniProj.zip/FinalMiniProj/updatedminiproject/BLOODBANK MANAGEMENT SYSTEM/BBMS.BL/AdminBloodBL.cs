﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.DAL;

namespace BBMS.BL
{
    public class AdminBloodBL
    {
        AdminBloodDL bbd = new AdminBloodDL();

        public bool AddBankIdName(Bloodbank bb)
        {
            try
            {
                bool valid = true;
                StringBuilder sb = new StringBuilder();
                if (bb.BloodBankId < 100000 || bb.BloodBankId > 999999)
                {
                    valid = false;
                    sb.Append(" ID should be atleast 6 digits ");
                }
                if (valid == false)
                {
                    throw new BloodExceptions(sb.ToString());
                }  
            }
            catch (BloodExceptions b)
            { 
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return bbd.AddBankIDName(bb);
        }
        public Bloodbank GetBankDetailsById(Bloodbank bb)
        {
            try
            {
                return bbd.GetBankDetailsById(bb);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool UpdateBankDetails(Bloodbank b)
        {
            try
            {
                bool valid = true;
                StringBuilder sb = new StringBuilder();
                if (b.Baddress == string.Empty || b.BRegion == string.Empty || b.BloodBankCity == string.Empty || b.BloodBankMobNo == string.Empty
                    || b.BloodBankname == string.Empty)
                {
                    valid = false;
                    sb.Append(" Values cannot be null ");
                }
                var expr = new Regex("^[0-9]{5,10}$");
                if (expr.IsMatch(b.BloodBankMobNo) != true)
                {
                    valid = false;
                    sb.Append(" Contact no can only be digits ");
                }
                if (valid == false)
                {
                    throw new BloodExceptions(sb.ToString());
                }
            }
            catch (BloodExceptions be)
            {
                throw be;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bbd.UpdateBankDetail(b);
        }
        public bool DelBankDetails(Bloodbank bb)
        {
            try
            {
                return bbd.DelBankDetails(bb);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
