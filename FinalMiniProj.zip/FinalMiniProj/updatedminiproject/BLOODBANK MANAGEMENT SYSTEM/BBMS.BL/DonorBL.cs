﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.DAL;

namespace BBMS.BL
{
    public class DonorBL
    {
        DonorDL ddl = new DonorDL();
        public bool ValidateDonor(Donor donr)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();

            if(donr.DonorID<100000||donr.DonorID>999999||donr.DonationID<100000||donr.DonationID>999999)
            {
                valid = false;
                sb.Append(" Enter valid ID. ID should be 6 digits only ");
            }
            if(donr.Age<16||donr.Age>70)
            {
                valid = false;
                sb.Append("Inappropriate Age for blood donation ");
            }
            if (donr.Weight < 45)
            {
                valid = false;
                sb.Append("Inappropriate Weight for blood donation ");
            }
            if(donr.HBcount<50)
            {
                valid = false;
                sb.Append("Inappropriate HB Count for blood donation ");
            }
            var rxp = new Regex("[A-Za-z]$");
            if(rxp.IsMatch(donr.firstname)==false||rxp.IsMatch(donr.lastname)==false)
            {
                valid = false;
                sb.Append(" Donor name can only be alphabet characters ");
            }
            var regexp = new Regex("^[0-9]{10}$");
            if (regexp.IsMatch(donr.Mobile)==false)
            {
                valid = false;
                sb.Append(" Mobile number should be 10 digits ");
            }
            if (valid == false)
            {
                throw new BloodExceptions(sb.ToString());
            }
            return valid;
        }
        public bool DonorAdd(Donor d)
        {
            bool added = false;
            try
            {
                if (ValidateDonor(d))
                {
                    added=ddl.AddDonor(d);
                }
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return added;
        }

        public bool DonorUpdate(Donor d)
        {
            bool updated=false;
            try
            {
                if(ValidateDonor(d))
                {
                    updated=ddl.UpdateDonor(d);
                }
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return updated;
        }
        public bool DonorDelete(Donor d)
        {
            try
            {
                return ddl.DelDonor(d);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
        public Donor SearchDonorById(Donor d)
        {
            try
            {
                return ddl.SearchDonorById(d);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
    }
}
