﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.DAL;


namespace BBMS.BL
{
    public class StockBL
    {
         StockDL idl = new StockDL();
         public bool DeleteExp()
        {
            try
            {
                return idl.DeleteExp();
            }
            catch (BloodExceptions b)
            {

                throw b;
            }
            catch (SqlException s)
            {

                throw s;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
         public bool UpdateInventory(int bbid,int units,string grp)
         {
             bool valid = true;
             StringBuilder sb = new StringBuilder();
             try
             {
                 if (units <= 0)
                 {
                     valid = false;
                     sb.Append(" Enter valid number of units ");
                 }
                 if (valid == false)
                 {
                     throw new BloodExceptions(sb.ToString());
                 }
             }
             catch (BloodExceptions b)
             {

                 throw b;
             }
             catch (SqlException s)
             {

                 throw s;
             }
             catch (Exception ex)
             {

                 throw ex;
             }
             return idl.UpdateInventory(bbid, units, grp);
         }

        public bool StockTransfer(int bbid,int units,string hname,string grp,DateTime dt)
         {
             bool valid = true;
             StringBuilder sb = new StringBuilder();
             try
             {
                 if (units <= 0)
                 {
                     valid = false;
                     sb.Append(" Enter valid number of units ");
                 }

                 if (valid == false)
                 {
                     throw new BloodExceptions(sb.ToString());
                 }
             }
             catch (BloodExceptions b)
             {

                 throw b;
             }
             catch (SqlException s)
             {

                 throw s;
             }
             catch (Exception ex)
             {

                 throw ex;
             }
            return idl.StockTransfer(bbid,units,hname,grp,dt);
         }
    }  
}
