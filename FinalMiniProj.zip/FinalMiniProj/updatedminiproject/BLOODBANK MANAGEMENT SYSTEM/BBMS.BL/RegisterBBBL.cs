﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.DAL;

namespace BBMS.BL
{
    public class RegisterBBBL
    {
        RegisterBBDL rdl = new RegisterBBDL();
        public bool CheckAvailability(Bloodbank bb)
        {
            try
            {
                return rdl.CheckAvailability(bb);
            }
            catch(BloodExceptions b)
            {
                throw b;
            }
            catch(SqlException s)
            {
                throw s;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public bool validregister(Bloodbank bb)
        {
            bool valid = true;
            StringBuilder sb=new StringBuilder();
            var regexp=new Regex("^[0-9]{10}$");
            if(regexp.IsMatch(bb.BloodBankMobNo)==false)
            {
                valid=false;
                sb.Append("Mobile no should be within 5-10 characters");
            }
            var regexp1=new Regex("^[0-9A-Za-z@_]+$");
            if(regexp1.IsMatch(bb.BloodBankPwd)==false)
            {
                valid = false;
                sb.Append("Password should be within numbers,alphabets or special characters.");
            }
            if (valid == false)
            {
                throw new BloodExceptions(sb.ToString());
            }
            return valid;
        }
        public bool RegisterBloodBank(Bloodbank bb)
        {
            bool added = false;
            try
            {
                if (validregister(bb))
                {
                    added = rdl.RegisterBloodBank(bb);
                }
                
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return added;
        }
    }
}
