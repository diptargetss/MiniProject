﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using BBMS.Entity;
using BBMS.Exception;


namespace AdminBBMSdal
{
    public class BBMSDAL
    {
        SqlConnection con =
             new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        public bool LoginCredentials(BBMSEntity.Login login)//For admin login (username and password is 'Admin')
        {

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BBMS_AdminLogin";
                cmd.Parameters.AddWithValue("@username", login.Username);
                cmd.Parameters.AddWithValue("@password", login.Password);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
        }

      
        public bool AddBloodRequest(BBMSEntity.BloodRequest entity)
        {
              
            bool reqadded = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_requestadd";
                cmd.Parameters.AddWithValue("@id", entity.HospitalId);
                cmd.Parameters.AddWithValue("@name",entity.HospitalName);
                cmd.Parameters.AddWithValue("@address",entity.HospAddress);
                cmd.Parameters.AddWithValue("@city", entity.HospCity);
                cmd.Parameters.AddWithValue("@region",entity.HospRegion);
                cmd.Parameters.AddWithValue("@date",entity.ReqDate);
                cmd.Parameters.AddWithValue("@bloodgroup",entity.BloodGroup);
                cmd.Parameters.AddWithValue("@packets",entity.NoOfPackets);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    reqadded = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return reqadded;
    }

        //public bool AddHospitalDetails(BBMSEntity.Hospital details)
        //{
        //    bool hospadd = false;

        //    try
        //    {
        //        cmd = new SqlCommand();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "hosp_add";
        //        cmd.Parameters.AddWithValue("@hid", details.HospitalId);
        //        cmd.Parameters.AddWithValue("@hname", details.Hospitalname);
        //        cmd.Parameters.AddWithValue("@haddress", details.HospitalAddress);
        //        cmd.Parameters.AddWithValue("@hcity", details.HospitalCity);
        //        cmd.Connection = con;

        //        con.Open();

        //        int result = cmd.ExecuteNonQuery();

        //        con.Close();

        //        if (result > 0)
        //            hospadd = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new BBMSException(ex.Message);
        //    }

        //    return hospadd;
        //}

        public bool AddHospIdName(int id,string hname)
        {
            bool hospadd = false;
                        try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hospadm_add";
                cmd.Parameters.AddWithValue("@hid", id);
                cmd.Parameters.AddWithValue("@hname", hname);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospadd = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return hospadd;
        }
     

        public bool DelHospitalDetails(int id)
        {
            bool hospadd = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_del";
                cmd.Parameters.AddWithValue("@hid",id);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospadd = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return hospadd;
        }
        public bool UpdateHospitalDetails(BBMSEntity.Hospital details)
        {
            bool hospupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_upd";
                cmd.Parameters.AddWithValue("@hid", details.HospitalId);
                cmd.Parameters.AddWithValue("@hname", details.Hospitalname);
                cmd.Parameters.AddWithValue("@haddress", details.HospitalAddress);
                cmd.Parameters.AddWithValue("@hcity", details.HospitalCity);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospupdate = true;
            }
            catch (Exception)
            {

                throw;
            }
            return hospupdate;
        }

        public List<BBMSEntity.Hospital> GetHospDetails()
        {
            List<BBMSEntity.Hospital> hospdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_showall";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                hospdetails = new List<BBMSEntity.Hospital>();
                while (dr.Read())
                {
                    BBMSEntity.Hospital entity = new BBMSEntity.Hospital();
                    entity.HospitalId = dr.GetInt32(0);
                    entity.Hospitalname = dr.GetString(1);
                    entity.HospitalAddress = dr.GetString(2);
                    entity.HospitalCity = dr.GetString(3);
                    hospdetails.Add(entity);

                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return hospdetails;
        }
        //Search hospital details by Id
        public BBMSEntity.Hospital GetHospDetailsById(int id)
        {
            BBMSEntity.Hospital hospdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_showall";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                hospdetails = new BBMSEntity.Hospital();
                while (dr.Read())
                {
                    BBMSEntity.Hospital entity = new BBMSEntity.Hospital();
                    entity.HospitalId = dr.GetInt32(0);
                    entity.Hospitalname = dr.GetString(1);
                    entity.HospitalAddress = dr.GetString(2);
                    entity.HospitalCity = dr.GetString(3);


                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return hospdetails;
        }


        //Bank Admin

        public bool AddBankIdName(int id, string bname)
        {
            bool bankadd = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bankadm_add";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Parameters.AddWithValue("@bname", bname);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankadd = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return bankadd;
        }
        //delete bank details by id
        public bool DelBankDetails(int id)
        {
            bool bankdel = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_del";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankdel = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return bankdel;
        }

        //update details by id
        public bool UpdateBankDetails(BBMSEntity.BBank details)
        {
            bool bankupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_upd";
                cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                cmd.Parameters.AddWithValue("@bname", details.BloodBankname);
                cmd.Parameters.AddWithValue("@baddress", details.Baddress);
                cmd.Parameters.AddWithValue("@bcity", details.BloodBankCity);
                cmd.Parameters.AddWithValue("@bno", details.BloodBankMobNo);

                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankupdate = true;
            }
            catch (Exception)
            {

                throw;
            }
            return bankupdate;
        }

        public List<BBMSEntity.BBank> GetBankDetails()
        {
            List<BBMSEntity.BBank> bankdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_showall";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                bankdetails = new List<BBMSEntity.BBank>();
                while (dr.Read())
                {
                    BBMSEntity.BBank entity = new BBMSEntity.BBank();
                    entity.BloodBankId = dr.GetInt32(0);
                    entity.BloodBankname = dr.GetString(1);
                    entity.Baddress = dr.GetString(2);
                    entity.BRegion = dr.GetString(3);
                    entity.BloodBankCity = dr.GetString(4);
                    entity.BloodBankMobNo = dr.GetString(5);
                    bankdetails.Add(entity);

                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return bankdetails;
        }
        //search by BloodBankid

        public BBMSEntity.BBank GetBankDetailsById(int id)
        {
            BBMSEntity.BBank bankdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_showbyid";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                bankdetails = new BBMSEntity.BBank();
                while (dr.Read())
                {
                    BBMSEntity.BBank entity = new BBMSEntity.BBank();
                    entity.BloodBankId = dr.GetInt16(0);
                    entity.BloodBankname = dr.GetString(1);
                    entity.Baddress=dr.GetString(2);
                    entity.BRegion = dr.GetString(3);
                    entity.BloodBankMobNo = dr.GetString(4);
                    entity.BloodBankCity = dr.GetString(5);
                    entity.BloodBankUserId = dr.GetInt16(6);
                    entity.BloodBankPwd = dr.GetString(7);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return bankdetails;
        }

        //Blood Bank Inventory

        public List<BBMSEntity.BloodInventory> GetInventoryDetails()
        {
            List<BBMSEntity.BloodInventory> invdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "inventory_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                invdetails = new List<BBMSEntity.BloodInventory>();
                while (dr.Read())
                {
                    BBMSEntity.BloodInventory entity = new BBMSEntity.BloodInventory();
                    entity.BloodInventoryId = dr.GetInt32(0);
                    entity.BloodBankId = dr.GetInt32(1);
                    entity.BloodGroup = dr.GetString(2);
                    entity.NumOfBottles = dr.GetInt32(3);
                    entity.ExpDate = dr.GetDateTime(4);
                    invdetails.Add(entity);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return invdetails;
        }

      

        //Camp 

        public List<BBMSEntity.BloodDonationCamp> GetDonationCampDetails()
        {
            List<BBMSEntity.BloodDonationCamp> campdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "camp_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                campdetails = new List<BBMSEntity.BloodDonationCamp>();
                while (dr.Read())
                {
                    BBMSEntity.BloodDonationCamp entity = new BBMSEntity.BloodDonationCamp();
                    entity.BloodDonationCampId = dr.GetInt16(0);
                    entity.CampName = dr.GetString(1);
                    entity.City = dr.GetString(2);
                    entity.Addr = dr.GetString(3);
                    entity.BBName = dr.GetString(4);
                    entity.CampSDate = dr.GetDateTime(5);
                    entity.CampEDate = dr.GetDateTime(6);
                    campdetails.Add(entity);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return campdetails;
        }

      

        //donor details
        public List<BBMSEntity.BloodDonor> GetDonorDetails()
        {
            List<BBMSEntity.BloodDonor> donordetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "donor_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                donordetails = new List<BBMSEntity.BloodDonor>();
                while (dr.Read())
                {
                    BBMSEntity.BloodDonor entity = new BBMSEntity.BloodDonor();
                    entity.BloodDonorId = dr.GetInt16(0);
                    entity.fName = dr.GetString(1);
                    entity.lName = dr.GetString(2);
                    entity.MobNum = dr.GetString(3);
                    entity.BloodGroup = dr.GetString(4);
                    entity.BdonorCity = dr.GetString(5);
                    donordetails.Add(entity);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return donordetails;
        }
        //adding donor details
        public bool AddDonor()
        {
            BBMSEntity.BloodDonor donor = new BBMSEntity.BloodDonor();
            BBMSEntity.BloodDonorDonation bdd = new BBMSEntity.BloodDonorDonation();
            bool donoradded = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_adddonor";
                cmd.Parameters.AddWithValue("@id", donor.BloodDonorId);
                cmd.Parameters.AddWithValue("@fname", donor.fName);
                cmd.Parameters.AddWithValue("@lname", donor.lName);
                cmd.Parameters.AddWithValue("@add", donor.BdonorAddr);
                cmd.Parameters.AddWithValue("@city", donor.BdonorCity);
                cmd.Parameters.AddWithValue("@mobileno", donor.MobNum);
                //cmd.Parameters.AddWithValue("@age", donor.Age);
                //cmd.Parameters.AddWithValue("@weight", donor.Weight);
                cmd.Parameters.AddWithValue("@bloodgroup", donor.BloodGroup);


                //cmd.Parameters.AddWithValue("@units", bdd.Units);
                cmd.Parameters.AddWithValue("@donationdate", bdd.BloodDonationDate);
                cmd.Parameters.AddWithValue("@hbcount", bdd.hbCount);
                cmd.Parameters.AddWithValue("@donationid", bdd.BloodDonationId);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    donoradded = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return donoradded;
        }

       

        public bool DelDonor()
        {
            BBMSEntity.BloodDonor donor = new BBMSEntity.BloodDonor();
            BBMSEntity.BloodDonorDonation bdd = new BBMSEntity.BloodDonorDonation();
            bool donordeleted = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_donordelete";
                cmd.Parameters.AddWithValue("@id", donor.BloodDonorId);
                cmd.Parameters.AddWithValue("@fname", donor.fName);
                cmd.Parameters.AddWithValue("@lname", donor.lName);
                cmd.Parameters.AddWithValue("@add", donor.BdonorAddr);
                cmd.Parameters.AddWithValue("@city", donor.BdonorCity);
                cmd.Parameters.AddWithValue("@mobileno", donor.MobNum);
                cmd.Parameters.AddWithValue("@age", donor.Age);
                cmd.Parameters.AddWithValue("@weight", donor.Weight);
                cmd.Parameters.AddWithValue("@bloodgroup", donor.BloodGroup);


                //cmd.Parameters.AddWithValue("@units", bdd.Units);
                cmd.Parameters.AddWithValue("@donationdate", bdd.BloodDonationDate);
                cmd.Parameters.AddWithValue("@hbcount", bdd.hbCount);
                cmd.Parameters.AddWithValue("@donationid", bdd.BloodDonationId);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    donordeleted = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return donordeleted;
        }

        //adding camp details
        public bool AddCampDetails()
        {
            BBMSEntity.BloodDonationCamp camp = new BBMSEntity.BloodDonationCamp();
            bool campadded = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_camp";
                //cmd.Parameters.AddWithValue("@bid", camp.BloodBankId);
                cmd.Parameters.AddWithValue("@cid", camp.BloodDonationCampId);
                cmd.Parameters.AddWithValue("@cname", camp.CampName);
                cmd.Parameters.AddWithValue("@cadd", camp.Addr);
                cmd.Parameters.AddWithValue("@startdate", camp.CampSDate);
                cmd.Parameters.AddWithValue("@enddate", camp.CampEDate);
                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    campadded = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return campadded;
        }

        public BBMSEntity.BloodDonationCamp GetCampDetailsById(int id)
        {
            BBMSEntity.BloodDonationCamp campdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_campbyid";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                campdetails = new BBMSEntity.BloodDonationCamp();
                while (dr.Read())
                {
                    BBMSEntity.BloodDonationCamp camp = new BBMSEntity.BloodDonationCamp();
                    //camp.BloodBankId = dr.GetInt32(0);
                    camp.BloodDonationCampId = dr.GetInt32(1);
                    camp.CampName = dr.GetString(2);
                    camp.Addr = dr.GetString(3);
                    camp.CampSDate = dr.GetDateTime(4);
                    camp.CampEDate = dr.GetDateTime(5);
                    
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return campdetails;
        }

        public bool UpdateCampDetails(BBMSEntity.BloodDonationCamp details)
        {
            bool campupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_campupdate";
                //cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                cmd.Parameters.AddWithValue("@cid", details.BloodDonationCampId);
                cmd.Parameters.AddWithValue("@cname", details.CampName);
                cmd.Parameters.AddWithValue("@city", details.City);
                cmd.Parameters.AddWithValue("@startdate", details.CampSDate);
                cmd.Parameters.AddWithValue("@endate", details.CampEDate);


                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    campupdate = true;
            }
            catch (Exception)
            {

                throw;
            }
            return campupdate;
        }

        //11-02-2018
        //displaying camp details for particular blood bank

        public BBMSEntity.BloodDonationCamp GetCampDetailsByBankId(int id)
        {
            BBMSEntity.BloodDonationCamp campdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bb_campview";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                campdetails = new BBMSEntity.BloodDonationCamp();
                while (dr.Read())
                {
                    BBMSEntity.BloodDonationCamp entity = new BBMSEntity.BloodDonationCamp();
                    entity.BloodDonationCampId = dr.GetInt32(0);
                    entity.BloodBankId = dr.GetInt32(1);
                    //entity.BBName = dr.GetString(2);
                    entity.CampName = dr.GetString(3);
                    entity.Addr = dr.GetString(4);
                    entity.CampSDate = dr.GetDateTime(5);
                    entity.CampEDate = dr.GetDateTime(6);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return campdetails;
        }

        //-----displaying donor for particular blood bank

        public BBMSEntity.BloodDonor GetDonorByBankId(int id)
        {
            BBMSEntity.BloodDonor donordetails = null;
            

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bb_donorview";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                donordetails = new BBMSEntity.BloodDonor();
               
                while (dr.Read())
                {
                    BBMSEntity.BloodDonor entity = new BBMSEntity.BloodDonor();
                
                    entity.BloodDonorId = dr.GetInt32(0);
                    entity.fName = dr.GetString(1);
                    entity.lName = dr.GetString(2);
                    entity.BdonorAddr = dr.GetString(3);
                    entity.BdonorCity = dr.GetString(4);
                    entity.MobNum = dr.GetString(5);
                    entity.BloodGroup = dr.GetString(6);
                    entity.units = dr.GetInt32(7);
                    entity.Weight = dr.GetInt32(8);
                    entity.BloodDonationDate = dr.GetDateTime(9);
                    entity.hbCount = dr.GetInt32(10);
                    entity.BloodDonationId = dr.GetInt32(11);
                    entity.BloodBankId = dr.GetInt32(12);

                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return donordetails;        
        }

        
         //---displaying inventory for particular blood bank
        public BBMSEntity.BloodInventory GetInventoryBankId(int id)
        {
            BBMSEntity.BloodInventory inventorydetails = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bb_inventoryview";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                inventorydetails = new BBMSEntity.BloodInventory();

                while (dr.Read())
                {
                    BBMSEntity.BloodInventory entity = new BBMSEntity.BloodInventory();

                    entity.BloodInventoryId = dr.GetInt32(0);
                    entity.BloodGroup = dr.GetString(1);
                    entity.NumOfBottles = dr.GetInt32(2);
                    entity.BloodBankId = dr.GetInt32(3);
                    entity.ExpDate = dr.GetDateTime(4);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return inventorydetails;
        }

        //---displaying request for blood bank

        public BBMSEntity.BloodRequest GetRequestBankId(int id)
        {
            BBMSEntity.BloodRequest requestdetails = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bb_requestview";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                requestdetails = new BBMSEntity.BloodRequest();

                while (dr.Read())
                {
                    BBMSEntity.BloodRequest entity = new BBMSEntity.BloodRequest();

                    entity.HospitalId = dr.GetInt32(0);
                    entity.HospitalName = dr.GetString(1);
                    entity.HospAddress= dr.GetString(2);
                    entity.HospCity = dr.GetString(3);
                    entity.HospRegion = dr.GetString(4);
                    entity.ReqDate = dr.GetDateTime(5);
                    entity.BloodGroup = dr.GetString(6);
                    entity.NoOfPackets = dr.GetInt32(7);
                    entity.BloodBankId = dr.GetInt32(8);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return requestdetails;
        }

       


    }  
}
