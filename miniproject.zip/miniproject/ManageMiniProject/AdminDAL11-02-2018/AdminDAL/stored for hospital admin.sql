create schema BBMS

1)-----table of blood inventory

create table BBMS.BloodInventory
(BloodInventoryId int primary key,BloodGroup varchar(5),NoOfBottles int,BloodBankId int,expirydate date,
Foreign key(bloodBankId) REFERENCES BBMS.BloodBank(BloodBankId))

drop table BBMS.BloodInventory


2)------table of Bloodbank


create table BBMS.BloodBank (BloodBankId int primary key,BloodBankname varchar(20),bbaddress varchar(50),bbregion varchar(20),bbcity varchar(20),
bbMobNo varchar(15),bbusername varchar(10),bbpass varchar(10))

select * from BBMS.BloodBank

insert into BBMS.BloodBank values(100100,'XYZ','ABC','IJK','Chirala','12345678','ABCD',1234)


drop table BBMS.BloodBank

3)----table of blood donation camp


create table BBMS.BloodDonationCamp(bloodDonationCamp int,campName varchar(50),donaddress varchar(50),campstartdate date,campenddate date);

4)----table of Hospital

create table BBMS.Hospital(hospitalid int,hospitalname varchar(20),hospaddress varchar(50),city varchar(15));

5)------table of Blood donor

drop table BBMS.BloodDonor

create table BBMS.BloodDonor(BloodDonorId int,firstname varchar(20),lastname varchar(20),
donoraddress varchar(50),city varchar(10),donormobnum varchar(15),age int,donorbloodgroup varchar(15),
units int,bweight int,bloodDonationdate date,hbCount float,blooddonationid int,bloodbankid int,foreign key(bloodbankid)
references BBMS.BloodBank(bloodbankid))

insert into BBMS.BloodDonor values(101,'Madhavi','Gangalakurthi','Sri','Reddy','7337037769',21,'O+ve',2,2,'02-02-1998',12,1001,100100)

select * from BBMS.BloodDonor

6)----table of BloodDonorDonation

--drop table BBMS.BloodDonorDonation
--create table BBMS.BloodDonorDonation(bloodDonationId int ,bloodDonorId int,bloodDonationdate date,
--numberOfBottle int,bloodweight float,
--hbCount float,foreign key(BloodDonorId) references BBMS.BloodDonor(BloodDonorId))

create table BBMS.AdminLogin(Username varchar(10),Password varchar(10));
insert into  BBMS.AdminLogin values('Admin','Admin');
---stored procedure for Admin login
go
create proc BBMS_AdminLogin @username varchar(10),@password varchar(10) as 
(select * from BBMS.AdminLogin)	
go

---------------Stored procedure for Adding Hospital details by admin
go
create proc hosp_add @hid int,@hname varchar(20),@haddress varchar(50),@hcity varchar(15) as 
insert into BBMS.Hospital(hospitalid,hospitalname,hospaddress,city) values(@hid,@hname,@haddress,@hcity)
go


---Stored procedure for adding hospital id and hospital name by admin


go 
create proc hospadm_add (@hid int,@hname varchar(20)) as
begin
insert into BBMS.Hospital(hospitalid,hospitalname) values(@hid,@hname)
end
go
------------------Stored Procedure for deleting Hosptital details by admin
go
create proc hosp_del (@hid int) as
begin
delete from BBMS.Hospital where hospitalid=@hid
end
go

---stored procedure for updating hospital details

go
create proc hosp_upd(@hid int,@hname varchar(20),@haddress varchar(50),@hcity varchar(15))
as
begin
update  BBMS.Hospital SET @hid=hospitalid,@hname=hospitalname,@haddress=hospaddress,@hcity=city
where hospitalid=@hid
end
go
---stored procedure for showing details of the hospitals

go
create proc hosp_show(@hid int)
as
begin
select * from BBMS.Hospital where hospitalid=@hid
end
go

