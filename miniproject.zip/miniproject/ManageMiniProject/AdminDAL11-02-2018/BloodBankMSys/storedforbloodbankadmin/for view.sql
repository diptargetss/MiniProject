
--stored procedure for showing inventory details
go
create procedure inventory_show
as
begin
select * from BBMS.BloodInventory
end
go

drop proc inventory_show
exec inventory_show
--stored procedure for showing donor details


go
create procedure donor_show
as
begin
select * from BBMS.BloodDonor
end
go

drop proc donor_show



go
create procedure camp_show
as
begin
select * from BBMS.BloodDonationCamp
end
go

drop proc camp_show
exec camp_show

select * from BBMS.BloodInventory

select * from BBMS.Hospital
select * from BBMS.BloodDonor

select * from BBMS.BloodBank


----------------------11-02-2018------------------------------

-----Stored procedure for displaying bloodbank details using region and num of bottles
go 
create proc request_view(@id int,@group varchar(5),@region varchar(20),@numofbottles int)
as
begin
select bb.BloodBankId,bb.BloodBankname,bb.bbregion,bb.bbaddress,bb.bbcity,bb.bbMobNo,bi.BloodGroup,bi.NoOfBottles from BBMS.BloodInventory bi,BBMS.Hospital h,BBMS.BloodBank bb where h.hospitalid=@id and bi.BloodGroup=@group and bb.bbregion=@region and bi.NoOfBottles>=@numofbottles and bb.BloodBankId=bi.BloodBankId 
end
go

insert into BBMS.BloodBank values(100101,'ABC','Mumbai','Thane','Maharastra','9949833837','madhu','reddy')
insert into BBMS.BloodBank values(100105,'ABC','Mumbai','kadap','Maharastra','9949833837','madhu','reddy')

drop proc request_view

exec request_view 1001,'O+ve','Chirala',5

-----Stored procedure for displaying bloodbank details using city and num of bottles
go 
create proc request_view1(@id int,@group varchar(5),@city varchar(20),@numofbottles int)
as
begin
select bb.BloodBankId,bb.BloodBankname,bb.bbregion,bb.bbaddress,bb.bbcity,bb.bbMobNo,bi.BloodGroup,bi.NoOfBottles from BBMS.BloodInventory bi,BBMS.Hospital h,BBMS.BloodBank bb where h.hospitalid=@id and bi.BloodGroup=@group and (bb.bbcity=@city and bi.NoOfBottles>=@numofbottles) and bb.BloodBankId=bi.BloodBankId 
end
go

exec request_view1 1001,'O+ve','Chirala',5

drop proc request_view1

---displaying donor details for hospital features



----displaying donor details in request grid 
go 
create proc request_donorview(@id int,@group varchar(5),@city varchar(20))
as
begin
select bd.BloodDonorId,bd.firstname,bd.lastname,bd.donoraddress,bd.city,bd.donormobnum,bd.units,
bd.bweight,bd.bloodDonationdate,bd.hbCount  from BBMS.BloodDonor bd,BBMS.Hospital h where h.hospitalid=@id and
bd.donorbloodgroup=@group and (bd.city=@city and bd.bloodDonationdate<=DATEADD(m,-3,Convert(date,convert(varchar(6),getdate())+'01')))
end
go

drop proc request_donorview

exec request_donorview 1002,'AB+ve','Mumbai'

select * from BBMS.BloodDonor

insert into BBMS.BloodDonor values(102,'harsha','sri','sadanala','Mumbai','787576',5,'AB+ve',3,88,'2018-11-13',13,102,100101)

insert into BBMS.BloodDonor values(103,'harsha','sri','sadanala','Mumbai','787576',5,'AB+ve',3,88,'2016-11-13',13,102,100101)


----displaying camp details for particular blood bank



go 
create proc bb_campview(@bbid int)
as
begin
select * from BBMS.BloodDonationCamp where bloodbankid=@bbid
end
go

-----displaying donor for particular blood bank


go 
create proc bb_donorview(@bbid int)
as
begin
select * from BBMS.BloodDonor where bloodbankid=@bbid
end
go


---displaying inventory for particular blood bank


go 
create proc bb_inventoryview(@bbid int)
as
begin
select * from BBMS.BloodInventory where BloodBankId=@bbid
end
go


---displaying request for blood bank


go 
create proc bb_requestview
as
begin
select * from BBMS.HospitalRequest
end
go

drop proc bb_requestview