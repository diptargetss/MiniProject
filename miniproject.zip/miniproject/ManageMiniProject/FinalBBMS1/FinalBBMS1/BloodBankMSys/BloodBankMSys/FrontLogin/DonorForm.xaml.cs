﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.Entities;
using BBMS.Exceptions;
using BBMS.BL;
namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for DonarForm.xaml
    /// </summary>
    public partial class DonarForm : Window
    {
        int bbid;
        public DonarForm(int id)
        {
            InitializeComponent();
            bbid = id;
        }
        DonorBL bbl = null;
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btndonoradd_Click(object sender, RoutedEventArgs e)
        {
            Donor dr=new Donor();
            dr.Address = txtaddress.Text;
            dr.Age = Convert.ToInt32(txtage.Text);
            dr.BloodBankID=bbid;
            dr.BloodGroup = bgrp.SelectedValue.ToString();
            dr.City = txtcity.Text;
            dr.DonationDate = Convert.ToDateTime(dpdonate.SelectedDate);
            dr.DonationID = Convert.ToInt32(txtdonationid.Text);
            dr.firstname = txtfirstname.Text;
            dr.lastname = txtlastname.Text;
            dr.HBcount = Convert.ToInt32(txthbcount.Text);
            dr.NoOfBottles = 1;
            dr.Weight = Convert.ToInt32(txtweight.Text);
            dr.Mobile = txtmobile.Text;
            dr.DonorID = Convert.ToInt32(txtdonorid.Text);

            bbl = new DonorBL();
            if (bbl.DonorAdd(dr))
                MessageBox.Show("Added Successfully");
            else
                MessageBox.Show("Failed to Add Donor");
            


        }

        private void btndonorupd_Click(object sender, RoutedEventArgs e)
        {
            Donor dr = new Donor();
            dr.Address = txtaddress.Text;
            dr.Age = Convert.ToInt32(txtage.Text);
            dr.BloodBankID = bbid;
            dr.BloodGroup = bgrp.SelectedValue.ToString();
            dr.City = txtcity.Text;
            dr.DonationDate = Convert.ToDateTime(dpdonate.SelectedDate);
            dr.DonationID = Convert.ToInt32(txtdonationid.Text);
            dr.firstname = txtfirstname.Text;
            dr.lastname = txtlastname.Text;
            dr.HBcount = Convert.ToInt32(txthbcount.Text);
            dr.NoOfBottles = 1;
            dr.Weight = Convert.ToInt32(txtweight.Text);
            dr.Mobile = txtmobile.Text;
            dr.DonorID = Convert.ToInt32(txtdonorid.Text);
            
            bbl=new DonorBL();
            if (bbl.DonorUpdate(dr))
                MessageBox.Show("Donor Details updated");
            else
                MessageBox.Show("Failed to update Donor");
        }


        private void btndonordel_Click(object sender, RoutedEventArgs e)
        {
            Donor dr = new Donor();
            dr.Address = txtaddress.Text;
            dr.Age = Convert.ToInt32(txtage.Text);
            dr.BloodBankID = bbid;
            dr.BloodGroup = bgrp.SelectedValue.ToString();
            dr.City = txtcity.Text;
            dr.DonationDate = Convert.ToDateTime(dpdonate.SelectedDate);
            dr.DonationID = Convert.ToInt32(txtdonationid.Text);
            dr.firstname = txtfirstname.Text;
            dr.lastname = txtlastname.Text;
            dr.HBcount = Convert.ToInt32(txthbcount.Text);
            dr.NoOfBottles = 1;
            dr.Weight = Convert.ToInt32(txtweight.Text);
            dr.Mobile = txtmobile.Text;
            dr.DonorID = Convert.ToInt32(txtdonorid.Text);
            bbl = new DonorBL();
            if (bbl.DonorDelete(dr))
                MessageBox.Show("Donor Details deleted");
            else
                MessageBox.Show("Failed to delete Donor");
        }

        private void btnviewdonor_Click(object sender, RoutedEventArgs e)
        {
            Donor df = new Donor();
            df.DonorID = Convert.ToInt32(txtdonorid.Text);
            Donor d = bbl.SearchDonorById(df);
            if(d!=null)
            {
                txtfirstname.Text = d.firstname;
                txtlastname.Text = d.lastname;
                txtmobile.Text = d.Mobile;
                txtweight.Text = d.Weight.ToString();
                txthbcount.Text = d.HBcount.ToString();
                txtdonationid.Text = d.DonationID.ToString();
                dpdonate.DisplayDate = d.DonationDate;
                txtage.Text = d.Age.ToString();
                txtaddress.Text = d.Address;
                txtcity.Text = d.City;

                bgrp.SelectedItem = d.BloodGroup;

            }
        }


    }
}
