﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BBMS.Entities;
using BBMS.Exceptions;

namespace BBDAL
{
    public class DonorDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        public bool AddDonor(Donor donor)
        {
            bool donoradded = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_adddonor";
                cmd.Parameters.AddWithValue("@id", donor.DonorID);
                cmd.Parameters.AddWithValue("@fname", donor.firstname);
                cmd.Parameters.AddWithValue("@lname", donor.lastname);
                cmd.Parameters.AddWithValue("@add", donor.Address);
                cmd.Parameters.AddWithValue("@city", donor.City);
                cmd.Parameters.AddWithValue("@mobileno", donor.Mobile);
                cmd.Parameters.AddWithValue("@age", donor.Age);
                cmd.Parameters.AddWithValue("@weight", donor.Weight);
                cmd.Parameters.AddWithValue("@bloodgroup", donor.BloodGroup);
                cmd.Parameters.AddWithValue("@units", donor.NoOfBottles);
                cmd.Parameters.AddWithValue("@donationdate", donor.DonationDate);
                cmd.Parameters.AddWithValue("@hbcount", donor.HBcount);
                cmd.Parameters.AddWithValue("@donationid", donor.DonationID);
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    donoradded = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return donoradded;
        }

        public bool DelDonor(Donor donor)
        {
            bool donordeleted = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_donordelete";
                cmd.Parameters.AddWithValue("@id", donor.DonorID);
                cmd.Parameters.AddWithValue("@fname", donor.firstname);
                cmd.Parameters.AddWithValue("@lname", donor.lastname);
                cmd.Parameters.AddWithValue("@add", donor.Address);
                cmd.Parameters.AddWithValue("@city", donor.City);
                cmd.Parameters.AddWithValue("@mobileno", donor.Mobile);
                cmd.Parameters.AddWithValue("@age", donor.Age);
                cmd.Parameters.AddWithValue("@weight", donor.Weight);
                cmd.Parameters.AddWithValue("@bloodgroup", donor.BloodGroup);
                //cmd.Parameters.AddWithValue("@units", bdd.Units);
                cmd.Parameters.AddWithValue("@donationdate", donor.DonationDate);
                cmd.Parameters.AddWithValue("@hbcount", donor.HBcount);
                cmd.Parameters.AddWithValue("@donationid", donor.DonationID);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    donordeleted = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return donordeleted;
        }
        public bool UpdateDonor(Donor d)
        {
            bool updated = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_update";
                cmd.Parameters.AddWithValue("@id", d.DonorID);
                cmd.Parameters.AddWithValue("@fname", d.firstname);
                cmd.Parameters.AddWithValue("@lname", d.lastname);
                cmd.Parameters.AddWithValue("@add", d.Address);
                cmd.Parameters.AddWithValue("@city", d.City);
                cmd.Parameters.AddWithValue("@mobileno", d.Mobile);
                cmd.Parameters.AddWithValue("@age", d.Age);
                cmd.Parameters.AddWithValue("@weight", d.Weight);
                cmd.Parameters.AddWithValue("@bloodgroup", d.BloodGroup);
                cmd.Parameters.AddWithValue("@units", d.NoOfBottles);
                cmd.Parameters.AddWithValue("@donationdate", d.DonationDate);
                cmd.Parameters.AddWithValue("@hbcount", d.HBcount);
                cmd.Parameters.AddWithValue("@donationid", d.DonationID);
                cmd.Parameters.AddWithValue("@bloodbankid", d.BloodBankID);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                
                if (result > 0)
                    updated = true;
                con.Close();
            }
            catch (SqlException s)
            {
                throw s;
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return updated;
        }
        public Donor SearchDonorById(Donor d)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_DonorSearchById";
                cmd.Parameters.AddWithValue("@id", d.DonorID);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    d = new Donor();
                    d.firstname = dr.GetString(0);
                    d.lastname = dr.GetString(1);
                    d.Address = dr.GetString(2);
                    d.City = dr.GetString(3);
                    d.Mobile = dr.GetString(4);
                    d.Age = dr.GetInt32(5);
                    d.Weight = dr.GetInt32(6);
                    d.BloodGroup = dr.GetString(7);
                    d.NoOfBottles = dr.GetInt32(8);
                    d.DonationDate = dr.GetDateTime(9);
                    d.HBcount = dr.GetInt32(10);
                    d.DonationID = dr.GetInt32(11);
                    d.BloodBankID = dr.GetInt32(12);
                }
                dr.Read();
                con.Close();
            }
            catch (SqlException s)
            {
                throw s;
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
                con.Close();
            }
            return d;
        }
    }
}
