﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Entity
{
    public class Donor
    {
        public int DonorID { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Mobile { get; set; }
        public string BloodGroup { get; set; }
        public int Age { get; set; }
        public int Weight { get; set; }
        public int DonationID { get; set; }
        public DateTime DonationDate { get; set; }
        public int NoOfBottles { get; set; }
        public int BloodBankID { get; set; }
        public int HBcount { get; set; }
    }
}
