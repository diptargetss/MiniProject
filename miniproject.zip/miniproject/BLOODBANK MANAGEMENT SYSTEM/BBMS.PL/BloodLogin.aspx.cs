﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class BloodLogin : System.Web.UI.Page
    {
        LoginBL bbl = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                Bloodbank bb = new Bloodbank();
                bb.BloodBankUserId= txtuser.Text;
                bb.BloodBankPwd = txtpasswd.Text;
                bbl = new LoginBL();
                int id=bbl.ValidateBankLogin(bb);
                if (id!=0)
                {
                    Response.Redirect("BloodBank.aspx");
                    Session["user"] = id;
                }
                else
                {
                    lblmsg.Text = "Incorrect username or password entered";
                    txtuser.Text = "";
                    txtpasswd.Text = "";
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception v)
            {
                lblmsg.Text = v.Message;
            }
        }
    }
}