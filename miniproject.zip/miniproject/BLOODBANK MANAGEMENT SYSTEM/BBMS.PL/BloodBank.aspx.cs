﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class BloodBank : System.Web.UI.Page
    {
        AdminBloodBL abl = new AdminBloodBL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                Bloodbank bb = new Bloodbank();
                if (txtaddid.Text == string.Empty || txtbbankname.Text == string.Empty)
                {

                    lblmsg.Text = "Values cannot be null ";
                }
                else
                {
                    bb.BloodBankId = Convert.ToInt32(txtaddid.Text);
                    bb.BloodBankname = txtbbankname.Text;
                    if (abl.AddBankIdName(bb))
                    {
                        lblmsg.Text = "Added Successfully...";
                        txtaddid.Text = "";
                        txtbbankname.Text = "";
                    }
                    else
                    {
                        lblmsg.Text = "Failed to add record...";
                        txtaddid.Text = "";
                        txtbbankname.Text = "";
                    }
                }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception v)
            {
                lblmsg.Text = v.Message;
            }
        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            RequiredFieldValidator1.Enabled = false;
            RequiredFieldValidator2.Enabled = false;

            try
            {
                Bloodbank bb = new Bloodbank();
                bb.BloodBankId = Convert.ToInt32(txtviewid.Text);
                bb=abl.GetBankDetailsById(bb);
                if (bb!=null)
                {
                    lblview.Text = "Record found";
                    txtname.Text = bb.BloodBankname;
                    txtaddr.Text = bb.Baddress;
                    txtreg.Text = bb.BRegion;
                    txtcity.Text = bb.BloodBankCity;
                    txtcon.Text = bb.BloodBankMobNo;
                    lblmsg.Text = "";
                }
                else
                {
                    lblview.Text = "Record not found";
                    txtviewid.Text = "";
                    lblmsg.Text = "";
                }
            }
            catch (BloodExceptions b)
            {
                lblview.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblview.Text = s.Message;
            }
            catch (Exception v)
            {
                lblview.Text = v.Message;
            }            
        }

        protected void btnmodify_Click(object sender, EventArgs e)
        {
            try
            {
                Bloodbank bk = new Bloodbank();
                bk.BloodBankId = Convert.ToInt32(txtviewid.Text);
                bk.BloodBankname = txtname.Text;
                bk.Baddress = txtaddr.Text;
                bk.BRegion = txtreg.Text;
                bk.BloodBankCity = txtcity.Text;
                bk.BloodBankMobNo = txtcon.Text;

                if (abl.UpdateBankDetails(bk))
                {
                    lblmodify.Text="Modified Successfully...";
                    txtviewid.Text = "";
                    txtname.Text = "";
                    txtaddr.Text = "";
                    txtcity.Text = "";
                    txtreg.Text = "";
                    txtcon.Text = "";
                    lblmsg.Text = "";
                    lblview.Text = "";
                }
                else
                {
                    lblmodify.Text = "Failed to modify...";
                    lblmsg.Text = "";
                    lblview.Text = "";
                    txtviewid.Text = "";
                    txtname.Text = "";
                    txtaddr.Text = "";
                    txtcity.Text = "";
                    txtreg.Text = "";
                    txtcon.Text = "";
                    lblmsg.Text = "";
                    lblview.Text = "";
                }
            }
            catch (BloodExceptions b)
            {
                lblmodify.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmodify.Text = s.Message;
            }
            catch (Exception v)
            {
                lblmodify.Text = v.Message;
            }  
        }

        protected void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                Bloodbank bb = new Bloodbank();
                bb.BloodBankId = Convert.ToInt32(txtviewid.Text);
                
                if(abl.DelBankDetails(bb))
                {
                    lbldel.Text = "Record Deleted...";
                    txtviewid.Text = "";
                    txtname.Text = "";
                    txtaddr.Text = "";
                    txtcity.Text = "";
                    txtreg.Text = "";
                    txtcon.Text = "";
                    lblmsg.Text = "";
                    lblview.Text = "";
                    lblmodify.Text = "";

                }
                else
                {
                    lbldel.Text = "Record Not Deleted...";
                    txtviewid.Text = "";
                    txtname.Text = "";
                    txtaddr.Text = "";
                    txtcity.Text = "";
                    txtreg.Text = "";
                    txtcon.Text = "";
                    lblmsg.Text = "";
                    lblview.Text = "";
                    lblmodify.Text = "";
                }
            }
            catch (BloodExceptions b)
            {
                lbldel.Text = b.Message;
            }
            catch (SqlException s)
            {
                lbldel.Text = s.Message;
            }
            catch (Exception v)
            {
                lbldel.Text = v.Message;
            }
        }

    }
}