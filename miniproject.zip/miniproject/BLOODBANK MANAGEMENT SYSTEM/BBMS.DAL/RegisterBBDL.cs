﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.Exceptions;
using BBMS.Entity;

namespace BBMS.DAL
{
    public class RegisterBBDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        public bool CheckAvailability(Bloodbank bb)
        {
            bool valid = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_checkavailbankuser";
                cmd.Parameters.AddWithValue("@bbuser", bb.BloodBankUserId);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    valid = true;
                    con.Close();
                }
            }
            catch(BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return valid;
        }
        public bool RegisterBloodBank(Bloodbank bb)
        {
            bool added = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_bloodbankreg";
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankId);
                cmd.Parameters.AddWithValue("@bname", bb.Baddress);
                cmd.Parameters.AddWithValue("@bname", bb.BRegion);
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankCity);
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankMobNo);
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankUserId);
                cmd.Parameters.AddWithValue("@bname", bb.BloodBankPwd);
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    added = true;
                }
            }
            catch(BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return added;
        }
    }
}
