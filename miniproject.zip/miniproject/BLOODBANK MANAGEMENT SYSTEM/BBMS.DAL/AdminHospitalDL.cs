﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entity;
using BBMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace BBMS.DAL
{
    public class AdminHospitalDL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        //add hospital details
        public bool AddHospIdName(Hospitals h)
        {
            bool hospadd = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hospadm_add";
                cmd.Parameters.AddWithValue("@hid",h.Hospitalid);
                cmd.Parameters.AddWithValue("@hname",h.Hospitalname);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    hospadd = true;
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return hospadd;
        }

        public bool UpdateHospitalDetails(Hospitals details)
        {
            bool hospupdate = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_upd";
                cmd.Parameters.AddWithValue("@hid", details.Hospitalid);
                cmd.Parameters.AddWithValue("@hname", details.Hospitalname);
                cmd.Parameters.AddWithValue("@haddress", details.HospitalAddress);
                cmd.Parameters.AddWithValue("@hcity", details.HospitalCity);
                cmd.Parameters.AddWithValue("@region", details.Location);
                cmd.Parameters.AddWithValue("@contact", details.ContactNo);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    hospupdate = true;
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return hospupdate;
        }

        public Hospitals GetHospDetailsById(int id)
        {
            Hospitals hospdetails = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_showbyid";
                cmd.Parameters.AddWithValue("@hid", id);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                //hospdetails = new Hospital();
                while (dr.Read())
                {
                    hospdetails = new Hospitals();
                    hospdetails.Hospitalid = dr.GetInt32(0);
                    hospdetails.Hospitalname = dr.GetString(1);
                    hospdetails.HospitalAddress = dr.GetString(2);
                    hospdetails.HospitalCity = dr.GetString(3);
                    hospdetails.Location = dr.GetString(4);
                    hospdetails.ContactNo = dr.GetString(5);
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return hospdetails;
        }

        public bool DelHospitalDetails(Hospitals h)
        {
            bool hospdel = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_del";
                cmd.Parameters.AddWithValue("@hid", h.Hospitalid);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    hospdel = true;
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return hospdel;
        }
    }
}
