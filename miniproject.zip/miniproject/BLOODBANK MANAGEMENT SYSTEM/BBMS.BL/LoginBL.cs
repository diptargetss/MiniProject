﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.DAL;

namespace BBMS.BL
{
    public class LoginBL
    {
        LoginDL bbda = new LoginDL();

        public bool AdminCheck(AdminLogin admin)
        {
            return bbda.AdminCheck(admin);
        }

        public int ValidateBankLogin(Bloodbank bb)
        {
            return bbda.ValidateBankLogin(bb);
        }
    }
}
