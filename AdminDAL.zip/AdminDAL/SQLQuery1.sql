create table Madhavi_142354.product(categoryid int references Madhavi_142354.Category(categoryid)
,productid int,productname varchar(10),unitprice float,unitsinstock float)

create table Madhavi_142354.Category(categoryid int primary key,categoryname varchar(10))

insert into Madhavi_142354.Category values(1,'Wheat')
insert into Madhavi_142354.Category values(2,'Rice')
insert into Madhavi_142354.Category values(3,'Bread')

insert into Madhavi_142354.product values(1,1,'XYZ',2000,20001)
insert into Madhavi_142354.product values(2,2,'ABC',12.24,1255)
insert into Madhavi_142354.product values(3,3,'IJK',17.34,10000)

select * from Madhavi_142354.product