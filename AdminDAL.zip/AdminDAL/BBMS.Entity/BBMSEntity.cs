﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Entity
{
    public class BBMSEntity
    {
        public class BBank
        {
            public int BloodBankId { get; set; }
            public string BloodBankname { get; set; }
            public string Baddress { get; set; }
            public string BRegion { get; set; }
            public string BloodBankCity { get; set; }
            public string BloodBankMobNo { get; set; }
            public int BloodBankUserId { get; set; }
            public string BloodBankPwd { get; set; }
        }
        public class BloodInventory
        {
            public int BloodInventoryId { get; set; }
            public string BloodGroup { get; set; }
            public int NumOfBottles { get; set; }
            public int BloodBankId { get; set; }
            public DateTime ExpDate { get; set; }
        }
        public class Hospital
        {
            public int hospitalid;
            public int HospitalId
            {
                get
                {
                    return hospitalid;
                }
                set { hospitalid = value; }
            }
            public string Hospitalname { get; set; }
            public string HospitalAddress { get; set; }
            public string HospitalCity { get; set; }
        }
        public class BloodDonorDonation
        {
            public int BloodDonationId { get; set; }
            public int BloodDonorId { get; set; }
            public DateTime BloodDonationDate { get; set; }
            public int NumOfBottles { get; set; }
            public double Weight { get; set; }
            public double hbCount { get; set; }
        }
        public class BloodDonor
        {
            public int BloodDonorId { get; set; }
            public string fName { get; set; }
            public string lName { get; set; }
            public string BdonorAddr { get; set; }
            public string BdonorCity { get; set; }
            public string MobNum { get; set; }
            public string BloodGroup { get; set; }
        }
        public class BloodDonationCamp
        {
            public int BloodDonationCampId { get; set; }
            public string CampName { get; set; }
            public string Addr { get; set; }
            public string City { get; set; }
            public string BBName { get; set; }
            public DateTime CampSDate { get; set; }
            public DateTime CampEDate { get; set; }
        }
        public class Login
        {
            string username;
            string password;

            public string Password
            {
                get { return password; }
                set { password = value; }
            }

            public string Username
            {
                get { return username; }
                set { username = value; }
            }
        }
    }

}
