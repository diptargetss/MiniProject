﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using BBMS.Entity;
using BBMS.Exception;


namespace AdminBBMSdal
{
    public class BBMSDAL
    {
        SqlConnection con =
             new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        public bool LoginCredentials(BBMSEntity.Login login)//For admin login (username and password is 'Admin')
        {

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BBMS_AdminLogin";
                cmd.Parameters.AddWithValue("@username", login.Username);
                cmd.Parameters.AddWithValue("@password", login.Password);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
        }

        //public bool AddHospitalDetails(BBMSEntity.Hospital details)
        //{
        //    bool hospadd = false;

        //    try
        //    {
        //        cmd = new SqlCommand();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "hosp_add";
        //        cmd.Parameters.AddWithValue("@hid", details.HospitalId);
        //        cmd.Parameters.AddWithValue("@hname", details.Hospitalname);
        //        cmd.Parameters.AddWithValue("@haddress", details.HospitalAddress);
        //        cmd.Parameters.AddWithValue("@hcity", details.HospitalCity);
        //        cmd.Connection = con;

        //        con.Open();

        //        int result = cmd.ExecuteNonQuery();

        //        con.Close();

        //        if (result > 0)
        //            hospadd = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new BBMSException(ex.Message);
        //    }

        //    return hospadd;
        //}

        public bool AddHospIdName(int id,string hname)
        {
            bool hospadd = false;
                        try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hospadm_add";
                cmd.Parameters.AddWithValue("@hid", id);
                cmd.Parameters.AddWithValue("@hname", hname);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospadd = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return hospadd;
        }
     

        public bool DelHospitalDetails(int id)
        {
            bool hospadd = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_del";
                cmd.Parameters.AddWithValue("@hid",id);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospadd = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return hospadd;
        }
        public bool UpdateHospitalDetails(BBMSEntity.Hospital details)
        {
            bool hospupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_upd";
                cmd.Parameters.AddWithValue("@hid", details.HospitalId);
                cmd.Parameters.AddWithValue("@hname", details.Hospitalname);
                cmd.Parameters.AddWithValue("@haddress", details.HospitalAddress);
                cmd.Parameters.AddWithValue("@hcity", details.HospitalCity);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    hospupdate = true;
            }
            catch (Exception)
            {

                throw;
            }
            return hospupdate;
        }

        public List<BBMSEntity.Hospital> GetHospDetails()
        {
            List<BBMSEntity.Hospital> hospdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                hospdetails = new List<BBMSEntity.Hospital>();
                while (dr.Read())
                {
                    BBMSEntity.Hospital entity = new BBMSEntity.Hospital();
                    entity.HospitalId = dr.GetInt32(0);
                    entity.Hospitalname = dr.GetString(1);
                    entity.HospitalAddress = dr.GetString(2);
                    entity.HospitalCity = dr.GetString(3);
                    hospdetails.Add(entity);

                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return hospdetails;
        }
        


        //Bank Admin

        public bool AddBankIdName(int id, string bname)
        {
            bool bankadd = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bankadm_add";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Parameters.AddWithValue("@bname", bname);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankadd = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return bankadd;
        }

        public bool DelBankDetails(int id)
        {
            bool bankdel = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_del";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankdel = true;
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }

            return bankdel;
        }
        public bool UpdateBankDetails(BBMSEntity.BBank details)
        {
            bool bankupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_upd";
                cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                cmd.Parameters.AddWithValue("@bname", details.BloodBankname);
                cmd.Parameters.AddWithValue("@baddress", details.Baddress);
                cmd.Parameters.AddWithValue("@bcity", details.BloodBankCity);
                cmd.Parameters.AddWithValue("@bno", details.BloodBankMobNo);

                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankupdate = true;
            }
            catch (Exception)
            {

                throw;
            }
            return bankupdate;
        }
        public List<BBMSEntity.BBank> GetBankDetails()
        {
            List<BBMSEntity.BBank> bankdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                bankdetails = new List<BBMSEntity.BBank>();
                while (dr.Read())
                {
                    BBMSEntity.BBank entity = new BBMSEntity.BBank();
                    entity.BloodBankId = dr.GetInt32(0);
                    entity.BloodBankname = dr.GetString(1);
                    entity.Baddress = dr.GetString(2);
                    entity.BRegion = dr.GetString(3);
                    entity.BloodBankCity = dr.GetString(4);
                    entity.BloodBankMobNo = dr.GetString(5);
                    bankdetails.Add(entity);

                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return bankdetails;
        }


        //Blood Bank Inventory

        public List<BBMSEntity.BloodInventory> GetInventoryDetails()
        {
            List<BBMSEntity.BloodInventory> invdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "inventory_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                invdetails = new List<BBMSEntity.BloodInventory>();
                while (dr.Read())
                {
                   BBMSEntity.BloodInventory entity = new BBMSEntity.BloodInventory();
                   entity.BloodInventoryId = dr.GetInt32(0);
                   entity.BloodBankId = dr.GetInt32(1);
                   entity.BloodGroup = dr.GetString(2);
                   entity.NumOfBottles = dr.GetInt32(3);
                   entity.ExpDate = dr.GetDateTime(4);
                   invdetails.Add(entity);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return invdetails;
        }
        

        //Camp 

        public List<BBMSEntity.BloodDonationCamp> GetDonationCampDetails()
        {
            List<BBMSEntity.BloodDonationCamp> campdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "camp_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                campdetails = new List<BBMSEntity.BloodDonationCamp>();
                while (dr.Read())
                {
                    BBMSEntity.BloodDonationCamp entity = new BBMSEntity.BloodDonationCamp();
                    entity.BloodDonationCampId = dr.GetInt16(0);
                    entity.CampName = dr.GetString(1);
                    entity.City = dr.GetString(2);
                    entity.Addr = dr.GetString(3);
                    entity.BBName = dr.GetString(4);
                    entity.CampSDate = dr.GetDateTime(5);
                    entity.CampEDate = dr.GetDateTime(6);
                    campdetails.Add(entity);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return campdetails;
        }
        //donor details
        public List<BBMSEntity.BloodDonor> GetDonorDetails()
        {
            List<BBMSEntity.BloodDonor> donordetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "donor_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                donordetails = new List<BBMSEntity.BloodDonor>();
                while (dr.Read())
                {
                    BBMSEntity.BloodDonor entity = new BBMSEntity.BloodDonor();
                    entity.BloodDonorId = dr.GetInt16(0);
                    entity.fName = dr.GetString(1);
                    entity.lName = dr.GetString(2);
                    entity.MobNum = dr.GetString(3);
                    entity.BloodGroup = dr.GetString(4);
                    entity.BdonorCity = dr.GetString(5);
                    donordetails.Add(entity);
                }
            }
            catch (Exception ex)
            {
                throw new BBMSException(ex.Message);
            }
            return donordetails;
        }
    }  
}
