create schema BBMS

1)-----table of blood inventory

create table BBMS.BloodInventory
(BloodInventoryId int primary key,BloodGroup varchar(5),NoOfBottles int,BloodBankId int,expirydate date)

insert into BBMS.BloodInventory values(1,'O+ve',5,100100,'07-08-2018')

insert into BBMS.BloodInventory values(2,'AB+ve',5,100101,'07-09-2018')

drop table BBMS.BloodInventory

---Foreign key(bloodBankId) REFERENCES BBMS.BloodBank(BloodBankId)
2)------table of Bloodbank


create table BBMS.BloodBank (BloodBankId int primary key,BloodBankname varchar(20),bbaddress varchar(50),bbregion varchar(20),bbcity varchar(20),
bbMobNo varchar(15))

insert into BBMS.BloodBank values(100100,'ABC','ABC Apartments','Airoli','Mumbai',7893360561)

insert into BBMS.BloodBank values(100101,'DEF','DEF Apartments','Mulund','Mumbai',7893360562)


drop table BBMS.BloodBank

3)----table of blood donation camp


create table BBMS.BloodDonationCamp(bloodDonationCamp int,campName varchar(50),donaddress varchar(50),campstartdate date,campenddate date);

insert into BBMS.BloodDonationCamp values(1001,'harsha','chirala','07-08-2015','12-08-21996')
insert into BBMS.BloodDonationCamp values(1002,'Madhu','Amalapuram','07-09-2015','12-09-2015')

4)----table of Hospital

create table BBMS.Hospital(hospitalid int,hospitalname varchar(20),hospaddress varchar(50),city varchar(15),region varchar(20),contact varchar(15));

insert into BBMS.Hospital values(1001,'Appolo','Hyderabad','Andhra pradesh','Kadap','1234567890')

insert into BBMS.Hospital values(1002,'KIMS','Hyderabad','Andhra pradesh','Tirupati','9876543210')

select * from  BBMS.Hospital

drop table  BBMS.Hospital

5)------table of Blood donor

create table BBMS.BloodDonor(BloodDonorId int primary key,firstname varchar(20),lastname varchar(20),
donoraddress varchar(50),donorcity varchar(20),donormobnum varchar(15),donorbloodgroup varchar(5),age int,weights int)

insert into BBMS.BloodDonor values(10001,'Latha','Reddy','Kadapa','SPuram',7893360561,'O+ve',22,60)

insert into BBMS.BloodDonor values(10002,'Madhu','Reddy','chirala','Rangasthalam',7893360562,'B+ve',23,70)

drop table BBMS.BloodDonor

6)----table of BloodDonorDonation

create table BBMS.BloodDonorDonation(bloodDonationId int ,bloodDonorId int,bloodDonationdate date,
numberOfBottle int,bloodweight float,
hbCount float,units int,foreign key(BloodDonorId) references BBMS.BloodDonor(BloodDonorId))

drop table BBMS.BloodDonorDonation

create table BBMS.AdminLogin(Username varchar(10),Passwrd varchar(10));
insert into  BBMS.AdminLogin values('admin','admin');
select * from BBMS.AdminLogin
drop table BBMS.AdminLogin
---stored procedure for Admin login
go
create proc BBMS_AdminLogin (@username varchar(10),@password varchar(10)) as 
(select * from BBMS.AdminLogin where Username=@username and Passwrd=@password)	
go

drop proc BBMS_AdminLogin
exec BBMS_AdminLogin 'admin1','Admin'

---------------Stored procedure for Adding Hospital details by admin
go
create proc hosp_add @hid int,@hname varchar(20),@haddress varchar(50),@hcity varchar(15) as 
insert into BBMS.Hospital(hospitalid,hospitalname,hospaddress,city) values(@hid,@hname,@haddress,@hcity)
go


---Stored procedure for adding hospital id and hospital name by admin


go 
create proc hospadm_add (@hid int,@hname varchar(20)) as
begin
insert into BBMS.Hospital(hospitalid,hospitalname) values(@hid,@hname)
end
go
------------------Stored Procedure for deleting Hosptital details by admin
go
create proc hosp_del (@hid int) as
begin
delete from BBMS.Hospital where hospitalid=@hid
end
go

---stored procedure for updating hospital details

go
create proc hosp_upd(@hid int,@hname varchar(20),@haddress varchar(50),@hcity varchar(15))
as
begin
update  BBMS.Hospital SET hospitalname=@hname,hospaddress=@haddress,city=@hcity
where hospitalid=@hid
end
go

select * from BBMS.Hospital
exec hosp_upd 1001,'AIIMS','312 MG','Delhi'
drop proc hosp_upd
---stored procedure for showing details of the hospitals by id

go
create proc hosp_showbyid(@hid int)
as
begin
select * from BBMS.Hospital where hospitalid=@hid
end
go

--stored procedure for showing all details---


go
create procedure hosp_showall
as
begin
select * from BBMS.Hospital
end
go

drop proc hosp_showall
exec hosp_showall


go
create proc BBMS_BBLogin (@username varchar(10),@password varchar(10)) as 
(select * from BBMS.BloodLogin where Username=@username and Passwrd=@password)	
go
