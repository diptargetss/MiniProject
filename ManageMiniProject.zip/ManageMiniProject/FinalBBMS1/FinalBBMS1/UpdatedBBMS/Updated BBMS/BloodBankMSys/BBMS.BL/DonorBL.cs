﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class DonorBL
    {
        DonorDL bbda = new DonorDL();
        //Donor Add
        public bool DonorAdd(Donor d)
        {
            //if(d.Address==""||d.BloodGroup!)
            return bbda.AddDonor(d);
        }


        //Donor Update
        public bool DonorUpdate(Donor d)
        {
            DonorDL ddl = new DonorDL();

            if (d.DonorID != null || d.DonationID != null || d.Address != null || d.Age != null || d.BloodGroup != null || d.City != null || d.BloodBankID != null
                || d.firstname != null || d.lastname != null || d.Mobile != null || d.Weight != null || d.NoOfBottles != null)
                return ddl.UpdateDonor(d);
            else
                return false;
        }
        public bool DonorDelete(Donor d)
        {
            return bbda.DelDonor(d);
        }
        
    }
}
