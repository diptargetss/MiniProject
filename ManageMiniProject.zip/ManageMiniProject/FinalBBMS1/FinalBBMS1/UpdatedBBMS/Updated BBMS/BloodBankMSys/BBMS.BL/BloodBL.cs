﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class BloodBL
    {
        //AdminBloodbank bbda = null;
        //DonorDL ddl = new DonorDL();
        //AdminHospital adh = new AdminHospital();
        //InventoryDAL idl = new InventoryDAL();
        //CampDAL c = new CampDAL();

        BloodBankDA bbd = null;
        AdminBBMSDAL abbms = null;
        public BloodBL()
        {
            bbd = new BloodBankDA();
            abbms = new AdminBBMSDAL();
        }
        
        
        
       
        
        
        //public bool BloodRequest(Hospital hos,int units)
        //{
        //    bool ch=bbda.RequestCheck(hos.Location,units);
        //    return ch;
        //}


        public List<Donor> ShowDonors(int bbid)
        {
            return bbd.ShowDonors(bbid);
        }


       

     
        
        //public List<Bloodbank> GetBankDetails()
        //{
        //    return c.GetBankDetails();
        //}

        //Get bank details by id
        


        public List<BloodInventory> GetInventoryDetails()
        {
            return abbms.GetInventoryDetails();
        }

        //Get All Camp details for admin
        public List<BloodCamp> GetDonationCampDetails()
        {
            return abbms.GetDonationCampDetails();
        }
        
        //Get all donor details for admin
        public List<Donor> GetDonorDetails()
        {
            return abbms.GetDonorDetails();
        }

       
       
    }
}
