﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using BBMS.Entities;
using BBMS.Exceptions;

namespace BBDAL
{
   public class AdminBBMSDAL
    {
       SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
       SqlCommand cmd;
       public bool AddBloodRequest(BloodRequest entity)
       {
           bool reqadded = false;
           try
           {
               cmd = new SqlCommand();
               cmd.CommandType = CommandType.StoredProcedure;
               cmd.CommandText = "udp_requestadd";
               cmd.Parameters.AddWithValue("@id", entity.HospitalId);
               cmd.Parameters.AddWithValue("@name", entity.HospitalName);
               cmd.Parameters.AddWithValue("@address", entity.HospAddress);
               cmd.Parameters.AddWithValue("@city", entity.HospCity);
               cmd.Parameters.AddWithValue("@region", entity.HospRegion);
               cmd.Parameters.AddWithValue("@date", entity.ReqDate);
               cmd.Parameters.AddWithValue("@bloodgroup", entity.BloodGroup);
               cmd.Parameters.AddWithValue("@packets", entity.NoOfPackets);
               cmd.Connection = con;
               con.Open();
               int result = cmd.ExecuteNonQuery();
               con.Close();
               if (result > 0)
                   reqadded = true;
           }
           catch (SqlException s)
           {
               con.Close();
               throw s;
           }
           catch (Exception ex)
           {
               con.Close();
               throw ex;
           }
           return reqadded;
       }
       //Blood Inventory details
       public List<BloodInventory> GetInventoryDetails()
       {
           List<BloodInventory> invdetails = null;

           try
           {
               cmd = new SqlCommand();
               cmd.CommandType = CommandType.StoredProcedure;
               cmd.CommandText = "inventory_show";
               cmd.Connection = con;
               con.Open();

               SqlDataReader dr = cmd.ExecuteReader();

               invdetails = new List<BloodInventory>();
               while (dr.Read())
               {
                   BloodInventory entity = new BloodInventory();
                   entity.BloodInventoryId = dr.GetInt32(0);
                   entity.BloodGroup = dr.GetString(1);
                   entity.NumOfBottles = dr.GetInt32(2);
                   entity.BloodBankId = dr.GetInt32(3);
                   entity.ExpDate = dr.GetDateTime(4);
                   invdetails.Add(entity);
               }
           }
           catch (SqlException s)
           {
               con.Close();
               throw s;
           }
           catch (Exception ex)
           {
               con.Close();
               throw ex;
           }
           return invdetails;
       }
       //Get DonationCampdetails
       public List<BloodCamp> GetDonationCampDetails()
       {
           List<BloodCamp> campdetails = null;

           try
           {
               cmd = new SqlCommand();
               cmd.CommandType = CommandType.StoredProcedure;
               cmd.CommandText = "camp_show";
               cmd.Connection = con;
               con.Open();

               SqlDataReader dr = cmd.ExecuteReader();

               campdetails = new List<BloodCamp>();
               while (dr.Read())
               {
                   BloodCamp entity = new BloodCamp();
                   entity.CampID = dr.GetInt32(0);
                   entity.Name = dr.GetString(1);
                   //entity.City = dr.GetString(2);
                   entity.Address = dr.GetString(2);
                   //entity.BloodBankName = dr.GetString(4);
                   entity.StartDate = dr.GetDateTime(3);
                   entity.EndDate = dr.GetDateTime(4);
                   campdetails.Add(entity);
               }
           }
           catch (SqlException s)
           {
               con.Close();
               throw s;
           }
           catch (Exception ex)
           {
               con.Close();
               throw ex;
           }
           return campdetails;
       }
       //donor details
       public List<Donor> GetDonorDetails()
       {
           List<Donor> donordetails = null;
           try
           {
               cmd = new SqlCommand();
               cmd.CommandType = CommandType.StoredProcedure;
               cmd.CommandText = "donor_show";
               cmd.Connection = con;
               con.Open();

               SqlDataReader dr = cmd.ExecuteReader();

               donordetails = new List<Donor>();
               while (dr.Read())
               {
                   Donor entity = new Donor();
                   entity.DonorID = dr.GetInt32(0);
                   entity.firstname = dr.GetString(1);
                   entity.lastname = dr.GetString(2);
                   entity.Address = dr.GetString(3);
                   entity.City = dr.GetString(4);
                   entity.Mobile = dr.GetString(5);
                   entity.BloodGroup = dr.GetString(6);
                   donordetails.Add(entity);
               }
           }
           catch (SqlException s)
           {
               con.Close();
               throw s;
           }
           catch (Exception ex)
           {
               con.Close();
               throw ex;
           }
           return donordetails;
       }
    }
}
