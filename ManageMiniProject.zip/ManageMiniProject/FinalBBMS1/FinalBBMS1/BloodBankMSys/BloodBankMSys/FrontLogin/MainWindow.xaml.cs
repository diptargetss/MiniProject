﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BBMS.Entities;
using BBMS.BL;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        LoginBL bbl = null;

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

       

        

       
        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            BBRegister register = new BBRegister();
            register.Show();
        }

        private void btnadmin_Click(object sender, RoutedEventArgs e)
        {
            Admin ad = new Admin();
            ad.Username = txtadminid.Text;
            ad.Password = txtadminpass.Password;
            bbl = new LoginBL();
            if (bbl.AdminCheck(ad))
            {
                Admin_Page ap = new Admin_Page(txtadminid.Text);
                
              
                ap.Show();
            }
            else
                MessageBox.Show("Incorrect username or password entered");
        }

        private void btnbloodbank_Click(object sender, RoutedEventArgs e)
        {

            Bloodbank bb = new Bloodbank();
            bb.BloodBankUserId = bloodBankuserId.Text;
            bb.BloodBankPwd = bloodBankPwd.Password;
            bbl = new LoginBL();
            int bbid = bbl.ValidateBankLogin(bb);
            if (bbid!=0)
            {
                BloodBank bk = new BloodBank(bbid);
                
                bk.Show();
            }
            else
                MessageBox.Show("Incorrect username or password entered");
        }


      
    }
}


 