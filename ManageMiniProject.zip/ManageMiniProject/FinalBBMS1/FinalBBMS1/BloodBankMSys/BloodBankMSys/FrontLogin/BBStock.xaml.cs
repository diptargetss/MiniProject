﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.Exceptions;
using BBMS.Entities;
using BBMS.BL;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for BBStock.xaml
    /// </summary>
    public partial class BBStock : Window
    {
        int bbid;
        public BBStock(int id)
        {
            InitializeComponent();
            bbid = id;
        }
        InventoryBL ibl = new InventoryBL();
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int units = Convert.ToInt32(txtQuantity.Text);
            string grp = cmbgrp.SelectedItem.ToString();
            string hname = txtHospitalName.Text;
            DateTime dt = Convert.ToDateTime(dpsend.SelectedDate);
            if (ibl.UpdateInventory(bbid, units, grp) == true && ibl.StockTransfer(bbid, units, hname, grp, dt) == true)
                MessageBox.Show("Inventory updated");
            else
                MessageBox.Show("Failed to update inventory");
        }

        private void btnDeleteStock_Click(object sender, RoutedEventArgs e)
        {
            if (ibl.DeleteExp())
                MessageBox.Show("All expired blood removed from inventory");
            else
                MessageBox.Show("Failed to remove expired bloodfrom inventory");
        }
    }
}
