﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class InventoryBL
    {
        InventoryDAL idl = new InventoryDAL();
         public bool DeleteExp()
        {
            return idl.DeleteExp();
        }
         public bool UpdateInventory(int bbid,int units,string grp)
         {
             return idl.UpdateInventory(bbid, units, grp);
         }

        public bool StockTransfer(int bbid,int units,string hname,string grp,DateTime dt)
         {
            return idl.StockTransfer(bbid,units,hname,grp,dt);
         }
    }
}
