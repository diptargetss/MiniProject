﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_04_Assignment_
{
    class Program
    {
        /// <summary>
        /// Using LINQ to Entities write the following functionality and execute them
        /// i. Add a Employee details
        /// ii. Updating a Employee details
        /// iii. Searching for an Employee based on It ID
        /// iv. Deleteing an employee.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Mumbai13TrainingEntities obj = new Mumbai13TrainingEntities();
            NNEmployee n = new NNEmployee();

            //Console.Write("Id:");
            //n.ID = Convert.ToInt32(Console.ReadLine());
            //Console.Write("\nName: ");
            //n.Name = Console.ReadLine();
            //Console.Write("\nDesignation: ");
            //n.Designation = Console.ReadLine();
            //Console.Write("\nDate Of Birth (YYYY/MM/DD)");
            //n.DOB = Convert.ToDateTime(Console.ReadLine());
            //Console.Write("\nDate of Joining (YYYY/MM/DD)");
            //n.DOJ = Convert.ToDateTime(Console.ReadLine());
            //Console.Write("\nSalary");
            //n.Salary = Convert.ToDecimal(Console.ReadLine());

            //obj.NNEmployees.Add(n);//For Addition

            //var k = (from e in obj.NNEmployees.Where(e => e.ID == n.ID) select e).FirstOrDefault();//For Updating

            //k.Name = n.Name;
            //k.ID = n.ID;
            //k.Salary = n.Salary;
            //k.DOJ = n.DOJ;
            //k.DOB = n.DOB;
            //k.Designation = n.Designation;


            //var q = (from e in obj.NNEmployees.Where(e => e.ID == n.ID) select e).First();
            //obj.NNEmployees.Remove(q);//For Removing

            //var q = (from e in obj.NNEmployees.Where(e=>e.ID == n.ID) select e).First();//For Searching

            //Console.WriteLine(q.Name);
            //Console.WriteLine(q.Salary);

            //var k = from q in obj.NNEmployees select q;//for Showing

            //foreach (var item in k)
            //{
            //    Console.WriteLine(item.Name);
            //}

            obj.SaveChanges();

        }
    }
}
