﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace LAB_04
{
    class LINQEFConsoleApp
    {
        static void Main(string[] args)
        {
            Mumbai13TrainingEntities obj = new Mumbai13TrainingEntities();

        //    Write Linq queries for the following.
        //    1) To display staff details write the following query
        //    2) To display list of employee whose salary is more than 30000
        //    Perform the following query by yourself
        //    3) Display the list of student where city is not null
        //    4) Display the list of student which includes Student name, department and date of birth
        //    5) Display count of total student belonging to Bangalore
            //6) Display list of employees whose salary is more than the average salary of the employee.
        
        //var q1= from e in obj.Staff_Master select e;
        //foreach (var item in q1)
        //{
        //    Console.WriteLine(item.Staff_Name);
        //}

            //var q2 = from e in obj.Staff_Master where e.Salary >30000 select e;
            //foreach (var item in q2)
            //{
            //    Console.WriteLine(item.Salary);
            //}

            //var q3 = from e in obj.Student_master where e.Address !=null select e;
            //foreach (var item in q3)
            //{
            //    Console.WriteLine(item.Stud_Name);
            //}

            //var q4 = from e in obj.Student_master select new { e.Stud_Name, e.Dept_Code, e.Stud_Dob};
            //foreach (var item in q4)
            //{
            //    Console.WriteLine(item.Stud_Name + item.Stud_Dob + item.Dept_Code);
            //}

            //var q5 = (from e in obj.Student_master where e.Address == "Bangalore" select e).Count();

            //Console.WriteLine(q5);

            //var q6_1 = (from e in obj.Staff_Master select e.Salary).Average();
            //var q6 = from e in obj.Staff_Master where e.Salary > q6_1 select e;

            //foreach (var item in q6)
            //{
            //    Console.WriteLine(item.Salary);
            //}

            Student_master o = new Student_master();

            Console.WriteLine("Student_code");
            o.Stud_Code = Convert.ToDecimal(Console.ReadLine());
            //Decimal s = Convert.ToDecimal(Console.ReadLine());

            Console.WriteLine("Name");
            o.Stud_Name = Console.ReadLine();

            Console.WriteLine("DOB YYYY/MM/DD");
            o.Stud_Dob = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Dept code");
            o.Dept_Code = Convert.ToDecimal(Console.ReadLine());

            Console.WriteLine("City");
            o.Address = Console.ReadLine();

            obj.Student_masters.Add(o);//For Adding

            //var k = (from e in obj.Student_masters.Where(e => e.Stud_Code == o.Stud_Code) select e).First();//For Removing

            //obj.Student_masters.Remove(k);

            //var k = (from e in obj.Student_masters.Where(e => e.Stud_Code == o.Stud_Code) select e).FirstOrDefault();

            //k.Stud_Name = o.Stud_Name;
            //k.Stud_Dob = o.Stud_Dob;
            //k.Dept_Code = o.Dept_Code;
            //k.Address = o.Address;

            obj.SaveChanges();

        }
    }
}
