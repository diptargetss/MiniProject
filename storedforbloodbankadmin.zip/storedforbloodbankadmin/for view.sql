--stored procedure for showing inventory details
go
create procedure inventory_show(@biid int,@bigroup varchar(10),@bibottles int,@bid int)
as
begin
select * from BBMS.BloodInventory
end
go

--stored procedure for showing donor details


go
create procedure donor_show(@bdid int,@fname varchar(20),@lname varchar(20),@bdaddress varchar(20),@bdcity varchar(20),
@mobnum varchar(20),@bgroup varchar(10))
as
begin
select * from BBMS.BloodInventory
end
go




go
create procedure camp_show(@bcamp int,@campname varchar(20),@donoraddress varchar(50),@cstartdate date,@cenddate date)
as
begin
select * from BBMS.BloodDonationCamp
end
go