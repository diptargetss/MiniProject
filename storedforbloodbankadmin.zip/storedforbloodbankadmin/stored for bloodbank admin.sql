---stored procedure for Bloodbank---
 

 go
 create proc bank_add(@bid int,@bname varchar(20)) as
 begin
 insert into BBMS.BloodBank(BloodBankId,BloodBankname) values(@bid,@bname)
 end 
 go



---stored procedure for updating----

go
create proc bank_upd(@bid int,@bname varchar(20),@baddress varchar(50),@bregion varchar(20),@bcity varchar(15),@bmobnum varchar(20))
as
begin
update  BBMS.BloodBank SET @bname=BloodBankname,@baddress=bbaddress,@bregion=bbregion,@bcity=bbcity,@bmobnum=bbMobNo
where BloodBankId=@bid
end
go
select * from BBMS.BloodBank
--stored procedure for deleting---
go
create proc bank_del (@bid int) as
begin
delete from BBMS.BloodBank where BloodBankId=@bid
end
go

---stored procedure for showing bloodbank details by id---

go
create proc bank_showbyid(@bid int)
as
begin
select BloodBankId,BloodBankname,bbcity,bbaddress,bbMobNo,bbregion from BBMS.BloodBank where BloodBankId=@bid
end
go

---stored procedure for showing bloodbank details


go
create procedure bank_showall(@bid int,@bname varchar(20),@baddress varchar(20),@bregion varchar(20),@bcity varchar(20),@bmobnum varchar(20))
as
begin
select * from BBMS.BloodBank
end
go

--table for bloodbank login credentials


create table BBMS.BloodLogin(Username varchar(10),Password varchar(10));

insert into  BBMS.BloodLogin values('bloodbank','bloodbank');