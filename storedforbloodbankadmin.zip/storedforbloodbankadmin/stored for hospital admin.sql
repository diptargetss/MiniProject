create schema BBMS

1)-----table of blood inventory

create table BBMS.BloodInventory
(BloodInventoryId int primary key,BloodGroup varchar(5),NoOfBottles int,BloodBankId int,expirydate date,
Foreign key(bloodBankId) REFERENCES BBMS.BloodBank(BloodBankId))

insert into BBMS.BloodInventory values(1,'O+ve',5,100100,'07-08-2018')

insert into BBMS.BloodInventory values(2,'AB+ve',5,100101,'07-09-2018')

drop table BBMS.BloodInventory


2)------table of Bloodbank


create table BBMS.BloodBank (BloodBankId int primary key,BloodBankname varchar(20),bbaddress varchar(50),bbregion varchar(20),bbcity varchar(20),
bbMobNo varchar(15))

insert into BBMS.BloodBank values(100100,'ABC','ABC Apartments','Airoli','Mumbai',7893360561)

insert into BBMS.BloodBank values(100101,'DEF','DEF Apartments','Mulund','Mumbai',7893360562)


drop table BBMS.BloodBank

3)----table of blood donation camp


create table BBMS.BloodDonationCamp(bloodDonationCamp int,campName varchar(50),donaddress varchar(50),campstartdate date,campenddate date);

insert into BBMS.BloodDonationCamp values(1001,'harsha','chirala','07-08-2015','12-08-21996')
insert into BBMS.BloodDonationCamp values(1002,'Madhu','Amalapuram','07-09-2015','12-09-2015')

4)----table of Hospital

create table BBMS.Hospital(hospitalid int,hospitalname varchar(20),hospaddress varchar(50),city varchar(15));

insert into BBMS.Hospital values(1001,'Appolo','Hyderabad','Andhra pradesh')

insert into BBMS.Hospital values(1002,'KIMS','Hyderabad','Andhra pradesh')

5)------table of Blood donor

create table BBMS.BloodDonor(BloodDonorId int primary key,firstname varchar(20),lastname varchar(20),
donoraddress varchar(50),donorcity varchar(20),donormobnum varchar(15),donorbloodgroup varchar(5))

insert into BBMS.BloodDonor values(10001,'Latha','Reddy','Kadapa','SPuram',7893360561,'O+ve')

insert into BBMS.BloodDonor values(10002,'Madhu','Reddy','chirala','Rangasthalam',7893360562,'B+ve')

drop table BBMS.BloodDonor

6)----table of BloodDonorDonation

create table BBMS.BloodDonorDonation(bloodDonationId int ,bloodDonorId int,bloodDonationdate date,
numberOfBottle int,bloodweight float,
hbCount float,foreign key(BloodDonorId) references BBMS.BloodDonor(BloodDonorId))

drop table BBMS.BloodDonorDonation

create table BBMS.AdminLogin(Username varchar(10),Password varchar(10));
insert into  BBMS.AdminLogin values('Admin','Admin');
---stored procedure for Admin login
go
create proc BBMS_AdminLogin @username varchar(10),@password varchar(10) as 
(select * from BBMS.AdminLogin)	
go

---------------Stored procedure for Adding Hospital details by admin
go
create proc hosp_add @hid int,@hname varchar(20),@haddress varchar(50),@hcity varchar(15) as 
insert into BBMS.Hospital(hospitalid,hospitalname,hospaddress,city) values(@hid,@hname,@haddress,@hcity)
go


---Stored procedure for adding hospital id and hospital name by admin


go 
create proc hospadm_add (@hid int,@hname varchar(20)) as
begin
insert into BBMS.Hospital(hospitalid,hospitalname) values(@hid,@hname)
end
go
------------------Stored Procedure for deleting Hosptital details by admin
go
create proc hosp_del (@hid int) as
begin
delete from BBMS.Hospital where hospitalid=@hid
end
go

---stored procedure for updating hospital details

go
create proc hosp_upd(@hid int,@hname varchar(20),@haddress varchar(50),@hcity varchar(15))
as
begin
update  BBMS.Hospital SET @hid=hospitalid,@hname=hospitalname,@haddress=hospaddress,@hcity=city
where hospitalid=@hid
end
go
---stored procedure for showing details of the hospitals

go
create proc hosp_show(@hid int)
as
begin
select * from BBMS.Hospital where hospitalid=@hid
end
go

