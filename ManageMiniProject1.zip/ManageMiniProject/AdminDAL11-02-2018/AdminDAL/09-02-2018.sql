create table BBMS.HospitalRequest(hospitalid int,hospitalname varchar(20),hospaddress varchar(30),hospcity varchar(10),
hospregion varchar(10),hospdate date,hosbloodgroup varchar(5),noofpackets int)

go 
create proc udp_requestadd(@hid int,@hname varchar(20),@haddress varchar(20),@hcity varchar(20),@hregion varchar(20),@hdate date,
@hbgroup varchar(20),@humpackets int)
as
begin 
insert into BBMS.hospitalrequest values(@hid,@hname,@haddress,@hcity,@hregion,@hdate,@hbgroup,@humpackets)
end
go

drop proc udp_requestadd
DROP TABLE BBMS.hospitalrequest



--go
--create proc udp_showinv(@hid int,id int,name varchar)
--as
--begin
--declare  id int;
--declare name varchar;
--select hospitalid into id,hospitalname into name from BBMS.hospital where hospitalid==@hid
insert into BBMS.hospitalrequest values(1001,'Apollo','Chirala','AP','Munthavaricenter','17-06-1996','O+',12)

select * from BBMS.hospitalrequest
select * from BBMS.Hospital


select BBMS.hospitalrequest.hospitalid,BBMS.Hospital.hospitalid from BBMS.hospitalrequest,BBMS.Hospital
where BBMS.hospitalrequest.hospitalid=BBMS.Hospital.hospitalid;

GO
CREATE PROC udp_showinve(@hid int,@hhid int,@diid int,@bgroup varchar(5),@numofbottles int,@bbid int,@expirydate date)
as
begin

select * from BBMS.BloodInventory bi inner join BBMS.hospitalrequest hr on bi.BloodGroup=hr.hosbloodgroup inner join BBMS.Hospital h on hr.hospitalid=h.hospitalid
where h.hospitalid=@hhid and bi.BloodGroup=@bgroup
end
go

---------Adding Donor and donation details-----

drop proc udp_adddonor
go 
create proc udp_adddonor(@id int,@fname varchar(20),@lname varchar(20),@add varchar(50),@city varchar(20),@mobileno varchar(15),
@age int,@weight int,@bloodgroup varchar(15),@units int,@donationdate date,@hbcount int,@donationid int,@bloodbankid int)
as
begin
insert into BBMS.BloodDonor values(@id,@fname,@lname,@add,@city,@mobileno,@age,@weight,@bloodgroup,@units,@donationdate,@hbcount,@donationid
,@bloodbankid)
end
go

exec udp_adddonor 102,'Madhu','Gangalakurthi','Sri','Reddy','7337037769',21,20.1,'dhf',2,'02-02-1998',12,1001,100100

-------Adding blood donation camp details---
go
create proc udp_camp(@bid int,@cid int,@cname varchar(10),@cadd varchar(10),@startdate date,@enddate date)
as
begin
insert into BBMS.BloodDonationCamp values(@bid,@cid,@cname,@cadd,@startdate,@enddate)
end	
go

------Searching by donation camp id--
go
create proc udp_campbyid(@cid int)
as
begin
select * from BBMS.BloodDonationCamp where bloodDonationCamp=@cid
end
go

---_Updating camp details by camp id-----
go
create proc udp_campupdate(@cid int,@bid int,@cname varchar(10),@cadd varchar(10),@startdate date,@enddate date)
as
begin
update BBMS.BloodDonationCamp set bloodDonationCamp=@cid,bloodbankid=@bid,campName=@cname,donaddress=@cadd,campstartdate=@startdate,
campenddate=@enddate where bloodDonationCamp=@cid
end
go

---------check availability for  bank id----

go
create proc udp_checkavailbank(@bid int)
as
begin
select * from BBMS.BloodBank where BloodBankId=@bid
end
go

select * from BBMS.BloodBank

exec udp_checkavailbank

-------------check availability donor---
go
create proc udp_checkavailbankuser(@bbuser varchar(10))
as
begin
select * from BBMS.BloodBank where BloodBankname=@bbuser
end
go



--deleting the donor details

drop proc udp_donordelete

go
create proc udp_donordelete(@id int)
as
begin
delete from BBMS.BloodDonor where BloodDonorId=@id
end
go

exec udp_donordelete 101


--create proc udp_donordelete(@id int)
--as
--begin
--delete BBMS.BloodDonor,BBMS.BloodDonorDonation from BBMS.BloodDonor,BBMS.BloodDonorDonation where BBMS.BloodDonor.blooddonorid=BBMS.BloodDonorDonation.blooddonorid
--end
--go

select * from BBMS.BloodDonor
select * from BBMS.BloodDonorDonation

exec udp_donordelete 1001

----updating the donor details

insert into BBMS.BloodDonor values(1001,'latha','Reddy','Chirala','Ap','7337037769','O+ve',21,65)

insert into BBMS.BloodDonorDonation values(10023,1001,'02-02-1998',12,23,23,12)

-----updating donor details

go
create proc udp_update(@id int,@fname varchar(20),@lname varchar(20),@add varchar(50),@city varchar(20),@mobileno varchar(15),
@age int,@weight int,@bloodgroup varchar(15),@units int,@donationdate date,@hbcount int,@donationid int,@bloodbankid int)
as
begin
update BBMS.BloodDonor set BloodDonorId=@id,firstname=@fname,lastname=@lname,donoraddress=@add,city=@city,donormobnum=@mobileno,
age=@age,donorbloodgroup=@bloodgroup,units=@units,bweight=@weight,bloodDonationdate=@donationdate,hbCount=@hbcount,
blooddonationid=@donationid,bloodbankid=@bloodbankid
end
go

drop proc udp_update

--searching donor dy id
go
create proc udp_DonorSearchById(@id int)
as
begin
select * from BBMS.BloodDonor where BloodDonorId=@id
end
go


exec udp_DonorSearchById 101

------Blood bank----
go
create proc udp_bloodbankreg(@id int,@user varchar(10),@pass varchar(10),@address varchar(50),@region varchar(20),@city varchar(10),@contact varchar(10))
as
begin
insert into BBMS.BloodBank(BloodBankId,bbusername,bbpass,bbaddress,bbregion,bbcity,bbMobNo) values(@id,@user,@pass,@address,@region,@city,@contact)
end
go

exec udp_bloodbankreg 10010,'ABCD','1234','IJK','Chirala','12345678','23345'

select * from BBMS.BloodBank

----view all -------

go
create proc view