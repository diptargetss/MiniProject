﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Exceptions
{
    public class BloodBankException : ApplicationException
    {

        public BloodBankException(): base()
        {

        }
        public BloodBankException(string message): base(message)
        {

        }
        public BloodBankException(string message, Exception innerException): base(message, innerException)
        {

        }
    }
}
