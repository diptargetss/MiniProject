﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace dal
{
    public class Inventory
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["demo"].ConnectionString);
        SqlCommand cmd;
        public bool DeleteExp(BloodInventory bi)
        {
            bool delete = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "inventory_delexp";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@id",bi.);

                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                {
                    delete = true;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return delete;
        }
        public bool ValidateBankLogin(BloodBank bb)
        {
            bool valid = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BBMS_BBLogin";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@u", Convert.ToString(bb.Username)));
                cmd.Parameters.Add(new SqlParameter("@p", Convert.ToString(bb.Password)));
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    valid = true;
                    con.Close();
                }
            }
            catch(SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return valid;
        }
    }
}
