﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Entities
{
   public class Hospital
    {
        public int hospitalid;
        public int HospitalId
        {
            get
            {
                return hospitalid;
            }
            set { hospitalid = value; }
        }
        public string Hospitalname { get; set; }
        public string HospitalAddress { get; set; }
        public string HospitalCity { get; set; }
        public string Location { get; set; }
        public string ContactNo { get; set; }
        


    }
}
