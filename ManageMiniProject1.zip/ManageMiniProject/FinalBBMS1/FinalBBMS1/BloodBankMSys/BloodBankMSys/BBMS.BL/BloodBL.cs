﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class BloodBL
    {
        //AdminBloodbank bbda = null;
        //DonorDL ddl = new DonorDL();
        //AdminHospital adh = new AdminHospital();
        //InventoryDAL idl = new InventoryDAL();
        //CampDAL c = new CampDAL();
        //StringBuilder sb = new StringBuilder();
        BloodBankDA bbd = null;
        AdminBBMSDAL abbms = null;
        AdminBloodbank adb = null;
        public BloodBL()
        {
            bbd = new BloodBankDA();
            abbms = new AdminBBMSDAL();
            adb = new AdminBloodbank();
        }






        //public bool BloodRequest(Hospital hos,int units)
        //{
        //    bool ch=bbda.RequestCheck(hos.Location,units);
        //    return ch;
        //}


        public List<Donor> ShowDonors(int bbid)
        {
            
            return bbd.ShowDonors(bbid);
        }






        //public List<Bloodbank> GetBankDetails()
        //{
        //    return c.GetBankDetails();
        //}

        //Get bank details by id



        public List<BloodInventory> GetInventoryDetails()
        {
            return abbms.GetInventoryDetails();
        }

        //Get All Camp details for admin
        public List<BloodCamp> GetDonationCampDetails()
        {
            return abbms.GetDonationCampDetails();
        }

        //Get all donor details for admin
        public List<Donor> GetDonorDetails()
        {
            return abbms.GetDonorDetails();
        }

        public bool AddRequest(BloodRequest brq)
        {
            StringBuilder sb = new StringBuilder();
            bool valid = true;
            if(brq.ReqDate==null||brq.NoOfPackets==null||brq.HospRegion==string.Empty
                ||brq.HospitalName==string.Empty||brq.HospitalId==null
               ||brq.HospCity==string.Empty||brq.HospAddress==string.Empty||brq.BloodGroup==string.Empty)
            {
                valid = false;
                sb.Append("Values cannot be null");
            }
            if(brq.HospitalId<100000||brq.HospitalId>=999999)
            {
                valid = false;
                sb.Append(" ID must be 6 digits only ");
            }
            if(brq.ReqDate.CompareTo(DateTime.Now)<0)
            {
                valid = false;
                sb.Append(" Date has already passed ");
            }
            if(brq.NoOfPackets<=0)
            {
                valid = false;
                sb.Append(" Return Valid number of units ");
            }
            if (valid == false)
            {
                throw new BloodException(sb.ToString());
                
            }
            return abbms.AddBloodRequest(brq);
        }
        public bool CheckAvailability(string buserid)
        {
            return adb.CheckAvailability(buserid);
        }
        public bool RegisterBloodBank(Bloodbank bb)
        {
            return adb.RegisterBloodBank(bb);
        }
    }
}