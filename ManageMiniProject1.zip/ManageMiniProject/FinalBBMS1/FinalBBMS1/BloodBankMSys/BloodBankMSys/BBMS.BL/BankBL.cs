﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBDAL;
using BBMS.Entities;
using BBMS.Exceptions;

namespace BBMS.BL
{
    public class BankBL
    {
        BloodBankDA bbda = new BloodBankDA();
       

        AdminBloodbank bbd = new AdminBloodbank();
        public bool UpdateBankDetails(Bloodbank b)
        {

            return bbd.UpdateBankDetail(b);

        }
        public Bloodbank GetBankDetailsById(string id)
        {

            int i = Convert.ToInt32(id);

            return bbd.GetBankDetailsById(i);

        }

        public List<Bloodbank> ShowBanks()
        {
            return bbd.ShowBanks();
        }



        public bool AddBankIdName(int id, string bname)
        {
            return bbd.AddBankIDName(id, bname);
        }

        public bool DelBankDetails(int id)
        {
            return bbd.DelBankDetails(id);
        }
    }
}
