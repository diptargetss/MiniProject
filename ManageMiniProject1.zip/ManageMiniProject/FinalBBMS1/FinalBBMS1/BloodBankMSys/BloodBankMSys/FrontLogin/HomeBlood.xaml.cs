﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FrontLogin;

namespace HomePage
{
    /// <summary>
    /// Interaction logic for HomeBlood.xaml
    /// </summary>
    public partial class HomeBlood : Window
    {
        public HomeBlood()
        {
            InitializeComponent();
        }

        private void btndirlogin_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
        }

        private void btnrequest_Click(object sender, RoutedEventArgs e)
        {
            BloodRequestPage brp = new BloodRequestPage();
            brp.Show();
        }

        
    }
}
