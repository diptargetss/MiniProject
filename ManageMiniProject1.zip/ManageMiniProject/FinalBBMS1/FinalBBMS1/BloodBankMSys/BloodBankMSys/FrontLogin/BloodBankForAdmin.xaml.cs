﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BBMS.BL;
using BBMS.Entities;
using BBMS.Exceptions;

namespace FrontLogin
{
    /// <summary>
    /// Interaction logic for BloodBankForAdmin1.xaml
    /// </summary>
    public partial class BloodBankForAdmin : Window
    {
        string admin;
        public BloodBankForAdmin(string str)
        {
            InitializeComponent();
            admin = str;
            
        }


        BankBL bbl = new BankBL();
        private void btnbbview_Click(object sender, RoutedEventArgs e)
        {
            
            string id = txtbbidview.Text;
            Bloodbank bb = bbl.GetBankDetailsById(id);
            //if (id < 100000 || id > 999999)
            //    MessageBox.Show("Enter valid id");
            if (bb == null)
                MessageBox.Show("No Blood Bank found with that id");
            else
            {
                if (bb.BloodBankMobNo == "  " && bb.Baddress == "  " && bb.BloodBankCity == "  " && bb.BRegion == "  ")
                {
                    txtaddress.Text = string.Empty;
                    txtcontact.Text = string.Empty;
                    txtcity.Text = string.Empty;
                    txtregion.Text = string.Empty;
                }
                else
                {
                    txtaddress.Text = bb.Baddress;
                   
                    txtcity.Text = bb.BloodBankCity;
                    txtcontact.Text = bb.BloodBankMobNo;
                    txtregion.Text = bb.BRegion;
                }
                txtbbname.Text = bb.BloodBankname;
                }


        }

        private void btnmodbb_Click(object sender, RoutedEventArgs e)
        {
            Bloodbank bk = new Bloodbank();
            bk.BloodBankId = Convert.ToInt32(txtbbidview.Text);
            bk.Baddress = txtaddress.Text;
            bk.BloodBankCity = txtcity.Text;
            bk.BRegion = txtregion.Text;
            bk.BloodBankMobNo = txtcontact.Text;
            bk.BloodBankname = txtbbname.Text;
            if (bk.Baddress == "" || bk.BloodBankCity == "" || bk.BloodBankMobNo == "" ||
                bk.BloodBankname == "" || bk.BRegion == "")
                MessageBox.Show("Values cannot be null");
            else
            {

                if (bbl.UpdateBankDetails(bk))
                    MessageBox.Show("Updated successfully");
                else
                    MessageBox.Show("Failed to Update");
            }
        }

        private void btndelbb_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtbbidview.Text);
            
            if (bbl.DelBankDetails(id))
                MessageBox.Show("Blood bank deleted successfully");
            else
                MessageBox.Show("Failed blood bank deletion");
        }

        private void btnaddbb_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtbbidadd.Text);
            string bname = txtbbnameadd.Text;
            
            if (bname == string.Empty)
                MessageBox.Show("Values cannot be null");
            else
            {

                if (bbl.AddBankIdName(id, bname))
                    MessageBox.Show("Blood Bank added successfully");
                else
                    MessageBox.Show("Adding Blood Bank failed");
            }
        }



        



    }
}
