﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class CampBL
    {
        //Add Camp
        CampDAL bbda = new CampDAL();
        AdminBloodbank bbd = new AdminBloodbank();
        public bool AddCamp(BloodCamp bc)
        {
            if (bc.StartDate.CompareTo(DateTime.Now) > 0)
            {
                if (bc.EndDate.CompareTo(bc.StartDate) > 0)
                    return bbda.AddCampDetails(bc);
                else
                    return false;
            }
            else
            {
                return false;
            }
        }

        //Modify Camp
        public bool ModifyCampDetails(BloodCamp camp)
        {
            //bool checkDate=false;
            StringBuilder sb = new StringBuilder();


            if (camp.StartDate.CompareTo(DateTime.Now) > 0)
                return bbda.UpdateCampDetails(camp);
            else
            {
                //Console.WriteLine("Cannot Change details as date already passed");
                sb.Append("Date has already passed");
                throw new BloodException(sb.ToString());

            }

        }
    }
}
