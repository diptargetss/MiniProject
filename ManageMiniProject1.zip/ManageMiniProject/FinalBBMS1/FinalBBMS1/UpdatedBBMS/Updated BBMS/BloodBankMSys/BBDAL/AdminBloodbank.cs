﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entities;
using BBMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BBDAL
{
    public class AdminBloodbank             //bloodbank admin side operations
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        //add blood bank details
        public bool AddBankIDName(int id, string bname)
        {
            bool bankadd = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_add";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Parameters.AddWithValue("@bname", bname);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    bankadd = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return bankadd;
        }
        //delete blood bank details
        public bool DelBankDetails(int id)
        {
            bool bankdel = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_del";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    bankdel = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return bankdel;
        }
        //update bank details
        public bool UpdateBankDetail(Bloodbank details)
        {
            bool bankupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_upd";
                cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                cmd.Parameters.AddWithValue("@bname", details.BloodBankname);
                cmd.Parameters.AddWithValue("@baddress", details.Baddress);
                cmd.Parameters.AddWithValue("@bcity", details.BloodBankCity);
                cmd.Parameters.AddWithValue("@bmobnum", details.BloodBankMobNo);
                cmd.Parameters.AddWithValue("@bregion", details.BRegion);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    bankupdate = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return bankupdate;
        }
  
        //search by BloodBankid
        public Bloodbank GetBankDetailsById(int id)
        {
            Bloodbank entity = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_showbyid";
                cmd.Parameters.AddWithValue("@bid", id);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    entity = new Bloodbank();
                    entity.BloodBankId = dr.GetInt32(0);
                    entity.BloodBankname = dr.GetString(1);
                    entity.Baddress = dr.GetString(2);
                    entity.BRegion = dr.GetString(3);
                    entity.BloodBankMobNo = dr.GetString(5);
                    entity.BloodBankCity = dr.GetString(4);
                }
                con.Close();
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return entity;
        }
        //show all blood bank details

        public List<Bloodbank> ShowBanks()
        {
            List<Bloodbank> BBlist = null;


            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "bank_show";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                BBlist = new List<Bloodbank>();
                while (dr.Read())
                {
                    Bloodbank entity = new Bloodbank();
                    entity.BloodBankId = dr.GetInt32(0);
                    entity.BloodBankname = dr.GetString(1);
                    entity.Baddress = dr.GetString(2);
                    entity.BRegion = dr.GetString(3);
                    entity.BloodBankCity = dr.GetString(4);
                    entity.BloodBankMobNo = dr.GetString(5);
                    BBlist.Add(entity);

                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return BBlist;
        }
    }
}
