---stored procedure for Bloodbank---
 select * from BBMS.BloodBank
 delete from BBMS.BloodBank where bbregion is NULL
 go
 create proc bank_add(@bid int,@bname varchar(20)) as
 begin
 insert into BBMS.BloodBank values(@bid,@bname,'  ','  ','  ','  ','  ','  ')
 end 
 go

 exec bank_add 170170,'Santoshi Maa'
 select * from BBMS.BloodBank
 drop proc bank_add

---stored procedure for updating----

go
create proc bank_upd(@bid int,@bname varchar(20),@baddress varchar(50),@bregion varchar(20),@bcity varchar(15),@bmobnum varchar(20))
as
begin
update  BBMS.BloodBank SET BloodBankname=@bname,bbaddress=@baddress,bbregion=@bregion,bbcity=@bcity,bbMobNo=@bmobnum
where BloodBankId=@bid
end
go
select * from BBMS.BloodBank
drop proc bank_upd
exec bank_upd 100100,'ABC','ABC Apartments','Thane','Mumbai',7893365789

--stored procedure for deleting---
go
create proc bank_del (@bid int) as
begin
delete from BBMS.BloodBank where BloodBankId=@bid
end
go

---stored procedure for showing bloodbank details by id---
create schema BBMS
create table BBMS.BloodBank
(BloodBankId int,BloodBankname


go
create proc bank_showbyid(@bid int)
as
begin
select BloodBankId,BloodBankname,bbaddress,bbregion,bbMobNo,bbcity  from BBMS.BloodBank where BloodBankId=@bid
end
go

drop proc bank_showbyid
exec bank_showbyid 456456
---stored procedure for showing bloodbank details


go
create procedure bank_show
as
begin
select * from BBMS.BloodBank
end
go
exec bank_showall
drop proc bank_show
--table for bloodbank login credentials


create table BBMS.BloodLogin(Username varchar(10),Passord varchar(10));

insert into  BBMS.BloodLogin values('bloodbank','bloodbank');

drop table BBMS.BloodLogin

go
create proc BBMS_BBLogin (@username varchar(10),@password varchar(10)) as 
(select * from BBMS.BloodLogin where Username=@username and Passord=@password)	
go


drop proc BBMS_BBLogin

exec BBMS_BBLogin 'bloodbank','bloodbank'

select * from BBMS.Hospital

--stored procedure for Inventory Addition


go 
create proc inventory_add(@units int,@bbid int,@bgrp varchar(10),@expdate date)
as
insert into BBMS.BloodInventory(BloodInventoryId,BloodGroup,NoOfBottles,BloodBankId,expirydate) values
(
(select MAX(BloodInventoryId)+1 from BBMS.BloodInventory),@bgrp,@units,@bbid,@expdate
)
go

exec inventory_add 5,150150,'A+','10-10-17'

--update inventory
go 
create proc inventory_upd(@bbid int,@bgrp varchar(10))
as
delete from BBMS.BloodInventory where BloodGroup=@bgrp and BloodBankId=@bbid
and expirydate=(select min(expirydate) from BBMS.BloodInventory)
and BloodInventoryId=(select MIN(BloodInventoryId) from BBMS.BloodInventory
where BloodGroup=@bgrp
and BloodBankId=@bbid
and expirydate=(select min(expirydate) from BBMS.BloodInventory)
)
go

delete from BBMS.BloodInventory

insert into BBMS.BloodInventory values(1,'A+','1','150150','10-10-17')
exec inventory_add 1,'150150','A+','09-04-17'

exec inventory_upd '150150','A+'

drop proc inventory_upd
exec inventory_upd 150150,3,'A+' 
select * from BBMS.BloodInventory

--delete for expired

go 
create proc inventory_delexp(@expdate date)
as
delete from BBMS.BloodInventory where expirydate<=@expdate
go


exec inventory_delexp '09-07-17'

select * from BBMS.BloodBank
create table BBMS.StockTransfer(BloodbankId int,HospitalName varchar(20),BloodGroup varchar(5),Quantity int,DateTransfer date)


drop table BBMS.StockTransfer

go 
create proc udp_stocktransfer(
@id int,
@name varchar(20),
@group varchar(5),
@quantity int,
@date date)
as
begin
insert into BBMS.StockTransfer values(@id,@name,@group,@quantity,@date)
end
go

exec udp_stocktransfer 1010,'ABC','O+ve',12,'02-02-2018'