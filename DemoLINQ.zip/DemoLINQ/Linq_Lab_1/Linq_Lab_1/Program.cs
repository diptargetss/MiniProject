﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq_Lab_1
{
    
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> Employeelist = new List<Employee>();
            Employeelist.Add(new Employee
            {
                EmployeeID = 1001,
                FirstName = "Malcolm",
                LastName = "Daruwalla",
                Title = "Manager",
                DOB = Convert.ToDateTime("11/16/1984"),
                DOJ = Convert.ToDateTime("06/08/2011"),
                City = "Mumbai"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1002,
                FirstName = "Astrid",
                LastName = "Dhalla",
                Title = "AsstManager",
                DOB = Convert.ToDateTime("08/20/1984"),
                DOJ = Convert.ToDateTime("07/07/2012"),
                City = "Mumbai"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1003,
                FirstName = "Madhavi",
                LastName = "Oza",
                Title = "Consultant",
                DOB = Convert.ToDateTime("11/14/1987"),
                DOJ = Convert.ToDateTime("04/12/2015"),
                City = "Pune"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1004,
                FirstName = "Saba",
                LastName = "Shaikh",
                Title = "SE",
                DOB = Convert.ToDateTime("06/03/1990"),
                DOJ = Convert.ToDateTime("02/02/2016"),
                City = "Pune"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1005,
                FirstName = "Nazia",
                LastName = "Shaikh",
                Title = "SE",
                DOB = Convert.ToDateTime("03/08/1991"),
                DOJ = Convert.ToDateTime("02/02/2016"),
                City = "Mumbai"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1006,
                FirstName = "Amit",
                LastName = "Pathak",
                Title = "Consultant",
                DOB = Convert.ToDateTime("11/07/1989"),
                DOJ = Convert.ToDateTime("08/08/2014"),
                City = "Chennai"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1007,
                FirstName = "Vijay",
                LastName = "Natrajan",
                Title = "Consultant",
                DOB = Convert.ToDateTime("12/02/1989"),
                DOJ = Convert.ToDateTime("06/01/2015"),
                City = "Mumbai"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1008,
                FirstName = "Rahul",
                LastName = "Dubey",
                Title = "Associate",
                DOB = Convert.ToDateTime("11/11/1993"),
                DOJ = Convert.ToDateTime("11/06/2014"),
                City = "Chennai"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1009,
                FirstName = "Suresh",
                LastName = "Mistry",
                Title = "Associate",
                DOB = Convert.ToDateTime("08/12/1992"),
                DOJ = Convert.ToDateTime("12/03/2014"),
                City = "Chennai"
            });
            Employeelist.Add(new Employee
            {
                EmployeeID = 1010,
                FirstName = "Sumit",
                LastName = "Shah",
                Title = "Manager",
                DOB = Convert.ToDateTime("04/12/1991"),
                DOJ = Convert.ToDateTime("01/02/2016"),
                City = "Pune"
            });
             var query1 = from Employee emp in Employeelist select emp;
             var query2 = from Employee emp in Employeelist where emp.City!="Mumbai" select emp;
             var query3 = from Employee emp in Employeelist where emp.Title == "AsstManager" select emp;
             var query4 = from Employee emp in Employeelist where emp.LastName[0] == 'S' select emp;
             var query5 = from Employee emp in Employeelist where emp.DOJ.CompareTo(Convert.ToDateTime("01/01/2015"))<0 select emp;
             var query6 = from Employee emp in Employeelist where emp.DOB.CompareTo(Convert.ToDateTime("01/01/1990")) > 0 select emp;
             var query7 = from Employee emp in Employeelist where emp.Title=="Consultant"||emp.Title=="Associate" select emp;
             var query8 = Employeelist.Count();
             var query9 = Employeelist.Count(e => e.City == "Chennai");
             var query10 = Employeelist.Max(e=>e.EmployeeID);
             var query11 = Employeelist.Count(e => e.DOJ.CompareTo(Convert.ToDateTime("01/01/2015")) > 0);
             var query12 = Employeelist.Count(e => e.Title!="Associate");
             var query13 = from Employee in Employeelist group Employee by Employee.City into e select new { City=e.Key, CityCount=e.Count()};
             //var query14 = from Employee in Employeelist group Employee by Employee.City+Employee.Title into e select new {City=e.Key,Title=e.Key};
             var query14 = from e in Employeelist group e by new { e.City, e.Title };
             var query15 = from Employee emp in Employeelist where emp.DOB == Employeelist.Max(e => e.DOB) select emp;
             Console.WriteLine("Total: "+query8);
             Console.WriteLine("Total in Chennai: "+query9);
             Console.WriteLine("Max ID: "+query10);
             Console.WriteLine("Total employees who joined after 01/01/2015: "+query11);
             Console.WriteLine("Total employees who are not associate: "+query12);
             foreach (var e in query15)
             {
                 Console.WriteLine("ID: " + e.EmployeeID);
                 Console.WriteLine("Name: " + e.FirstName + " " + e.LastName);
                 Console.WriteLine("DOB: " + e.DOB.Date);
                 Console.WriteLine("DOJ: " + e.DOJ.Date);
                 Console.WriteLine("Title: " + e.Title);
                 Console.WriteLine("City: " + e.City);
                 Console.WriteLine();
             }
            //foreach(var e in query14)
            //{
            //    Console.WriteLine("{0}",e.Count());
            //}
        }
        //public static void display( query)
        //{
        //    foreach (var e in query)
        //    {
        //        Console.WriteLine("ID: " + e.EmployeeID);
        //        Console.WriteLine("Name: " + e.FirstName + " " + e.LastName);
        //        Console.WriteLine("DOB: " + e.DOB.Date);
        //        Console.WriteLine("DOJ: " + e.DOJ.Date);
        //        Console.WriteLine("Title: " + e.Title);
        //        Console.WriteLine("City: " + e.City);
        //        Console.WriteLine();
        //    }
        //}
    }
}
