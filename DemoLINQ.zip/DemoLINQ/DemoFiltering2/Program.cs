﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoFiltering2
{
    class Program
    {
        class Developer
        {
            public string name;
            public string language;
            public int age;
        }
        static void Main(string[] args)
        {
            Developer[] developers = new Developer[]{
                new Developer{name="Paolo",language="C#"},
                new Developer{name="Marco",language="F#"},
                new Developer{name="Frank",language="VB.NET"},
            };
            var developersusingCsharp = from d in developers where d.name == "Marco" && d.language == "F#" select d;
            foreach(var item in developersusingCsharp)
            {
                Console.WriteLine("{0,1}",item.name);
            }
        }
    }
}
