﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LinqEF_Lab_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Mumbai13TrainingEntities db=new Mumbai13TrainingEntities();
            var q1 = from emp in db.ALBUMs.ToList() where emp.Name == "Rajat" select e;
            var q2 = from emp in db.ALBUMs.ToList() orderby emp.Name descending select emp;
            var q3 = from emp in db.ALBUMs.ToList() where emp.Price > Convert.ToDecimal(500) select e;
            var q4 = from emp in db.ALBUMs.ToList() where emp.Name[0] == 'A' select e;
            dgr.ItemsSource=q4.ToList();
        }
    }
}
