﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCoverDemoSample
{
    public class Calculation
    {
        public int AddNumbers(int firstNumber, int secondNumber)
        {
            return firstNumber + secondNumber;
        }
        public int MultiplyNumbers(int firstNumber, int secondNumber)
        {
            return firstNumber * secondNumber;
        }

        public void Main()
        {
            int sum = AddNumbers(5, 6);
            int mul = MultiplyNumbers(5, 6);
        }
    }
}
