﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NCoverDemoSample;

namespace NCoverDemoSampleTest
{
    [TestClass]
    public class CalculationTest
    {
    
        [TestMethod]
        public void TestAddNumbers()
        {
            Calculation calc = new Calculation();
            int actual, expected;
            expected = 11;
            actual = calc.AddNumbers(5, 6);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMultiplyNumbers()
        {
            Calculation calc = new Calculation();
            int actual, expected;
            expected = 30;
            actual = calc.MultiplyNumbers(5, 6);
            Assert.AreEqual(expected,actual);
        }

        //[TestCleanup]
        //public void TearDown()
        //{
        //    Calculation calc = new Calculation();
        //    calc = null;
        //}

    }
}
