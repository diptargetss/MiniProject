﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exceptions;

namespace Bank
{
    public class Account
    {
        public Account(string name, double bal)
        {
            
        }
        public int MinimumBalance { get; set; }
        private double balance;
        public void Deposit(double amount)
        {
            balance = amount;
        }

        public void withdraw(float amount)
        {
            balance -= amount;
        }
        public void TransferFunds(Account destination, float amount)
        {
            
            if (balance - amount < MinimumBalance)
            {
                throw new InsufficientFundsException();
            }
            destination.Deposit(amount);
            withdraw(amount); 
        }
        public double Balance
        {
            get { return balance; }
        }
    }
}
