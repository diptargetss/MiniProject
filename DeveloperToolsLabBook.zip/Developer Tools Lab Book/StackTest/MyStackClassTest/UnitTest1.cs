﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StackTest;

namespace MyStackClassTest
{
    [TestClass]
    public class UnitTest1
    {
        //MyStackClass stack = null;
        //[TestMethod]
        //public void Init()
        //{
        //    stack = new MyStackClass();
        //}

        [TestMethod] //to check for emptiness of stack
        public void IsEmp()
        {
            MyStackClass stack = new MyStackClass();
            Assert.AreEqual(true, stack.IsEmpty);
        }

        [TestMethod] //to insert first element
        public void FirstElement()
        {
            MyStackClass stack = new MyStackClass();
            stack.Push(10);
            Assert.AreEqual(false, stack.IsEmpty);
        }

        [TestMethod]//insert 2 elements and pop 1
        public void SecondTest()
        {
            MyStackClass stack = new MyStackClass();
            stack.Push(10);
            stack.Push(20);
            stack.Pop();
            Assert.AreEqual(false, stack.IsEmpty);
        }

        [TestMethod]
        public void Top()
        {

        }

        [TestMethod] 
        public void CleanUp()
        {
            MyStackClass stack = new MyStackClass();
            stack = null;
        }
    }
}
