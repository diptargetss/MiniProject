﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StackTest;

namespace Run
{
    class Program
    {
        static void Main(string[] args)
        {
            MyStackClass stack = new MyStackClass();
          
            stack.Push(10);
            stack.Push(20);
            stack.Push(30);
            stack.Pop();
            stack.Top();

            Console.WriteLine("Elements are");
            foreach()
        }
    }
}
