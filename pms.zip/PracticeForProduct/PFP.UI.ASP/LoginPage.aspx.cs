﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.Security;
using PFP.Entity;
using PFP.BL;

namespace PFP.UI.ASP
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            LoginCredsBL obj = new LoginCredsBL();

            LoginCreds o = new LoginCreds();
            o.UserName = txtuserid.Text;
            o.Pass = txtpassword.Text;
            bool flag = obj.LoginCredentials(o);
            Session["userName"] = txtuserid.Text;

            if (flag)
            {
                FormsAuthentication.RedirectFromLoginPage(txtuserid.Text, Persist.Checked);
            }
        }
    }
}