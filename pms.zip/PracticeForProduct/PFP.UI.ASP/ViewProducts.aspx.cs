﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using PFP.Exceptions;
using PFP.Entity;
using PFP.BL;

namespace PFP.UI.ASP
{
    public partial class ViewProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(5000);
        }

        protected void btnshowproducts_Click(object sender, EventArgs e)
        {
            try
            {
                System.Threading.Thread.Sleep(5000);

                ProductBL obj = new ProductBL();
                grdproducts.DataSource = obj.ShowAllProduct();
                grdproducts.DataBind();
            }
            catch(Exception)
            {
                Server.Transfer("Errorpage.aspx");
            }
        }

        protected void grdproducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ProductBL obj = new ProductBL();
            grdproducts.DataSource = obj.ShowAllProduct();
            grdproducts.PageIndex = e.NewPageIndex;
            grdproducts.DataBind();
        }
    }
}