﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using PFP.Entity;

namespace PFP.DAL
{
    public class ProductDAL
    {
        public List<Product> ShowAllProduct()
        {
            try
            {
                List<Product> getList = new List<Product>();
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "HMS_NN.usp_productasp";
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Product obj = new Product();
                    obj.PID = dr.GetInt32(0);
                    obj.ProductName = dr.GetString(1);
                    obj.Price = dr.GetDecimal(2);

                    getList.Add(obj);
                }
                dr.Close();
                con.Close();

                return getList;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }

        public bool AddProduct(Product obj)
        {
            bool flag = false;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
                SqlCommand cmd = new SqlCommand("INSERT INTO HMS_NN.ProductASP VALUES(@n , @p)", con);

                cmd.Parameters.AddWithValue("@n", obj.ProductName);
                cmd.Parameters.AddWithValue("@p", obj.Price);
                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();
                if (ra>0)
                {
                    flag = true;
                }

            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return flag;
        }

        public bool UpdateProduct(Product obj)
        {
            bool flag = false;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
                SqlCommand cmd = new SqlCommand("UPDATE HMS_NN.ProductASP SET ProductName=@n, Price=@p WHERE ProductID=@i", con);

                cmd.Parameters.AddWithValue("@i", obj.PID);
                cmd.Parameters.AddWithValue("@n", obj.ProductName);
                cmd.Parameters.AddWithValue("@p", obj.Price);

                con.Open();
                int ru = Convert.ToInt32(cmd.ExecuteNonQuery());
                con.Close();
                if (ru >0)
                {
                    flag = true;
                }
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return flag;
        }

        public bool DeleteProduct(int id)
        {
            bool flag = false;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
                SqlCommand cmd = new SqlCommand("DELETE FROM HMS_NN.ProductASP WHERE ProductID=@id", con);

                cmd.Parameters.AddWithValue("@id", id);

                con.Open();
                int rd = cmd.ExecuteNonQuery();
                con.Close();
                if (rd > 0)
                {
                    flag = true;
                }
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return flag;
        }

        public Product SearchProduct(int id)
        {
            Product retObj = new Product();
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
                SqlCommand cmd = new SqlCommand("SELECT * FROM HMS_NN.ProductASP WHERE ProductID=@id", con);

                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    retObj.PID = dr.GetInt32(0);
                    retObj.ProductName = dr.GetString(1);
                    retObj.Price = dr.GetDecimal(2);

                }
                con.Close();
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }

            return retObj;
        }

        public int MaxProdId()
        {
            int pid = 0;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
                SqlCommand cmd = new SqlCommand("SELECT MAX(ProductID)+1 FROM HMS_NN.ProductASP", con);

                con.Open();
                pid = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return pid;
        }
    }
}
