﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using PFP.Exceptions;
using PFP.Entity;
using PFP.DAL;

namespace PFP.BL
{
    public class ProductBL
    {
        public List<Product> ShowAllProduct()
        {
            try
            {
                ProductDAL obj = new ProductDAL();
                return obj.ShowAllProduct();
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }

        public int MaxProdId()
        {
            try
            {
                ProductDAL dobj = new ProductDAL();
                return dobj.MaxProdId();
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }

        public bool AddProduct(Product obj)
        {
            bool flag = false;
            try
            {
                ProductDAL dobj = new ProductDAL();
                if (ValidateProduct(obj))
                {
                    flag =dobj.AddProduct(obj);
                }

            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }

            return flag;
        }

        public bool UpdateProduct(Product obj)
        {
            bool flag = false;
            try
            {
                ProductDAL dobj = new ProductDAL();
                if (ValidateProduct(obj))
                {
                    flag = dobj.UpdateProduct(obj);
                }
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return flag;
        }

        public bool DeleteProduct(int id)
        {
            bool flag = false;
            try
            {
                ProductDAL dobj = new ProductDAL();
                flag = dobj.DeleteProduct(id);
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
            return flag;
        }

        private bool ValidateProduct(Product p)
        {
            bool flag = true;
            StringBuilder sb = new StringBuilder();

            if (p.PID <100 && p.PID >999)
            {
                flag = false;
                sb.Append("Product ID should be from 100 to 998");
            }
            if (p.ProductName == string.Empty)
            {
                flag = false;
                sb.Append("Product name cant be Null");
            }
            if (p.ProductName == "")
            {
                flag = false;
                sb.Append("Product name cant be Null");
            }
            if (p.ProductName == " ")
            {
                flag = false;
                sb.Append("Product name cant be Null");
            }
            if (p.Price <=0 )
            {
                flag = false;
                sb.Append("Price cant be Negative OR Zero");
            }
            if (flag == false)
            {
                throw new ProdcutExceptions(sb.ToString());
            }

            return flag;
        }

        public Product SearchProduct(int id)
        {
            try
            {
                ProductDAL dobj = new ProductDAL();
                //Product ojj = dobj.SearchProduct(id);
                return dobj.SearchProduct(id);
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
    }
}
