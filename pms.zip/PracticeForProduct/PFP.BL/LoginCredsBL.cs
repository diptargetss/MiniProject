﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using PFP.Entity;
using PFP.DAL;

namespace PFP.BL
{
    public class LoginCredsBL
    {
        public bool LoginCredentials(LoginCreds rec)
        {
            try
            {
                LoginCredsDAL obj = new LoginCredsDAL();
                bool flag = obj.LoginCredentials(rec);

                return flag;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
    }
}
