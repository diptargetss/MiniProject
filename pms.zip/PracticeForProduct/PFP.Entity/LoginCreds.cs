﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFP.Entity
{
    public class LoginCreds
    {
        #region Fields
        string userName;
        string pass;
        #endregion

        #region Properties
        public string Pass
        {
            get { return pass; }
            set { pass = value; }
        }

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
        #endregion
    }
}
