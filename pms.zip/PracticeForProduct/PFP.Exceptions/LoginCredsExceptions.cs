﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFP.Exceptions
{
    public class LoginCredsExceptions: ApplicationException
    {
        public LoginCredsExceptions(string message):base(message)
        {

        }

    }
}
