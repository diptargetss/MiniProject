﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MVCDbFirst.Models;

namespace MVCDbFirst.Controllers
{
    public class StaffController : Controller
    {
        private StaffContext db = new StaffContext();

        // GET: /Staff/
        public async Task<ActionResult> Index()
        {
            return View(await db.Staff_Master.ToListAsync());
        }

        // GET: /Staff/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Staff_Master staff_master = await db.Staff_Master.FindAsync(id);
            if (staff_master == null)
            {
                return HttpNotFound();
            }
            return View(staff_master);
        }

        // GET: /Staff/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /Staff/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="staff_code,staff_name,Design_code,Dept_code,hiredate,staff_dob,staff_address,mgr_code,staff_sal")] Staff_Master staff_master)
        {
            if (ModelState.IsValid)
            {
                db.Staff_Master.Add(staff_master);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(staff_master);
        }

        // GET: /Staff/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            Staff_Master staff_master = await db.Staff_Master.FindAsync(id);
            if (staff_master == null)
            {
                return HttpNotFound();
            }
            return View(staff_master);
        }

        // POST: /Staff/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="staff_code,staff_name,Design_code,Dept_code,hiredate,staff_dob,staff_address,mgr_code,staff_sal")] Staff_Master staff_master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(staff_master).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(staff_master);
        }

        // GET: /Staff/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Staff_Master staff_master = await db.Staff_Master.FindAsync(id);
            if (staff_master == null)
            {
                return HttpNotFound();
            }
            return View(staff_master);
        }

        // POST: /Staff/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Staff_Master staff_master = await db.Staff_Master.FindAsync(id);
            db.Staff_Master.Remove(staff_master);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        //Filter Data
        public async Task<ActionResult> FilterData()
        {
            //if (deptcode == null)
            //{
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            //}
            var query=from ob in db.Staff_Master where ob.Dept_code==177 select ob;
            if (query == null)
            {
                return HttpNotFound();
            }
            return View(query.ToList());
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
