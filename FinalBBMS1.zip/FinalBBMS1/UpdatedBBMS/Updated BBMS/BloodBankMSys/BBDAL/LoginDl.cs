﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entities;
using BBMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BBDAL
{
    public class LoginDl            //login checks for both admin and blood bank admin
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        //admin login check
        public bool AdminCheck(Admin adm)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BBMS_AdminLogin";
                cmd.Parameters.AddWithValue("@username", adm.Username);
                cmd.Parameters.AddWithValue("@password", adm.Password);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {

                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
        }

        //bank login check
        public bool ValidateBankLogin(Bloodbank bb)
        {
            bool valid = false;
            //int id;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BBMS_BBLogin";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@username", Convert.ToString(bb.BloodBankUserId)));
                cmd.Parameters.Add(new SqlParameter("@password", Convert.ToString(bb.BloodBankPwd)));
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    valid = true;
                    con.Close();
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return valid;
        }
    }
}
