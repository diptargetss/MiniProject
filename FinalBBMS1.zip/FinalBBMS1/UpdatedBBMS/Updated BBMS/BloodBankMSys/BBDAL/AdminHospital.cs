﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entities;
using BBMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BBDAL
{
    public class AdminHospital           //HOSPITAL SIDE OPERATION in admin
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;   
 
        //add hospital details
        public bool AddHospIdName(int id, string hname)
        {
            bool hospadd = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hospadm_add";
                cmd.Parameters.AddWithValue("@hid", id);
                cmd.Parameters.AddWithValue("@hname", hname);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    hospadd = true;
            }
            catch(SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return hospadd;
        }
        //update hospital detail
        public bool UpdateHospitalDetails(Hospital details)
        {
            bool hospupdate = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_upd";
                cmd.Parameters.AddWithValue("@hid", details.HospitalId);
                cmd.Parameters.AddWithValue("@hname", details.Hospitalname);
                cmd.Parameters.AddWithValue("@haddress", details.HospitalAddress);
                cmd.Parameters.AddWithValue("@hcity", details.HospitalCity);
                cmd.Parameters.AddWithValue("@hregion", details.Location);
                cmd.Parameters.AddWithValue("@hcontact", details.ContactNo);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    hospupdate = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return hospupdate;
        }
        //delete hospital details
        public bool DelHospitalDetails(int id)
        {
            bool hospdel = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_del";
                cmd.Parameters.AddWithValue("@hid", id);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    hospdel = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return hospdel;
        }
        //Search hospital details by Id
        public Hospital GetHospDetailsById(int id)
        {
            Hospital hospdetails = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_showbyid";
                cmd.Parameters.AddWithValue("@hid", id);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                //hospdetails = new Hospital();
                while (dr.Read())
                {
                    hospdetails = new Hospital();
                    hospdetails.HospitalId = dr.GetInt32(0);
                    hospdetails.Hospitalname = dr.GetString(1);
                    hospdetails.HospitalAddress = dr.GetString(2);
                    hospdetails.HospitalCity = dr.GetString(3);
                    hospdetails.Location = dr.GetString(4);
                    hospdetails.ContactNo = dr.GetString(5);
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return hospdetails;
        }
        //Get Hospital Details
        public List<Hospital> GetHospDetails()
        {
            List<Hospital> hospdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "hosp_showall";
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                hospdetails = new List<Hospital>();
                while (dr.Read())
                {
                    Hospital entity = new Hospital();
                    entity.HospitalId = dr.GetInt32(0);
                    entity.Hospitalname = dr.GetString(1);
                    entity.HospitalAddress = dr.GetString(2);
                    entity.HospitalCity = dr.GetString(3);
                    entity.Location = dr.GetString(4);
                    entity.ContactNo = dr.GetString(5);
                    hospdetails.Add(entity);
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return hospdetails;
        }
    }
}
