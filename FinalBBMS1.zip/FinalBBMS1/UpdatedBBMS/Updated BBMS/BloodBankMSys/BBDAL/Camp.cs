﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Entities;
using BBMS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BBDAL
{
    public class Camp
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        public bool AddCampDetails(BloodCamp camp)
        {
            //BloodCamp camp = new BloodCamp();
            bool campadded = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_camp";
                //cmd.Parameters.AddWithValue("@bid", camp.BloodBankId);
                cmd.Parameters.AddWithValue("@cid", camp.CampID);
                cmd.Parameters.AddWithValue("@cname", camp.Name);
                cmd.Parameters.AddWithValue("@cadd", camp.Address);
                cmd.Parameters.AddWithValue("@startdate", camp.StartDate);
                cmd.Parameters.AddWithValue("@enddate", camp.EndDate);
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    campadded = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return campadded;
        }

        public BloodCamp GetCampDetailsById(int id)
        {
            BloodCamp campdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_campbyid";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                campdetails = new BloodCamp();
                while (dr.Read())
                {
                    BloodCamp camp = new BloodCamp();
                    //camp.BloodBankId = dr.GetInt32(0);
                    camp.CampID = dr.GetInt32(1);
                    camp.Name = dr.GetString(2);
                    camp.Address = dr.GetString(3);
                    camp.StartDate = dr.GetDateTime(4);
                    camp.EndDate = dr.GetDateTime(5);

                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return campdetails;
        }

        public bool UpdateCampDetails(BloodCamp details)
        {
            bool campupdate = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_campupdate";
                //cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                cmd.Parameters.AddWithValue("@cid", details.CampID);
                cmd.Parameters.AddWithValue("@cname", details.Name);
                cmd.Parameters.AddWithValue("@city", details.City);
                cmd.Parameters.AddWithValue("@startdate", details.StartDate);
                cmd.Parameters.AddWithValue("@endate", details.EndDate);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    campupdate = true;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return campupdate;
        }
    }
}
