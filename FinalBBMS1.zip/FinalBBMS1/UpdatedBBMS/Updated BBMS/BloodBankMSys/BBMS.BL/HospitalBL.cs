﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBDAL;
using BBMS.Entities;
using BBMS.Exceptions;


namespace BBMS.BL
{
    public class HospitalBL
    {
        AdminHospital bbda = new AdminHospital();
        //For Adding Hospital
        public bool AddHospital(string id, string hname)
        {
            int i = Convert.ToInt32(id);
            if (i >= 100000 || i <= 999999)
                return bbda.AddHospIdName(i, hname);
            else
                return false;
        }


        //For Updating Hospital
        public bool UpdateHospitalDetails(Hospital details)
        {
            return bbda.UpdateHospitalDetails(details);
        }


        public bool DelHospitalDetails(int id)
        {
            return bbda.DelHospitalDetails(id);
        }
    }
}
