﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entities;
using BBDAL;

namespace BBMS.BL
{
    public class BloodBL
    {
        AdminBloodbank bbda = null;
        AdminBBMSDAL abbms = new AdminBBMSDAL();
        BloodBankDA bbd = new BloodBankDA();
        DonorDL ddl = new DonorDL();
        AdminHospital adh = new AdminHospital();
        InventoryDAL idl = new InventoryDAL();
        Camp c = new Camp();

        public BloodBL()
        {
            bbda = new AdminBloodbank();
        }
        
        
        
       
        
        
        //public bool BloodRequest(Hospital hos,int units)
        //{
        //    bool ch=bbda.RequestCheck(hos.Location,units);
        //    return ch;
        //}


        public List<Donor> ShowDonors(int bbid)
        {
            return bbd.ShowDonors(bbid);
        }


        public List<Bloodbank> ShowBanks()
        { 
            return bbda.ShowBanks(); 
        }

       
       
        public bool AddBankIdName(int id, string bname)
        {
            return bbda.AddBankIDName(id,bname);
        }

        public bool DelBankDetails(int id)
        {
            return bbda.DelBankDetails(id);
        }

     
        public List<Hospital> GetHospDetails()
        {
            return adh.GetHospDetails();
        }
        public Hospital GetHospDetailsById(int id)
        {
            return adh.GetHospDetailsById(id);
        }
        //public List<Bloodbank> GetBankDetails()
        //{
        //    return c.GetBankDetails();
        //}

        //Get bank details by id
        public Bloodbank GetBankDetailsById(string id)
        {

            int i = Convert.ToInt32(id);
                
          return bbda.GetBankDetailsById(i);
            
        }


        public List<BloodInventory> GetInventoryDetails()
        {
            return abbms.GetInventoryDetails();
        }

        //Get All Camp details for admin
        public List<BloodCamp> GetDonationCampDetails()
        {
            return abbms.GetDonationCampDetails();
        }
        
        //Get all donor details for admin
        public List<Donor> GetDonorDetails()
        {
            return abbms.GetDonorDetails();
        }

       
       
    }
}
