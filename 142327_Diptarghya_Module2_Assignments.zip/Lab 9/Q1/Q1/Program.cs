﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using Q1;
namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> NewDictionary = new Dictionary<string, string>();

            NewDictionary.Add("1", "Sayonara");
            NewDictionary.Add("3", "Bonjour");
            NewDictionary.Add("2", "Danke");
            NewDictionary.Add("4", "Gomen");
            
            Console.WriteLine("************Dictionary************");

            foreach (KeyValuePair<string, string> item in NewDictionary)
            {
                Console.WriteLine(item.Key + " -- " + item.Value);

            }
            

            Console.WriteLine("Please enter the key and value you want to enter in the table");
            string key1 = Console.ReadLine();
            string value1 = Console.ReadLine();
            // adding duplicate key values
            try
            {
                if ((NewDictionary.ContainsKey(key1)))
                    NewDictionary.Add(key1, value1);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }

            //if you want to change any value associated with a key
            Console.WriteLine("\n\nPlease enter the key whose value you want to change");
            string key2 = Console.ReadLine();
            try
            { 
            Console.WriteLine("\nPlease enter the new value  ");
            string value2 = Console.ReadLine();
            //val[key2] = value2;
            if (NewDictionary.ContainsKey(key2))
            {
               
                //val.Add(key2, value2);
                NewDictionary[key2] = value2;
            }
            else
            {
                throw new DictionaryException("Sorry key not found");
            }
            }
            catch(DictionaryException e)
              {
                Console.WriteLine(e.Message);
              }

           
           


            
            Console.WriteLine("****************Updated Dictionary*************");
            foreach (KeyValuePair<string, string> item in NewDictionary)
            {
                Console.WriteLine(item.Key + " -- " + item.Value);
            }
            

            Console.WriteLine("\n\nEnter the key you want to delete");
            string key3 = Console.ReadLine();
            NewDictionary.Remove(key3);

            
            Console.WriteLine("After Deletion Dictionary::");
            foreach (KeyValuePair<string, string> item in NewDictionary)
            {
                Console.WriteLine(item.Key + " -- " + item.Value);
            }
            
        }
    }
}
