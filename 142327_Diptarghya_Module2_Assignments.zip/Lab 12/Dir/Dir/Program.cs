﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Dir
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch ;
            do
            {
                //string fileName1="\Chennai.txt";
                int ch1;
                Console.WriteLine("Press 1 to create the directory.");
                Console.WriteLine("Press 2 to enter the batch details.");
                Console.WriteLine("Press 3 to create a backup copy.");
                Console.WriteLine("Press 4 to view the details of the text files");
                string path = @"P:\Diptarghya 142327\Module2_Lab_book_Assignments\Lab 12\Assembly";
                string copyPath = @"P:\Diptarghya 142327\Q12";
                string fileName1 = "Chennai.txt";
                string fileName2 = "Bangalore.txt";
                string fileName3 = "Mumbai.txt";
                string fileName4 = "Pune.txt";
                string line;
                string newpath1 = Path.Combine(path, fileName1);
                string newpath2 = Path.Combine(path, fileName2);
                string newpath3 = Path.Combine(path, fileName3);
                string newpath4 = Path.Combine(path, fileName4);
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        {

                            if (!Directory.Exists(path))
                                Directory.CreateDirectory(path);

                            FileStream fs = File.Create(newpath1);
                            FileStream fs1 = File.Create(newpath2); 
                            FileStream fs2 = File.Create(newpath3); 
                            FileStream fs3 = File.Create(newpath4); 
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Please enter the details ");
                            string str = Console.ReadLine();
                            StreamWriter sw=null;
                            Console.WriteLine("Press 1 to enter the details in Chennai file");
                            Console.WriteLine("Press 2 to enter the details in Bangalore file");
                            Console.WriteLine("Press 3 to enter the details in Mumbai file");
                            Console.WriteLine("Press 4 to enter the details in Pune file");
                            ch1 = Convert.ToInt32(Console.ReadLine());
                            if (ch1 == 1)
                            {
                                 sw = File.AppendText(str);
                                 
                            }
                            else if (ch1 == 2)
                            {
                                 sw = File.AppendText(str);
                            }
                            else if (ch1 == 3)
                            {
                                 sw = File.AppendText(str);
                                
                            }
                            else if (ch1 == 4)
                            {
                                
                                sw = File.AppendText(str);
                                
                            }
                            else
                            {
                                Console.WriteLine("Sorry wrong choice");
                            }
                            sw.Close();
                            break;
                           
                        }

                    case 3:
                        //Directory.CreateDirectory(copyPath);
                        Directory.Move(newpath1, copyPath);
                        break;
                    case 4:
                        Console.WriteLine("\n\n Chennai file details:  \n");
                        StreamReader br = new StreamReader(newpath1);
                        while (((line = br.ReadLine()) != null))
                        {
                            Console.WriteLine(line);
                        }
                        br.Close();


                        Console.WriteLine("\n\n Bangalore file details:  \n");
                        StreamReader br1 = new StreamReader(newpath2);
                        while (((line = br1.ReadLine()) != null))
                        {
                            Console.WriteLine(line);
                        }
                        br1.Close();
                        Console.WriteLine("\n\n Mumbai file details:  \n");
                        StreamReader br2 = new StreamReader(newpath3);
                        while (((line = br2.ReadLine()) != null))
                        {
                            Console.WriteLine(line);
                        }
                        br2.Close();
                        Console.WriteLine("\n\n Pune file details:  \n");
                        StreamReader br3 = new StreamReader(newpath4);
                        while (((line = br3.ReadLine()) != null))
                        {
                            Console.WriteLine(line);
                        }
                        br3.Close();

                        break;

                    case 5: Environment.Exit(0); break;
                }
            }
            while (ch != 5);
        }
    }
}
