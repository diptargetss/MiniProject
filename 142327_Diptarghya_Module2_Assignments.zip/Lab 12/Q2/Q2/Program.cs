﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the source file");
            string copyFrom = Console.ReadLine();
            Console.WriteLine("Please enter the destination file");
            string copyTo = Console.ReadLine();

            

            File.Copy(copyFrom, copyTo);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Contents of file A:        {0}",File.ReadAllText(copyFrom));
            Console.WriteLine("Contents of file B:        {0}", File.ReadAllText(copyTo));
        }
    }
}
