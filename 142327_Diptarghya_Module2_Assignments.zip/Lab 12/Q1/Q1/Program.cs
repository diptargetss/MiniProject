﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            
                //FileStream fs = null;
                Console.WriteLine("Please enter the name of the file ");
                string str = Console.ReadLine();
                string line;
                try
                {
               if(File.Exists(str))
               {
                   //fs = new FileStream(str, FileMode.Open, FileAccess.Read);
                   StreamReader br = new StreamReader(str);
                   while(((line=br.ReadLine())!=null))
                   {
                       Console.WriteLine(line);
                   }
                   br.Close();
                //fs.Close();
               }
               else
               {
                   Console.WriteLine ("Sorry file not found");
               }
             }
            catch(FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch(FileLoadException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();
        }
    }
}