﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierLib
{
    public class Supplier
    {
        public int supplierId;
        public string supplierName;
        public string city;
        public string phoneNo;
        public string email;
        public void AcceptDetails(Supplier sp)
        {
            Console.WriteLine("Enter Supplier Id:");
            sp.supplierId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter supplier name:");
            sp.supplierName = Console.ReadLine();
            Console.WriteLine("Enter city:");
            sp.city = Console.ReadLine();
            Console.WriteLine("Enter phone no.:");
            sp.phoneNo = Console.ReadLine();
            Console.WriteLine("Email:");
            sp.email = Console.ReadLine();
        }
        public void DisplayDetails()
        {
            Console.WriteLine("Supplier Id:"+this.supplierId);
            Console.WriteLine("Supplier Name:"+this.supplierName);
            Console.WriteLine("City:"+this.city);
            Console.WriteLine("Phone No:"+this.phoneNo);
            Console.WriteLine("Email:"+this.email);

            
        }
    }
}
