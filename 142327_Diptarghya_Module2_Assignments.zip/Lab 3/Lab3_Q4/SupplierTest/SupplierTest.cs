﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SupplierLib;

namespace SupplierDemo
{
    class SupplierTest
    {
        static void Main(string[] args)
        {
            Supplier sp = new Supplier();
            sp.AcceptDetails(sp);
            sp.DisplayDetails();

        }
    }
}
