﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityParticipant;

namespace University
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Student Details:");
            Console.WriteLine("Enter ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Foundation marks:");
            int foundationMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Web Basic Marks:");
            int webBasicMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter DotNet Marks:");
            int dotnetMarks = Convert.ToInt32(Console.ReadLine());
            Participant pp = new Participant(id, name, foundationMarks, webBasicMarks, dotnetMarks);
            pp.CalcTotalMarks();
            Console.WriteLine("Obtained Marks:"+pp.ObtainedMarks);
            Console.WriteLine("Total Marks:"+Participant.TotalMarks);
            Console.WriteLine("Company Name:"+Participant.Company_name);
            Console.WriteLine("Employee Name:"+pp.Name);
            Console.WriteLine("Percentage:"+pp.CalcPercentage());

        }
    }
}
