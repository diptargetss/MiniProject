﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exceptions;

namespace UniversityParticipant
{
    public class Participant
    {
        
        private string name;
        public string Name
        {
            get { return name; }
            set { name=value; }
        }
        
        
        public int EmpId { get; set; }
        public static string Company_name { get; set; }
        private int foundation;
        private int WebBasic;
        private int dotnet;

        public int FoundationMarks
        {
            get { return foundation; }
            set {
                try
                {
                    if (value >= 0 && value <= 100)
                        foundation = value;
                    else
                        throw new InvalidMarksException();
                }
                catch(InvalidMarksException e)
                {
                    Console.WriteLine("Enter valid marks");
                    System.Environment.Exit(0);
                }
            }
        }
        public int WebBasicMarks
        {
            get { return WebBasic; }
            set
            {
                try
                {
                    if (value >= 0 && value <= 100)
                        WebBasic = value;
                    else
                        throw new InvalidMarksException();
                }
                catch (InvalidMarksException e)
                {
                    Console.WriteLine("Enter valid marks");
                    System.Environment.Exit(0);
                }
            }
        }
        public int DotNetMarks
        {
            get { return dotnet; }
            set
            {
                try
                {
                    if (value >= 0 && value <= 100)
                        dotnet = value;
                    else
                        throw new InvalidMarksException();
                }
                catch (InvalidMarksException e)
                {
                    Console.WriteLine("Enter valid marks");
                    System.Environment.Exit(0);
                }
            }
        }
        
        public static int TotalMarks { get; set; }
        public int ObtainedMarks { get; set; }
        public double percentage { get; set; }
        public Participant()
        {
            
        }
        public Participant(int EID,string n,int foundationMarks,int WebBasicMarks,int DotNetMarks)
        {
            EmpId = EID;
            Name = n;
            FoundationMarks = foundationMarks;
            this.WebBasicMarks = WebBasicMarks;
            this.DotNetMarks = DotNetMarks;
        }
        static Participant()
        {
            Company_name = "Corporate University";
            TotalMarks = 300;
        }
        public void CalcTotalMarks()
        {
            ObtainedMarks = FoundationMarks + WebBasicMarks + DotNetMarks;
            
        }
        public double CalcPercentage()
        {
            percentage =(((double)ObtainedMarks / TotalMarks) * 100);
            return percentage;
        }


    }
}
