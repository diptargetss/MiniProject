﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CAR.Entity
{
    //Defining Car entity
    public class Car
    {
        #region Attributes

        int make;
        int model;    
        int year;    
        int sPrice;

        #endregion

        #region properties

        public int Make
        {
            get { return make; }
            set { make = value; }
        }

        public int Model
        {
            get { return model; }
            set { model = value; }
        }

        public int Year
        {
            get { return year; }
            set { year = value; }
        }

        public int SPrice
        {
            get { return sPrice; }
            set { sPrice = value; }
        }

        #endregion

        #region Contructor

        public Car()
        {

        }

        public Car(int make, int model, int year, int Price)
        {
            this.make = make;
            this.model = model;
            this.year = year;
            this.sPrice = Price;
        }

        #endregion
    }
}
