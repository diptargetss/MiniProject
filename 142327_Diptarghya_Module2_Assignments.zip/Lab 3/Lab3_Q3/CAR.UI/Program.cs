﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CAR.Entity;

namespace CAR.UI
{
    class Program
    {
        //Declaring array of type Car
        static Car[] carArray = new Car[10];

        static void Main(string[] args)
        {
            int choice;
            
            do
            {
                //Printing Operations Menu
                Menu();
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    
                    case 1: AddNewCar();
                        break;

                    case 2: ModifyDetails();
                        break;

                    case 3: Search();
                        break;

                    case 4: DisplayAll();
                        break;

                    case 5: DeleteCar();
                        break;

                    case 6: Environment.Exit(0);
                        break;

                    default: Console.WriteLine("Please enter a valid choice!!");
                        break;
                }
            } while (choice != 6);
        }

        //Method to print Menu
        private static void Menu()
        {
            Console.WriteLine("*********Catalog Of Used Cars**********");
            Console.WriteLine("1. Add a new car");
            Console.WriteLine("2. Modify the details of particular car");
            Console.WriteLine("3. Search a car");
            Console.WriteLine("4. List all the cars");
            Console.WriteLine("5. Delete a car");
            Console.WriteLine("6. Quit");
            Console.WriteLine("Please Enter Your choice : ");
        }

        //Method to add new car
        private static void AddNewCar()
        {
            int index = 0;
            Car car = new Car();

            Console.WriteLine("Please enter the car make");
            car.Make = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter the car model");
            car.Model = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter the year of manufacture");
            car.Year = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Plesae enter the sale price of the car");
            car.SPrice = Convert.ToInt32(Console.ReadLine());

            for (index = 0; index < carArray.Length; index++)
            {
                if (carArray[index] == null)
                    break;   
            }

            carArray[index] = car;

            Console.WriteLine();
            Console.WriteLine("A new car successfully added!!");
        }

        //Method to delete details of a car
        private static void DeleteCar()
        {
            int make;
            
            Console.WriteLine("Please enter the car make to delete the car");
            make = Convert.ToInt32(Console.ReadLine());

            Car car = new Car();

            for (int i = 0; i < carArray.Length; i++)
            {
                if (carArray[i] == null)
                {
                    car = null;
                    break;
                }
                else
                {
                    if (carArray[i].Make == make)
                    {
                        car = carArray[i];
                        break;
                    }
                    else
                        car = null;
                }
            }

            if (car == null)
                Console.WriteLine("No such record found!");
            else
            {
                for (int i = 0; i < carArray.Length; i++)
                {
                    if (carArray[i].Make == make)
                    {
                        carArray[i] = null;
                    }
                }

                Console.WriteLine("Record Removed successfully!!!");
            }
        }


        //Method to modify details of a car
        private static void ModifyDetails()
        {
            int make;

            Car car = new Car();
            
            Console.WriteLine("Please enter the car make to modify it");
            make = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < carArray.Length; i++)
            {
                if (carArray[i] == null)
                {
                    car = null;
                    break;
                }
                else
                {
                    if (carArray[i].Make == make)
                    {
                        car = carArray[i];
                        break;
                    }
                    else
                        car = null;
                }
            }

            if (car == null)
                Console.WriteLine("Car with the make {0} is not found.", make);
            else
            {
                Console.WriteLine("Please enter the car make");
                car.Make = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please enter the car model");
                car.Model = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please enter the year of manufacture");
                car.Year = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Plesae enter the sale price of the car");
                car.SPrice = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Car details updated successfully");
            }
        }


        //Method to display details of all cars
        private static void DisplayAll()
        {            
            if (carArray[0] == null)
                Console.WriteLine("No records found!");

            else
            {
                Console.WriteLine("List of all the cars present : ");
                Console.WriteLine();

                foreach (Car c in carArray)
                {
                    if (c == null)
                        break;
                    else
                    {
                        Console.WriteLine("Car make                : {0}", c.Make);
                        Console.WriteLine("Car model               : {0}", c.Model);
                        Console.WriteLine("Car Year of manufacture : {0}", c.Year);
                        Console.WriteLine("Car Selling price       : {0}", c.SPrice);
                        Console.WriteLine();
                    }
                }
            }
        }


        //Method to search for a particular car
        private static void Search()
        {
            int make;

            Console.WriteLine("Please enter the make of car to be searched");                       
            make = Convert.ToInt32(Console.ReadLine());

            Car car = new Car();

            for (int i = 0; i < carArray.Length; i++)
            {
                if (carArray[i] == null)
                {
                    car = null;
                    break;
                }
                else
                {
                    if (carArray[i].Make == make)
                    {
                        car = carArray[i];
                        break;
                    }
                    else
                        car = null;
                }
            }

            if(car == null)
                Console.WriteLine("No such record found!");
            
            else{
                    Console.WriteLine("Car make                : {0}", car.Make);
                    Console.WriteLine("Car model               : {0}", car.Model);
                    Console.WriteLine("Car Year of manufacture : {0}", car.Year);
                    Console.WriteLine("Car Selling price       : {0}", car.SPrice);
                }
        }
    }
}
