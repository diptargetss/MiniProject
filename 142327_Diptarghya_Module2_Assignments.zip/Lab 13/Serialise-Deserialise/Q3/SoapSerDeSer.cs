﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization;
using Contact;


namespace Q3
{
    class SoapSerDeSer
    {
        static ContactClass c1 = null;

        static void Main(string[] args)
        {
            c1 = new ContactClass();

            Console.WriteLine("\nEnter the Details to get it Serialised in Soap fashion\n");

            Console.WriteLine("\n-------------------");
            Console.WriteLine("Details of Person ");
            Console.Write("\nEnter the Contact No: ");
            c1.ContactNo = Int32.Parse(Console.ReadLine());

            Console.Write("Enter the Contact Name: ");
            c1.ContactName = Console.ReadLine();

            Console.Write("Enter the Cell No: ");
            c1.CellNo = Console.ReadLine();


            Console.WriteLine("-------------------\n");


            int choice;
            do
            {
                Console.WriteLine("******** Menu *********\n");
                Console.WriteLine("1. Soap Serialisation");
                Console.WriteLine("2. Soap DeSerialisation");
                Console.WriteLine("3. Exit");
                Console.WriteLine("------");
                Console.Write("Enter the Choice : ");
                choice = Int32.Parse(Console.ReadLine());
                Console.WriteLine("***********************\n");
                switch (choice)
                {
                    case 1:
                        {
                            if (SoapSerialisation())
                            {
                                Console.WriteLine("\n Soap Serialisation done successfully\n");
                            }
                            else
                            {
                                Console.WriteLine("\n Error in performing Soap Serialisation\n");
                            }

                        }
                        break;

                    case 2:
                        {
                            Console.WriteLine("\nBelow Data Is Shown after Soap DeSerialisation\n");
                            SoapDeSerialisation();
                            Console.WriteLine("\n-------- End --------\n\n");

                        }

                        break;
                    case 3: System.Environment.Exit(0);
                        break;

                    default: Console.WriteLine("Wrong Choice");
                        break;
                }
            } while (choice != 3);
        }

        private static bool SoapSerialisation()
        {

            FileStream fs = null;
            bool flag = false;
            try
            {
                fs = new FileStream(@"Contact.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
                SoapFormatter sf = new SoapFormatter();
                sf.Serialize(fs, c1);
                flag = true;
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (FileLoadException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                fs.Close();
            }
            return flag;
        }

        private static void SoapDeSerialisation()
        {
            FileStream fs = null;

            try
            {
                fs = new FileStream(@"P:\Diptarghya 142327\Module2_Lab_book_Assignments\Lab 13\Serialise-Deserialise\Q3\bin\Debug\Contact.xml", FileMode.Open, FileAccess.Read);

                SoapFormatter sf = new SoapFormatter();

                ContactClass c2 = (ContactClass)sf.Deserialize(fs);

                Console.WriteLine("\nDetails of Person \n");
                Console.WriteLine("Name : {0}", c2.ContactNo);
                Console.WriteLine("Roll No : {0}", c2.ContactName);
                Console.WriteLine("Address : {0}", c2.CellNo);


            }

            catch (FileNotFoundException e)
            {

                throw e;
            }
            catch (Exception e)
            {

                throw e;
            }
            finally
            {
                fs.Close();
            }

        }


    }
}
