﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contact;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace Q2
{
    class BinaryDeserialise
    {
        static List<ContactClass> myContactList = null;
        static void Main(string[] args)
        {
            myContactList = new List<ContactClass>();
            Console.WriteLine("\nBelow Data Is Shown after Binary DeSerialisation\n");
            BinDeSerialise();
            ShowBinDeserialise();

        }
        private static List<ContactClass> BinDeSerialise()
        {
            FileStream fs = null;
            List<ContactClass> newStudList = null;

            try
            {
                fs = new FileStream(@"P:\Diptarghya 142327\Module2_Lab_book_Assignments\Lab 13\Serialise-Deserialise\Q1\bin\Debug\Contact.dat", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                newStudList = (List<ContactClass>)bf.Deserialize(fs);

            }

            catch (FileNotFoundException e)
            {

                throw e;
            }
            catch (Exception e)
            {

                throw e;
            }
            finally
            {
                fs.Close();
            }
            return newStudList;
        }
        private static void ShowBinDeserialise()
        {
            List<ContactClass> tempList = BinaryDeserialise.BinDeSerialise();
            if (tempList != null)
            {
                

                int i = 0;
                foreach (var item in tempList)
                {

                    Console.WriteLine("\nDetails of Person {0}\n", i + 1);
                    i++;
                    Console.WriteLine("Name : {0}", item.ContactNo);
                    Console.WriteLine("Roll No : {0}", item.ContactName);
                    Console.WriteLine("Address : {0}", item.CellNo);

                }

            }
        }
    }
}
