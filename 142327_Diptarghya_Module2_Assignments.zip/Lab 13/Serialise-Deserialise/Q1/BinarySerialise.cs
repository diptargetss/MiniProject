﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Contact;

namespace Q1
{
    class BinarySerialise
    {
        static List<ContactClass> myContactList = null;
        
       
        static void Main(string[] args)
        {

            myContactList = new List<ContactClass>();

            Console.WriteLine("\nEnter the Details to get it Serialised in Binary fashion\n");
            Console.Write("No of Person's Contact Details you need to enter : ");
            int n = Convert.ToInt32(Console.ReadLine());

            ContactClass[] cnt = new ContactClass[n];
            for (int i = 0; i < n; i++)
            {
                cnt[i] = new ContactClass();
            }
            for (int i = 0; i < n; i++)
            {

                Console.WriteLine("\n-------------------");
                Console.WriteLine("Details of Person {0}", i + 1);
                Console.Write("\nEnter the Contact No: ");
                cnt[i].ContactNo = Int32.Parse(Console.ReadLine());

                Console.Write("Enter the Contact Name: ");
                cnt[i].ContactName = Console.ReadLine();

                Console.Write("Enter the Cell No: ");
                cnt[i].CellNo = Console.ReadLine();

                myContactList.Add(cnt[i]);
                Console.WriteLine("-------------------\n");
            }
           
           if (BinSerialise())
            {
                                
               Console.WriteLine("\nSuccessfully Done Serialisation");
            }
            else
            {
               Console.WriteLine("\nError While doing Serialisation");
            }
        }
        private static bool BinSerialise()
        {

            FileStream fs = null;
            bool flag = false;
            try
            {
                fs = new FileStream("Contact.dat", FileMode.OpenOrCreate, FileAccess.ReadWrite);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, myContactList);
                flag = true;
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (FileLoadException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                fs.Close();
            }
            return flag;
        }
       
    }
}
            
            
            
            
            
            


