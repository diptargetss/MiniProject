﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DelegateLIB;

namespace DelegateUI
{
    class ArithOps
    {
        static void Main(string[] args)
        {
            ArithmeticOperation aoperation = new ArithmeticOperation();

            Arithmeticdelegate ardel;

            int choice;
            do
            {
                //Menu
                
                Console.WriteLine("1. Addition...");
                Console.WriteLine("2. Multiply...");
                Console.WriteLine("3. Division...");
                Console.WriteLine("4. Subtract...");
                Console.WriteLine("5. GreaterOfTwo...");
                Console.WriteLine("6. Exit..");
                choice = Convert.ToInt32(Console.ReadLine());
                
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter Number 1: ");
                        int n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        int n2 = Convert.ToInt32(Console.ReadLine());

                        ardel = new Arithmeticdelegate(aoperation.Addition);
                        ardel(n1,n2);

                        break;

                    case 2:
                        Console.WriteLine("Enter Number 1: ");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        n2 = Convert.ToInt32(Console.ReadLine());

                        ardel = new Arithmeticdelegate(aoperation.Multiply);
                        ardel(n1,n2);
                        break;

                    case 3:
                        Console.WriteLine("Enter Number 1: ");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        n2 = Convert.ToInt32(Console.ReadLine());

                        ardel = new Arithmeticdelegate(aoperation.Division);
                        ardel(n1,n2);
                        break;

                    case 4:
                        Console.WriteLine("Enter Number 1: ");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        n2 = Convert.ToInt32(Console.ReadLine());

                        ardel = new Arithmeticdelegate(aoperation.Subtract);
                        ardel(n1,n2);
                        break;

                    case 5:
                        Console.WriteLine("Enter Number 1: ");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        n2 = Convert.ToInt32(Console.ReadLine());

                        ardel = new Arithmeticdelegate(aoperation.GreaterOfTwo);
                        ardel(n1,n2);
                        break;
                        
                    case 6:
                        System.Environment.Exit(0);
                        break;

                    default:
                        break;
                }
            } while (choice !=6);
        }
    }
}
