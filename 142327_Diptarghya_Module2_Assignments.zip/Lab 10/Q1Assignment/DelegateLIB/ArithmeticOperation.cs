﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateLIB
{
    //Creating an delegate
    public delegate void Arithmeticdelegate(int number1, int number2);

    public class ArithmeticOperation
    {
        //The operations include Add Numbers, Multiply Numbers, Divide Numbers, Subtract Numbers and Find Max Number.
        
        public void Addition(int number1, int number2)
        {
            Console.WriteLine("Additon of {0} and {1} is {2}",number1, number2, number1 + number2);
        }

        public void Multiply(int number1, int number2)
        {
            Console.WriteLine("Product of {0} and {1} is {2}", number1, number2, number1 * number2);
        }

        public void Division(int number1, int number2)
        {
            Console.WriteLine("Division of {0} and {1} is {2}", number1, number2, number1 / number2);
        }

        public void Subtract(int number1, int number2)
        {
            Console.WriteLine("Difference of {0} and {1} is {2}", number1, number2, number1 - number2);
        }

        public void GreaterOfTwo(int number1, int number2)
        {
            if (number1>number2)
            {
                Console.WriteLine("{0} is Greater then {1}", number1, number2);
            }
            else if(number2>number1)
            {
                Console.WriteLine("{1} is Greater then {0}", number1, number2);
            }
            else
            {
                Console.WriteLine("Both are Equal");
            }
        }
    }
}
