﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DelegateLIB;

namespace DelegateUI
{
    class AOPL
    {
        static void PerformArithmeticOperation(int num1, int num2, Arithmeticdelegate arOperation)
        {
            arOperation(num1, num2);
        }


        static void Main(string[] args)
        {
            ArithmeticOperation baseobj = new ArithmeticOperation();

            Arithmeticdelegate delegateobj;

            int choice;
            do
            {
                //Menu

                Console.WriteLine("1. Addition...");
                Console.WriteLine("2. Multiply...");
                Console.WriteLine("3. Divition...");
                Console.WriteLine("4. Subtract...");
                Console.WriteLine("5. GreaterOfTwo...");
                Console.WriteLine("6. Exit..");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter Number 1: ");
                        int n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        int n2 = Convert.ToInt32(Console.ReadLine());

                        delegateobj = new Arithmeticdelegate(baseobj.Addition);
                        AOPL.PerformArithmeticOperation(n1,n2,delegateobj);                                                
                        break;

                    case 2:
                        Console.WriteLine("Enter Number 1: ");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        n2 = Convert.ToInt32(Console.ReadLine());

                        delegateobj = new Arithmeticdelegate(baseobj.Multiply);
                        //delegateobj(n1, n2);
                        AOPL.PerformArithmeticOperation(n1, n2, delegateobj);                                                
                        break;

                    case 3:
                        Console.WriteLine("Enter Number 1: ");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        n2 = Convert.ToInt32(Console.ReadLine());

                        delegateobj = new Arithmeticdelegate(baseobj.Divition);
                        //delegateobj(n1, n2);
                        AOPL.PerformArithmeticOperation(n1, n2, delegateobj);                                                
                        break;

                    case 4:
                        Console.WriteLine("Enter Number 1: ");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        n2 = Convert.ToInt32(Console.ReadLine());

                        delegateobj = new Arithmeticdelegate(baseobj.Subtract);
                        //delegateobj(n1, n2);
                        AOPL.PerformArithmeticOperation(n1, n2, delegateobj);                                                
                        break;

                    case 5:
                        Console.WriteLine("Enter Number 1: ");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Number 2: ");
                        n2 = Convert.ToInt32(Console.ReadLine());

                        delegateobj = new Arithmeticdelegate(baseobj.GreaterOfTwo);
                        //delegateobj(n1, n2);
                        AOPL.PerformArithmeticOperation(n1, n2, delegateobj);                                                
                        break;

                    case 6:
                        System.Environment.Exit(0);
                        break;

                    default:
                        break;
                }
            } while (choice != 6);
        }
    }
}
