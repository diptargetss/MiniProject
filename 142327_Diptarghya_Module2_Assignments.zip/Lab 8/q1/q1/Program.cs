﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace q1
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch;
            int i = 0;
            Hashtable hbl = new Hashtable();
            ICollection keys = hbl.Keys;

            do
            {
                Console.WriteLine("\n***********RTO Department**************");
                Console.WriteLine("Press 1 to add records.");
                Console.WriteLine("Press 2 to search records.");
                Console.WriteLine("Press 3 to display all records.");
                Console.WriteLine("Press 4 to display total count of records.");
                Console.WriteLine("Press 5 to remove any record.");
                Console.WriteLine("Press 6 to exit.");
                Console.WriteLine("Please make your choice");
                
                ch = (Convert.ToInt32(Console.ReadLine()));

                switch (ch)
                {
                    case 1:
                        {
                            Console.Clear();
                            string dat, dat2;
                            Console.WriteLine("Enter the code and city you want to enter in the data");
                            dat2 = Console.ReadLine();
                            dat = Console.ReadLine();
                            i++;
                            hbl.Add(dat2, dat);
                            break;
                        }
                    case 2:
                        {
                            Console.Clear();
                            Console.WriteLine("Enter the city you want to search");
                            string str = Console.ReadLine();
                            
                            if (hbl.Contains(str))
                            {
                                Console.WriteLine("Record found");
                            }
                            else
                                Console.WriteLine("Record not found");
                            break;
                        }
                    case 3:
                        {
                            Console.Clear();
                            Console.WriteLine("Printing City and City Name");
                            foreach (object obj in keys)
                            {
                                string code = (string)obj;
                                string cityName = (string)hbl[code];
                                Console.WriteLine("Code: {0} -- City = {1}", code, cityName);
                            }
                            break;
                        }
                    case 4:
                        {
                            Console.Clear();
                            var counts = hbl.Count;
                            Console.WriteLine("Total no of accounts are {0}", counts);
                            break;
                        }
                    case 5:
                        {
                            Console.Clear();
                            Console.WriteLine("Enter the code or the city name you want to remove");
                            string s = Console.ReadLine();
                            hbl.Remove(s);
                            break;
                        }
                    case 6: Environment.Exit(0); break;
                    default: Console.WriteLine("please check your choice"); break;
                }
            } while (ch != 6);
        }
    }
}
