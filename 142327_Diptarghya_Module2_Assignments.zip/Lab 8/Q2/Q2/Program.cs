﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Q2
{
    class Program
    {
        static Hashtable GetHashtable()
        {
            Hashtable htl = new Hashtable(); ;
            htl.Add("Area", 1000);
            htl.Add("Perimeter", 55);
            htl.Add("Mortgage", 540);
            return htl;
        }
        static void Main(string[] args)
        {
            Hashtable hbl = GetHashtable();
            Console.WriteLine("Details of hastable are as follows");
            foreach (DictionaryEntry d in hbl)
            {
                Console.WriteLine(d.Key + " -- " + d.Value);
            }
            
            if(hbl.Contains("Perimeter"))
                Console.WriteLine("Perimeter key found");
            else
                Console.WriteLine("Perimeter key not found");
            Console.WriteLine(hbl.Contains("Area"));
            int value = (int)hbl["Area"];
            Console.WriteLine(value);

           

            hbl.Remove("Mortgage");

            Console.WriteLine("Details of hastable after deletion are as follows");
            foreach(DictionaryEntry d in hbl)
            {
                Console.WriteLine(d.Key+" -- "+d.Value);
            }
            Console.ReadKey();
        }
    }
}
