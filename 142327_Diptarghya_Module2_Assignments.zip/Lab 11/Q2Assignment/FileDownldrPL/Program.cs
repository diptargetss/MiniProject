﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileDownloader;

namespace FileDownldrPL
{
    class Program
    {
        public static void Main(string[] args)
        {
            //Instantiate
            FileDownloadercls  fd = new FileDownloadercls("http://www.microsoft.com/vstudio/expressv10.zip","d:\\setups");
            
            //Register Event Handler
            fd.DownLoadComplete += fdDownLoadComplete;
            //Start the task...
            fd.DownLoadResource();
            Console.ReadKey();
        }
        static void fdDownLoadComplete(int perc)
        {
            Console.SetCursorPosition(10, 10);
            Console.Write("Downloading {0} Percent Complete", perc);
        }
    }
}
