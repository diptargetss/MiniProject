﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEventLIB
{

    public delegate void EventHandler();//Defined an Delegate 

    public class CreditClass
    {
        //CreditCardNo, CardHolderName, BalanceAmount, CreditLimit
        //GetBalance(), GetCreditLimit(), and MakePayment().

        public event EventHandler MyEvent;//An event 

        #region Attributes/Prop
        int creditCardNo;
        string cardHolderName;
        int balanceAmount;
        int creditLimit;

        public int CreditLimit
        {
            get { return creditLimit; }
            set { creditLimit = value; }
        }

        public int BalanceAmount
        {
            get { return balanceAmount; }
            set { balanceAmount = value; }
        }

        public string CardHolderName
        {
            get { return cardHolderName; }
            set { cardHolderName = value; }
        }

        public int CreditCardNo
        {
            get { return creditCardNo; }
            set { creditCardNo = value; }
        }
        #endregion

        public void GetBalance()
        {

        }

        public void GetCreditLimit()
        {

        }

        public void MakePayment()
        {
            if (MyEvent != null)
                MyEvent();
        }

    }
}
