﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyEventLIB;

namespace MyEventPL
{
    class Program
    {
        static void MyEventHandler()
        {
            Console.WriteLine("Amount Credited");
        }


        static void Main(string[] args)
        {
            CreditClass obj = new CreditClass();//Declaring Class Object 
            obj.MyEvent += MyEventHandler;//Adding Event into event List and its handler in event

            obj.MakePayment();//Fire the Event

        }
    }
}
