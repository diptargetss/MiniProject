﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankAccountLIB;

namespace BankUI
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("-------------ICICI BANK--------------");
            ICICI salary = new ICICI();
            ICICI business = new ICICI();

            salary.AccountType = BankAccountTypeEnum.Saving;
            business.AccountType = BankAccountTypeEnum.Current;

            salary.Deposit(50000);
            business.Deposit(20000);

            Console.WriteLine("Savings account balance : {0}", salary.GetBalance());
            Console.WriteLine("Current account balance : {0}", business.GetBalance());

            if (salary.Transfer(business, 5000))
                Console.WriteLine("Transfer SuccessFull");           
            else
                Console.WriteLine("Transfer Failed");

            Console.WriteLine("Savings account balance : {0}", salary.GetBalance());
            Console.WriteLine("Current account balance : {0}", business.GetBalance());

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("----------HSBC BANK------------");
            HSBC sal = new HSBC();
            HSBC bus = new HSBC();

            sal.AccountType = BankAccountTypeEnum.Saving;
            bus.AccountType = BankAccountTypeEnum.Current;

            sal.Deposit(100000);
            bus.Deposit(20000);

            Console.WriteLine("Savings account balance : {0}", sal.GetBalance());
            Console.WriteLine("Current account balance : {0}", bus.GetBalance());

            if (sal.Transfer(bus, 30000))
                Console.WriteLine("Transfer SuccessFull");
            else
                Console.WriteLine("Transfer Failed");

            Console.WriteLine("Savings account balance : {0}", sal.GetBalance());
            Console.WriteLine("Current account balance : {0}", bus.GetBalance());
        }
    }
}
