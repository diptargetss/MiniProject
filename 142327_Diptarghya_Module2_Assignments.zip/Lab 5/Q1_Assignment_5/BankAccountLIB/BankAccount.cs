﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountLIB
{
    public class BankAccount : IBankAccount
    {
        protected double Balance { get; set; }

        public double GetBalance()
        {
            return Balance;
        }

        public void Deposit(double amount)
        {
            Balance += amount;
        }

        public virtual bool Withdraw(double amount)
        {
            return true;
        }

        public virtual bool Transfer(BankAccount toAccount, double amount)
        {
            return true;
        }

        public BankAccountTypeEnum AccountType { get; set; }
    }


    //Concrete Bank Account Classes having their own rules for Minimum Balance
    public class ICICI : BankAccount // Inherit this from BankAccount
    {
        public override bool Withdraw(double amount) // Override this method
        {
            if(Balance - amount >= 0)
            {
                this.Balance -= amount;
                return true;
            }
                
            else
                return false;        
        }

        public override bool Transfer(BankAccount toAccount, double amount) //Override this method
        {
            if (Balance - amount >= 1000)
            {
                this.Balance -= amount;
                toAccount.Deposit(amount);
                return true;
            }
            else
                return false;        
        }
    }


    public class HSBC : BankAccount// Inherit this from BankAccount
    {
        public override bool Withdraw(double amount) // Override this method
        {
            if(Balance - amount >= 5000)
            {
                this.Balance -= amount;
                return true;
            }
                
            else
                return false;        
        }

         public override bool Transfer(BankAccount toAccount, double amount) //Override this method
         {
             if (Balance - amount >= 5000)
             {
                 this.Balance -= amount;
                 toAccount.Deposit(amount);
                 return true;
             }
             else
                 return false;
         }
    }
}
