﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contact.LIB;

namespace Contact.UI
{
    class ContactUI
    {
        public static List<ContactLIB> myContacts = new List<ContactLIB>();

        public static void Add()
        {
            ContactLIB obj = new ContactLIB();
            Console.WriteLine("Enter Contact ID: ");
            obj.ContactNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Name of Contact");
            obj.ContactName = Console.ReadLine();

            Console.WriteLine("Enter the mobile no");
            obj.CellNo = Console.ReadLine();

            myContacts.Add(obj);
        }

        public static void Display()
        {
            ContactLIB obj1 = new ContactLIB();
            Console.WriteLine("Enter Contact id you want to Search: ");
            int id = Convert.ToInt32(Console.ReadLine());
            obj1 = myContacts.Find(x => x.ContactNo == id);
            Console.WriteLine("Contact No. :{0}", obj1.ContactNo);
            Console.WriteLine("Cell No. :{0}", obj1.CellNo);
            Console.WriteLine("Contact Name :{0}", obj1.ContactName);
            Console.WriteLine("=========================================");
                        

        }

        public static void Edit()
        {
            ContactLIB obj = new ContactLIB();
            Console.WriteLine("Enter Id :");
            int id1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter New Cell No. :");
            string cln = Console.ReadLine();
            Console.WriteLine("Enter New contact Name :");
            string cn = Console.ReadLine();
            obj = myContacts.Find(x => x.ContactNo == id1);
            obj.CellNo = cln;
            obj.ContactName = cn;
        }

        public static void ShowAll()
        {
            foreach (ContactLIB item in myContacts)
            {
                Console.WriteLine("Contact No. :{0}", item.ContactNo);
                Console.WriteLine("Cell No. :{0}", item.CellNo);
                Console.WriteLine("Contact Name :{0} ", item.ContactName);
                Console.WriteLine("=========================================");
            }
        }
        
        
        static void Main(string[] args)
        {
            #region Main Code Block
            ContactUI ob1=new ContactUI();
            int choice;
            do
            {
                //Menu
                Console.WriteLine("1. TO Add Contact");
                Console.WriteLine("2. TO Display Contact");
                Console.WriteLine("3. TO Edit Contact");
                Console.WriteLine("4. TO Show All Contact");
                Console.WriteLine("5. Exit");
                choice = Convert.ToInt32(Console.ReadLine());

                //ContactNo
                //ContatName
                //CellNo

                switch (choice)
                {
                    case 1:
                        ContactUI.Add();
                        break;

                    case 2:
                        ContactUI.Display();
                        break;

                    case 3:
                        ContactUI.Edit();
                        break;

                    case 4:
                        ContactUI.ShowAll();
                        break;

                    case 5:         
                                    System.Environment.Exit(0);
                                    break;

                    default:
                                    Console.WriteLine("Invalid number Entered");
                                    break;
                }


            } while (choice !=5);
            #endregion
        }
    }
}
