﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductLIB;


namespace Product.UI
{
    class ProductUser
    {
        public static ArrayList ProductList = new ArrayList();
        public static void AddProduct()
        {
            MyProduct obj = new MyProduct();
            Console.WriteLine("Enter Product No.");
            obj.ProductNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Name :");
            obj.Name = Console.ReadLine();
            Console.WriteLine("Enter Product Rate: ");
            obj.Rate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Stock: ");
            obj.Stock = Convert.ToInt32(Console.ReadLine());
            ProductList.Add(obj);

              foreach (MyProduct item in ProductList)
            {
                Console.WriteLine(item.ProductNo);
                Console.WriteLine(item.Name);
                Console.WriteLine(item.Rate);
                Console.WriteLine(item.Stock);
            }
            Console.WriteLine("Record added");
        }

        public static void DeleteProduct()
        {
            Console.WriteLine("Enter Product No.");
            int id = Convert.ToInt32(Console.ReadLine());
            foreach (MyProduct item in ProductList)
            {
                if (item.ProductNo == id)
                {
                    ProductList.Remove(item);
                    Console.WriteLine("Record Deleted");
                    break;
                }
            }
        }

        public static void SearchProduct()
        {
            Console.WriteLine("Enter Product No.");
            int id = Convert.ToInt32(Console.ReadLine());
            int cnt = 0;
            foreach (MyProduct item in ProductList)
            {
                if (item.ProductNo == id)
                {
                    Console.WriteLine("Searched Product ");
                    Console.WriteLine("Product No. {0}",item.ProductNo);
                    Console.WriteLine("Product No. {0}", item.Name);
                    Console.WriteLine("Product No. {0}", item.Rate);
                    Console.WriteLine("Product No. {0}", item.Stock);
                    cnt++;
                    break;
                }
            }
            if (cnt==0)
            {
                Console.WriteLine("No such code Exit");
            }
        }

        public static void ModifyProduct()
        {
            Console.WriteLine("Enter Product No.");
            int id1 = Convert.ToInt32(Console.ReadLine());
            int cnt = 0;
            foreach (MyProduct item in ProductList)
            {
                if (item.ProductNo == id1)
                {
                    Console.WriteLine("Enter New Product Name :");
                    item.Name = Console.ReadLine();
                    Console.WriteLine("Enter New Product Rate: ");
                    item.Rate = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter New Product Stock: ");
                    item.Stock = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Record Modified Successfully");
                    cnt++;
                    break;
                }
            }
            if (cnt == 0)
            {
                Console.WriteLine("No such Record Exists");
            }
        }
        
        static void Main(string[] args)
        {
            
            int choice;
            do
            {
                //Menu
                Console.WriteLine("1. For Adding New Product");
                Console.WriteLine("2. For Deleting Product");
                Console.WriteLine("3. For Searching Product");
                Console.WriteLine("4. For Save the New Product");
                Console.WriteLine("5. Exit");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        ProductUser.AddProduct();
                        break;

                    case 2:
                        ProductUser.DeleteProduct();
                        break;

                    case 3:
                        ProductUser.SearchProduct();
                        break;

                    case 4:
                        ProductUser.ModifyProduct();
                        break;
                    case 5: System.Environment.Exit(0);
                        break;
                    default:
                        break;
                }
            } while (choice !=5);
            
        }
    }
}
