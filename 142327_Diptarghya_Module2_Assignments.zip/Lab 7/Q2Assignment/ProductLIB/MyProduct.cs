﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLIB
{
    public class MyProduct
    {
        //ProductNo, Name, Rate and Stock.
        #region Attributes
        int productNo;
        string name;
        int rate;
        int stock;
        #endregion

        public int Stock
        {
            get { return stock; }
            set { stock = value; }
        }

        public int Rate
        {
            get { return rate; }
            set { rate = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int ProductNo
        {
            get { return productNo; }
            set { productNo = value; }
        }
    }
}
