﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.LIB
{
    public class EmployeeBL
    {
        //Employee Number, Name and Basic Salary, and PF attributes.
        int empNumber;
        string empName;
        int BasicSalary;
        int ProvidentFnd;

        public int EmpProvidentFnd
        {
            get { return ProvidentFnd; }
            set { ProvidentFnd = value; }
        }

        public int EmpBasicSalary
        {
            get { return BasicSalary; }
            set { BasicSalary = value; }
        }

        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }

        public int EmpNumber
        {
            get { return empNumber; }
            set { empNumber = value; }
        }

        public EmployeeBL()
        {
            EmpNumber = 101;
            EmpName = "Ram";
            EmpBasicSalary = 10000;
            EmpProvidentFnd = 1000;
        }

        public EmployeeBL(int id, string nm, int bs, int pf)
        {
            EmpNumber = id;
            EmpName = nm;
            EmpBasicSalary = bs;
            EmpProvidentFnd = pf;
        }
    }
}
