﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee.LIB;

namespace Employee.UI
{
    class EmployeeUser
    {
        //Making Lsits
        public static List<EmployeeBL> employeeList = new List<EmployeeBL>();

        public static void Add()
        {
            EmployeeBL ebl = new EmployeeBL();
            Console.WriteLine("Enter Employee Number");
            ebl.EmpNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name: ");
            ebl.EmpName = Console.ReadLine();
            Console.WriteLine("Eneter Employee's Basic Salary: ");
            ebl.EmpBasicSalary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Eneter Employee's Provident Fund:  ");
            ebl.EmpProvidentFnd = Convert.ToInt32(Console.ReadLine());

            employeeList.Add(ebl);
            Console.WriteLine("Record Added");
            Console.ReadLine();
        }

        public static void Search()
        {
            EmployeeBL obj = new EmployeeBL();
            Console.WriteLine("Enter Employee Number you wannna Search: ");
            int id = Convert.ToInt32(Console.ReadLine());
            obj = employeeList.Find(x => x.EmpNumber == id);
            Console.WriteLine("Employee No. :{0}", obj.EmpNumber);
            Console.WriteLine("Employee Name. :{0}", obj.EmpName);
            Console.WriteLine("Employee Basic Salary :{0}", obj.EmpBasicSalary);
            Console.WriteLine("Employee Provident Fund :{0}", obj.EmpProvidentFnd);
            Console.WriteLine("=========================================");
            Console.ReadLine();
        }
        
        public static void Delete()
        {
            EmployeeBL ebl = new EmployeeBL();
            Console.WriteLine("Enter Employee Number you wannna Delete: ");
            int id = Convert.ToInt32(Console.ReadLine());
            ebl = employeeList.Find(x => x.EmpNumber == id);
            employeeList.Remove(ebl);
            Console.WriteLine("Record Deleted");
        }
        
        public static void ViewAll()
        {
            foreach (EmployeeBL item in employeeList)
            {
                Console.WriteLine("Employee No. :{0}", item.EmpNumber);
                Console.WriteLine("Employee Name. :{0}", item.EmpName);
                Console.WriteLine("Employee Basic Salary :{0}", item.EmpBasicSalary);
                Console.WriteLine("Employee Provident Fund :{0}", item.EmpProvidentFnd);
            }
            Console.ReadLine();
        }
        
        static void Main(string[] args)
        {
            //The Client application should allow Adding new Employee’s of specified type, 
            //Searching Records, Delete Records and View all records operations.

            int choice;
            do
            {
                //Menu
                Console.WriteLine("1. TO Add new Employee");
                Console.WriteLine("2. TO Search Existing Employee");
                Console.WriteLine("3. TO Delete Records");
                Console.WriteLine("4. TO View All Records");
                Console.WriteLine("5. Exit");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        EmployeeUser.Add();
                        break;

                    case 2:
                        EmployeeUser.Search();
                        break;

                    case 3:
                        EmployeeUser.Delete();
                        break;

                    case 4:
                        EmployeeUser.ViewAll();
                        break;

                    case 5:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid number Entered");
                        break;
                }


            } while (choice != 5);
            Console.ReadLine();
        }
    }
}
