﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLIB;

namespace Lab4Q1
{
    public class ContractEmployee:Employee
    {
        public int perks;
        public override void GetSalary()
        {
            Salary = Salary + perks;
            Console.WriteLine("Salary:"+Salary);
        }

    }
}
