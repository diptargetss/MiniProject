﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLIB;

namespace Lab4Q1
{
    public class PermanentEmployee:Employee
    {
        public int NoOfLeaves;
        public int ProvidentFund;
        public override void GetSalary()
        {
            Salary = Salary - ProvidentFund;
            Console.WriteLine("Salary:" + Salary);
        }


    }
}
