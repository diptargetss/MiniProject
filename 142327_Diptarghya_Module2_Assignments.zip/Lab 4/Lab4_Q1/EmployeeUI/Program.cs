﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLIB;
using Lab4Q1;


namespace EmployeeUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Type of Employee:\n1 For Contract\n2 For Permanent");
            int ch = Convert.ToInt32(Console.ReadLine());
            switch(ch)
            {
                case 1:
                    ContractEmployee ct = new ContractEmployee();
                    Console.WriteLine("Enter name:");
                    ct.EmployeeName = Console.ReadLine();
                    Console.WriteLine("Enter ID:");
                    ct.EmployeeId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Address:");
                    ct.Address = Console.ReadLine();
                    Console.WriteLine("Enter city:");
                    ct.City = Console.ReadLine();
                    Console.WriteLine("Enter salary:");
                    ct.Salary = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter perks:");
                    ct.perks = Convert.ToInt32(Console.ReadLine());
                    ct.GetSalary();
                    break;
                case 2:
                    PermanentEmployee pt = new PermanentEmployee();
                    Console.WriteLine("Enter name:");
                    pt.EmployeeName = Console.ReadLine();
                    Console.WriteLine("Enter ID:");
                    pt.EmployeeId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Address:");
                    pt.Address = Console.ReadLine();
                    Console.WriteLine("Enter city:");
                    pt.City = Console.ReadLine();
                    Console.WriteLine("Enter salary:");
                    pt.Salary = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter provident fund:");
                    pt.ProvidentFund = Convert.ToInt32(Console.ReadLine());
                    pt.GetSalary();
                    break;
                default:
                Console.WriteLine("Enter Valid Choice.");break;
            }
            
        }
    }
}
