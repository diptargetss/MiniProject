﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product.LIB;

namespace Product.UI
{
    class ProductTest
    {
        static void Main(string[] args)
        {
            try
            {
                ProductMock obj = new ProductMock();

                Console.WriteLine("**********Product Details**********");
                Console.Write("\nEnter ID: ");
                int id = Convert.ToInt32(Console.ReadLine());

                Console.Write("\nEnter Product Name: ");
                 string name= Console.ReadLine();

                Console.Write("\nEnter Price: ");
                double pr = Convert.ToDouble(Console.ReadLine());

                obj.ProductID=id;
                obj.ProductName=name;
                obj.Price=pr;
            }
            catch (DataEntryException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
