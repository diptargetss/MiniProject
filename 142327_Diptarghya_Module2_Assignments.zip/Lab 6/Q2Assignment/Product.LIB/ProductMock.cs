﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product.LIB
{
    public class ProductMock
    {
        
        int productID;
        string productName;
        double price;
        

        
        public double Price
        {
            get { return price; }
            set
            {
                if (value > 0)
                {
                    price = value;
                }
                else
                {
                    throw new DataEntryException("Price of product must be greater than zero.");
                }
            }
        }

        public string ProductName
        {
            get { return productName; }
            set
            {
                if (value =="")
                {
                    throw new DataEntryException("Product Name cannot be left blank");
                }
                else
                {
                    productName = value;
                }
            }
        }

        public int ProductID
        {
            get { return productID; }
            set
            {
                if (value > 0)
                {
                    productID = value;
                }
                else
                {
                    throw new DataEntryException("Product ID must be greater than Zero");
                }
            }
        }
        
    }
}
