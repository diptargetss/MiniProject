﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerLIB
{
    //Task-04.2
    public class InvalidCreditLimit:ApplicationException
    {
        public InvalidCreditLimit(string message): base(message)
        {

        }
    }
}
