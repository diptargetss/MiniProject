﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerLIB
{
    public class Customer
    {
        
        int customerID;
        string customerName;        
        string address;        
        string city;
        double phoneNo;
        int creditLimit;
        

        
        public int CustomerID
        {
            get { return customerID; }
            set { customerID = value; }
        }
        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public string City
        {
            get { return city; }
            set { city = value; }
        }
        public double PhoneNo
        {
            get { return phoneNo; }
            set { phoneNo = value; }
        }
        public int CreditLimit
        {
            get { return creditLimit; }
            set 
            {
                if (value <50000)
                {
                    creditLimit = value;                     
                }
                else
                {
                    throw new InvalidCreditLimit("Invalid Credit Limit Entered");
                }
            }
        }
        

       
        public Customer()
        {
            CustomerID = 101;
            CustomerName = "Arthur";
            Address = "Pune";
            PhoneNo = 9346533433;
        }

        public Customer(string c, int cl)
        {
            City = c;
            CreditLimit = cl;
        }
        
    }
}
