﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerLIB;

namespace CustomerUI
{
    class CustomerUI
    {
        static void Main(string[] args)
        {
            #region Task-05
            try
            {
                new Customer();
                //new Customer("Chennai", 50007);// If you run this it will throw exception
                new Customer("Kolkata", 4992); //this one will not throw exceptin

            }
            catch (InvalidCreditLimit e)
            {

                Console.WriteLine(e.Message); ;
            }
            #endregion
        }
    }
}
