﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2_1
{
    class student
    {
        private string studentName;
        private string address;
        private byte age;
        private int rollNumber;
        private char gender;
        private double percentage;
        private DateTime dateOfBirth;
        public student(string name, string addr, byte ag, int roll, char gendr, DateTime dob, double percent)
        {
            studentName = name;
            address = addr;
            age = ag;
            rollNumber = roll;
            gender = gendr;
            dateOfBirth = dob;
            percentage = percent;

        }
        public void display()
        {
            Console.WriteLine(studentName);
            Console.WriteLine(address);
            Console.WriteLine(age);
            Console.WriteLine(rollNumber);
            Console.WriteLine(gender);
            Console.WriteLine(dateOfBirth);
            Console.WriteLine(percentage);

        }
    }
}
