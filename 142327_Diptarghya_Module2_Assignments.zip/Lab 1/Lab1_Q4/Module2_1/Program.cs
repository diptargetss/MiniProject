﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter student details:");
            Console.WriteLine("Enter student name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter address:");
            string addr = Console.ReadLine();
            Console.WriteLine("Enter age:");
            byte ag = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Enter roll number:");
            int roll = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter gender:");
            char gdr = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Enter date of birth:");
            DateTime dob = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter percentage:");
            double percent = Convert.ToDouble(Console.ReadLine());
            student ss = new student(name, addr, ag, roll, gdr, dob, percent);
            ss.display();

        }
    }
}
