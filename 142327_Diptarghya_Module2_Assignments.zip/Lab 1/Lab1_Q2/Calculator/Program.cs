﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module2_Q2;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter 1st operand:");
            double op1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter 2nd operand:");
            double op2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Select operation you want to perform::");
            Console.WriteLine("1 for Add\n2 for Subtract\n3 for Multiply\n4 for Division\n5 for Modulus");
            int sw = Convert.ToInt32(Console.ReadLine());
            ArithmeticOperations ap = new ArithmeticOperations();
            
            switch(sw)
            {
                case 1:
                    ap.Add(op1,op2);
                    break;
                case 2:
                    ap.Sub(op1, op2);
                    break;
                case 3:
                    ap.Prod(op1, op2);
                    break;
                case 4:
                    ap.Divide(op1, op2);
                    break;
                case 5:
                    ap.Modulo(op1, op2);
                    break;
                default:
                    Console.WriteLine("Enter valid choice");
                    break;

            }
            Console.WriteLine("Result:" + ap.res);
            Console.ReadLine();
        }
    }
}
