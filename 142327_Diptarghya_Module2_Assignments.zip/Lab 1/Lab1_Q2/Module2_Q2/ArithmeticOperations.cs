﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2_Q2
{
    public class ArithmeticOperations
    {
        public double res;
        public void Add(int op1,int op2)
        {
            res = op1 + op2;
        }
        public void Sub(int op1, int op2)
        {
            res = op1 - op2;
        }
        public void Prod(int op1, int op2)
        {
            res = op1 * op2;
        }
        public void Divide(int op1, int op2)
        {
            res = op1 / op2;
        }
        public void Add(double op1, double op2)
        {
            res = op1 + op2;
        }
        public void Sub(double op1, double op2)
        {
            res = op1 - op2;
        }
        public void Prod(double op1, double op2)
        {
            res = op1 * op2;
        }
        public void Divide(double op1, double op2)
        {
            res = op1 / op2;
        }
        public void Modulo(double op1, double op2)
        {
            res = op1 % op2;
        }
        public void Modulo(int op1, int op2)
        {
            res = op1 % op2;
        }

        

    }
}
