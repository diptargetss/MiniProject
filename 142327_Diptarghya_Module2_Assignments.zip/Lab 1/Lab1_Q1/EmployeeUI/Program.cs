﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLIB;


namespace EmployeeUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Initializing object of class Employee
            Employee emp1 = new Employee();
            int i;

            //Receiving details from end user

            //Console.WriteLine("Please enter your Employee ID:");
            //emp1.EmployeeId = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Please enter your Name:");
            //emp1.EmployeeName = Console.ReadLine();
            //Console.WriteLine("Please enter your Address:");
            //emp1.Address = Console.ReadLine();
            //Console.WriteLine("Please enter your City:");
            //emp1.City = Console.ReadLine();
            //Console.WriteLine("Please enter your Department:");
            //emp1.Department = Console.ReadLine();
            //Console.WriteLine("Please enter your Salary:");
            //emp1.Salary = Convert.ToInt32(Console.ReadLine());
            Employee[] C=new Employee[10];


            for (i = 0; i < 10;i++ )
            {
                C[i] = new Employee();
                Console.WriteLine("Please enter your Employee ID:");
                C[i].EmployeeId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please enter your Name:");
                C[i].EmployeeName = Console.ReadLine();
                Console.WriteLine("Please enter your Address:");
                C[i].Address = Console.ReadLine();
                Console.WriteLine("Please enter your City:");
                C[i].City = Console.ReadLine();
                Console.WriteLine("Please enter your Department:");
                C[i].Department = Console.ReadLine();
                Console.WriteLine("Please enter your Salary:");
                C[i].Salary = Convert.ToInt32(Console.ReadLine());
                

            }
            for(i=0;i<10;i++)
            {
                Console.WriteLine("Name:"+C[i].EmployeeName);
                //Console.WriteLine("ID:"+C[i].EmployeeId);
                Console.WriteLine("Salary:"+C[i].Salary);
            }

            //foreach(int i in E)
            //{
            //    Console.WriteLine("Please enter your Employee ID:");
            //    E[i].EmployeeId = Convert.ToInt32(Console.ReadLine());
            //    Console.WriteLine("Please enter your Name:");
            //    E[i].EmployeeName = Console.ReadLine();
            //    Console.WriteLine("Please enter your Address:");
            //    E[i].Address = Console.ReadLine();
            //    Console.WriteLine("Please enter your City:");
            //    E[i].City = Console.ReadLine();
            //    Console.WriteLine("Please enter your Department:");
            //    E[i].Department = Console.ReadLine();
            //    Console.WriteLine("Please enter your Salary:");
            //    E[i].Salary = Convert.ToInt32(Console.ReadLine());
                
            //}
        }
    }
}
