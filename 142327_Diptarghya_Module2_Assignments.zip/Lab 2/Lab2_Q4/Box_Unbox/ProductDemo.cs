﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box_Unbox
{
    class ProductDemo
    {
        public object productId, productName, price, qty;
        public ProductDemo(int pid,string name,int pr,int qt)
        {
            productId = pid;
            productName = name;
            price = pr;
            qty = qt;
        }
        
    }
}
