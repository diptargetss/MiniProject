﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box_Unbox
{
    class program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Enter product details:");
            Console.WriteLine("Enter product Id::");
            int pid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter product Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter price:");
            int pr = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter quantity:");
            int qt = Convert.ToInt32(Console.ReadLine());
            ProductDemo pd = new ProductDemo(pid, name, pr, qt);
            pid = (int)pd.productId;
            name = (string)pd.productName;
            pr = (int)pd.price;
            qt = (int)pd.qty;
            int amtPayable = pr * qt;
            Console.WriteLine(pid);
            Console.WriteLine(name);
            Console.WriteLine(pr);
            Console.WriteLine(qt);
            Console.WriteLine("Amount Payable:"+amtPayable);


        }
    }
}
