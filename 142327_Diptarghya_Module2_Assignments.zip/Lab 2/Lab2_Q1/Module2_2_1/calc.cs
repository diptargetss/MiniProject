﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2_2_1
{
    
        public struct Number
        {
            int number;
           public Number(int c)
            {
                number = c;
            }
            public void squarer()
            {
                Console.WriteLine("Square of number:"+(number*number));
            }
            public void cuber()
            {
                Console.WriteLine("Cube of number:"+(number*number*number));
            }
        }
    
}
