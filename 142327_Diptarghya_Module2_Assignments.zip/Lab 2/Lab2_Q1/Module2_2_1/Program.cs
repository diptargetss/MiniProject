﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2_2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number:");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter choice:: \n1 To square\n2 To Cube");
            int ch = Convert.ToInt32(Console.ReadLine());

            Number num = new Number(n);
            switch(ch)
            {
                case 1:
                    num.squarer();
                    break;
                case 2:
                    num.cuber();
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }
        }
    }
}
