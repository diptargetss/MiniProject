﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayOfCities
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] city = new string[7];
            Console.WriteLine("Enter names of 7 cities:");
            for(int i=0;i<7;i++)
            {
                city[i] = Console.ReadLine();
            }
            Console.WriteLine("The cities are:");
            foreach (var item in city)
            {
                Console.WriteLine(item);
            }
        }
    }
}
