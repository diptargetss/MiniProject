﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooksDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter Book Details:");
            string[,] bookDetails = new string[2, 4];
            for (int i = 0; i < bookDetails.GetLength(0); i++)
            {
                for (int j = 0; j < bookDetails.GetLength(1); j++)
                {
                    if (j == 0)
                        Console.WriteLine("Enter Book name:");
                    else if (j == 1)
                        Console.WriteLine("Enter Book author:");
                    else if (j == 2)
                        Console.WriteLine("Enter book publisher:");
                    else
                        Console.WriteLine("Enter price:");
                    bookDetails[i, j] = Console.ReadLine();
                }
            }

            string[] colname = new string[4]{"Title","Author","Publisher","Price"};
            foreach (var item in colname)
            {
                Console.Write("{0}\t\t",item);
            }
            Console.WriteLine();

            for (int i = 0; i < bookDetails.GetLength(0); i++)
            {
                for (int j = 0; j < bookDetails.GetLength(1); j++)
                {
                    Console.Write(bookDetails[i, j]+"\t\t");
                }
                Console.WriteLine();
            }

            
        }
    }
}
